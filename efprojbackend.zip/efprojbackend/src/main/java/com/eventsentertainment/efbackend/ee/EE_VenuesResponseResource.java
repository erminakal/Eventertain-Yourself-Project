
package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.model.ee.EE_RegionModel;
import com.evententertainment.database.dao.ee.EE_RegionDAO;
import com.evententertainment.database.dao.ee.EE_RegionDAOImpl;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAO;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAOImpl;
import com.evententertainment.database.model.ee.request.EE_VenueRequest;
import com.evententertainment.database.model.ee.response.EE_VenuesResponseModel;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


// http://localhost:8080/efbackend/webresources/ee/searchvenues
@Path("ee")
public class EE_VenuesResponseResource {

    @Context
   private UriInfo context;

    public EE_VenuesResponseResource() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    
    @Path("searchvenues")
    public List<EE_VenuesResponseModel> search(EE_VenueRequest request) {
       
        EE_VenuesResponseDAO vdao = new EE_VenuesResponseDAOImpl();
        EE_RegionDAO rdao = new EE_RegionDAOImpl();
        
        String placename = request.getSelectedVenuePlace();
        
        EE_RegionModel place = rdao.findByName(placename);
        
        if (place != null) {
            request.setLatitude(place.getLatitude());
            request.setLongitude(place.getLongitude());
        }
        
        List<EE_VenuesResponseModel> list = vdao.search(request);
     
        return list;
    }

   
}