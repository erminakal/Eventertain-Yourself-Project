/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_VenuesResponseDAO;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAOImpl;
import com.evententertainment.database.model.ee.request.EE_Free_Search_VenuesRequest;
import com.evententertainment.database.model.ee.response.EE_VenuesResponseModel;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// http://localhost:8080/efbackend/webresources/ee/tag_words_search_venues
@Path("ee")
public class EE_TagWordsVenuesResource {

    @Context
    private UriInfo context;

    public EE_TagWordsVenuesResource() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("tag_words_search_venues")
    public List<EE_VenuesResponseModel> search_all(EE_Free_Search_VenuesRequest request) {
        EE_VenuesResponseDAO vdao = new EE_VenuesResponseDAOImpl();

        List<EE_VenuesResponseModel> list = vdao.search_all(request);
        System.out.println(list);
        return list;
    }

}
