/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_EventsResponseDAO;
import com.evententertainment.database.dao.ee.EE_EventsResponseDAOImpl;
import com.evententertainment.database.model.ee.request.EE_Free_Search_EventsRequest;
import com.evententertainment.database.model.ee.response.EE_EventsResponseModel;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import opennlp.tools.stemmer.PorterStemmer;

// http://localhost:8080/efbackend/webresources/ee/tag_words_search_events
@Path("ee")
public class EE_TagWordsEventsResource {

    @Context
    private UriInfo context;

    public EE_TagWordsEventsResource() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("tag_words_search_events")
    public List<EE_EventsResponseModel> search_all(EE_Free_Search_EventsRequest request) {

        EE_EventsResponseDAO edao = new EE_EventsResponseDAOImpl();
        
        List<EE_EventsResponseModel> list = edao.search_all(request);
      //  System.out.println(request);
         System.out.println(list);

        return list;
    }

}
