/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_VenueCategoryDAOImpl;
import com.evententertainment.database.model.ee.EE_Venue_CategoryModel;

import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import com.evententertainment.database.dao.ee.EE_VenueCategoryDAO;

/**
 * REST Web Service
 *
 * @author user
 */
// http://localhost:8080/efbackend/webresources/ee/venue_categories
@Path("ee")
public class EE_Venue_CategoryResource {

    @Context
    private UriInfo context;

    public EE_Venue_CategoryResource() {
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("venue_categories")
    public List<EE_Venue_CategoryModel> getVenueCategories() {
       EE_VenueCategoryDAO vcdao = new EE_VenueCategoryDAOImpl();

        List<EE_Venue_CategoryModel> list = vcdao.listByName();

        return list;
    }

   
}
