package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_RegionDAO;
import com.evententertainment.database.dao.ee.EE_RegionDAOImpl;
import com.evententertainment.database.model.ee.EE_RegionModel;
 
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

// http://localhost:8080/efbackend/webresources/ee/regions
@Path("ee")
public class EE_RegionResource {

    @Context
    private UriInfo context;

    public EE_RegionResource() {
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("regions")
    public List<EE_RegionModel> getRegions() {
        EE_RegionDAO rdao = new EE_RegionDAOImpl();
   
        List<EE_RegionModel> list = rdao.listByName();

        return list;
    }
}
