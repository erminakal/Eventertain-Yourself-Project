/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_EventsResponseDAO;
import com.evententertainment.database.dao.ee.EE_EventsResponseDAOImpl;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAO;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAOImpl;
import com.evententertainment.database.model.ee.request.EE_FindEventsFromSelectedVenueRequest;
import com.evententertainment.database.model.ee.response.EE_EventsResponseModel;
import com.evententertainment.database.model.ee.response.EE_VenuesResponseModel;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("ee")
public class EE_FindEventsFromSelectedVenueResource {

    @Context
    private UriInfo context;

    public EE_FindEventsFromSelectedVenueResource() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    @Path("eventsclosetovenue")
    public List<EE_EventsResponseModel> find_events_from_selected_venue(EE_FindEventsFromSelectedVenueRequest request) {

        EE_EventsResponseDAO edao = new EE_EventsResponseDAOImpl();
        EE_VenuesResponseDAO vdao = new EE_VenuesResponseDAOImpl();

        long venue_id = request.getVenue_id();
        
        EE_VenuesResponseModel selectedVenue = vdao.find_by_id(venue_id);

        if (selectedVenue != null) {
            request.setLatitude(selectedVenue.getLatitude());
            request.setLongitude(selectedVenue.getLongitude());
        }
        System.out.println(request);
    
         List<EE_EventsResponseModel> list = edao.search_events_close_to_venue(request);
       System.out.println(list);
        return list;
    }

}
