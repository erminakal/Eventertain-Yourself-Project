/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eventsentertainment.efbackend;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author user
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method. It is automatically
     * populated with all resources defined in the project. If required, comment
     * out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(com.evententertainment.filters.CORSFilter.class);
        resources.add(com.eventsentertainment.efbackend.GenericResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_Event_CategoryResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_EventsResponseResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_FindEventsFromSelectedVenueResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_FindVenuesFromSelectedEventResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_RegionResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_TagWordsEventsResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_TagWordsVenuesResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_Venue_CategoryResource.class);
        resources.add(com.eventsentertainment.efbackend.ee.EE_VenuesResponseResource.class);
    }

}
