/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_EventsResponseDAO;
import com.evententertainment.database.dao.ee.EE_EventsResponseDAOImpl;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAO;
import com.evententertainment.database.dao.ee.EE_VenuesResponseDAOImpl;
import com.evententertainment.database.model.ee.request.EE_FindVenuesFromSelectedEventRequest;
import com.evententertainment.database.model.ee.response.EE_EventsResponseModel;
import com.evententertainment.database.model.ee.response.EE_VenuesResponseModel;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("ee")
public class EE_FindVenuesFromSelectedEventResource {

    @Context
    private UriInfo context;

    public EE_FindVenuesFromSelectedEventResource() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    @Path("venuesclosetoevent")
    public List<EE_VenuesResponseModel> find_venues_from_selected_event(EE_FindVenuesFromSelectedEventRequest request) {

        EE_EventsResponseDAO edao = new EE_EventsResponseDAOImpl();
        EE_VenuesResponseDAO vdao = new EE_VenuesResponseDAOImpl();

        String event_api_id = request.getEventApiId();
        EE_EventsResponseModel selectedEvent = edao.find_by_api_id(event_api_id);

        if (selectedEvent != null) {
            request.setLatitude(selectedEvent.getLatitude());
            request.setLongitude(selectedEvent.getLongitude());
        }
        List<EE_VenuesResponseModel> list = vdao.search_venues_close_to_event(request);

        return list;
    }

}
