package com.eventsentertainment.efbackend.ee;

import com.evententertainment.database.dao.ee.EE_EventCategoryDAO;
import com.evententertainment.database.dao.ee.EE_EventCategoryDAOImpl;
import com.evententertainment.database.model.ee.EE_Event_CategoryModel;

import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

// http://localhost:29554/efprojbackend/webresources/ee/event_categories
@Path("ee")
public class EE_Event_CategoryResource {

    @Context      
    private UriInfo context;

    public EE_Event_CategoryResource() {
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("event_categories")
    public List<EE_Event_CategoryModel> getEventCategories() {
        EE_EventCategoryDAO ecdao = new EE_EventCategoryDAOImpl();

        List<EE_Event_CategoryModel> list = ecdao.listByName();

        return list;
    }

}
