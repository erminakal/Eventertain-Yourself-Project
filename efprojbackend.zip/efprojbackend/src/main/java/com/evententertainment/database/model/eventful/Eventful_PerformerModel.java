
package com.evententertainment.database.model.eventful;

import java.util.ArrayList;

public class Eventful_PerformerModel {

    private long id;
    private String api_id;
    private String url;
    private String vanity_url;
    private String name;
    private boolean is_human;
    private String short_bio;
    private String long_bio;
    private String created;
    private String creator;
    private long demand_count;
    private long demand_member_count;
    private long event_count;
    private String category;
    private boolean withdrawn;
    private String withdrawn_note;

    //relationships
    private Eventful_PerformerImageModel performerimageModel = null;

    private Eventful_EventHasPerformerModel ehpModel = null;

    private Eventful_Performer_Has_Eventful_Event_CategoryModel phcModel = null;

    private ArrayList<Eventful_Event_CategoryModel> categories = new ArrayList<>();

    public Eventful_PerformerModel() {
    }

    public Eventful_PerformerModel(long id, String api_id, String url, String vanity_url, String name, boolean is_human, String short_bio, String long_bio, String created, String creator, long demand_count, long demand_member_count, long event_count, String category, boolean withdrawn, String withdrawn_note) {
        this.id = id;
        this.api_id = api_id;
        this.url = url;
        this.vanity_url = vanity_url;
        this.name = name;
        this.is_human = is_human;
        this.short_bio = short_bio;
        this.long_bio = long_bio;
        this.created = created;
        this.creator = creator;
        this.demand_count = demand_count;
        this.demand_member_count = demand_member_count;
        this.event_count = event_count;
        this.category = category;
        this.withdrawn = withdrawn;
        this.withdrawn_note = withdrawn_note;
    }

    public void print() {
        System.out.println("----------------------------------------");
        System.out.println("Performer's api_id is: " + this.getApi_id() + "and belongs to category: " + this.getCategory());
        System.out.println("Performer's url is: " + this.getUrl());
        System.out.println("We are talking about : " + this.getName() + " and you can see below a few things: " + this.getShort_bio());
        System.out.println("For more information check here : " + this.getLong_bio());
        System.out.println("Performer's creator is: " + this.getCreator());
        System.out.println("Performer was created in database on : " + this.getCreated());
        System.out.println(this.getName() + " has participated in : " + this.getEvent_count() + " events.");
        System.out.println("------------------------------------------");

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getVanity_url() {
        return vanity_url;
    }

    public void setVanity_url(String vanity_url) {
        this.vanity_url = vanity_url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isIs_human() {
        return is_human;
    }

    public void setIs_human(boolean is_human) {
        this.is_human = is_human;
    }

    public String getShort_bio() {
        return short_bio;
    }

    public void setShort_bio(String short_bio) {
        this.short_bio = short_bio;
    }

    public String getLong_bio() {
        return long_bio;
    }

    public void setLong_bio(String long_bio) {
        this.long_bio = long_bio;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public long getDemand_count() {
        return demand_count;
    }

    public void setDemand_count(long demand_count) {
        this.demand_count = demand_count;
    }

    public long getDemand_member_count() {
        return demand_member_count;
    }

    public void setDemand_member_count(long demand_member_count) {
        this.demand_member_count = demand_member_count;
    }

    public long getEvent_count() {
        return event_count;
    }

    public void setEvent_count(long event_count) {
        this.event_count = event_count;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isWithdrawn() {
        return withdrawn;
    }

    public void setWithdrawn(boolean withdrawn) {
        this.withdrawn = withdrawn;
    }

    public String getWithdrawn_note() {
        return withdrawn_note;
    }

    public void setWithdrawn_note(String withdrawn_note) {
        this.withdrawn_note = withdrawn_note;
    }

    public Eventful_PerformerImageModel getPerformerimageModel() {
        return performerimageModel;
    }

    public void setPerformerimageModel(Eventful_PerformerImageModel performerimageModel) {
        this.performerimageModel = performerimageModel;
    }

    public Eventful_EventHasPerformerModel getEhpModel() {
        return ehpModel;
    }

    public void setEhpModel(Eventful_EventHasPerformerModel ehpModel) {
        this.ehpModel = ehpModel;
    }

    public Eventful_Performer_Has_Eventful_Event_CategoryModel getPhcModel() {
        return phcModel;
    }

    public void setPhcModel(Eventful_Performer_Has_Eventful_Event_CategoryModel phcModel) {
        this.phcModel = phcModel;
    }

    public ArrayList<Eventful_Event_CategoryModel> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<Eventful_Event_CategoryModel> categories) {
        this.categories = categories;
    }

    @Override
    public String toString() {
        return "Eventful_PerformerModel{" + "id=" + id + ", api_id=" + api_id + ", url=" + url + ", vanity_url=" + vanity_url + ", name=" + name + ", is_human=" + is_human + ", short_bio=" + short_bio + ", long_bio=" + long_bio + ", created=" + created + ", creator=" + creator + ", demand_count=" + demand_count + ", demand_member_count=" + demand_member_count + ", event_count=" + event_count + ", category=" + category + ", withdrawn=" + withdrawn + ", withdrawn_note=" + withdrawn_note + ", performerimageModel=" + performerimageModel + ", ehpModel=" + ehpModel + ", phcModel=" + phcModel + ", categories=" + categories + '}';
    }


   

    public boolean has(long performer_id) {
        boolean value;
        if (performer_id >= 1) {
            value = true;
        } else {
            value = false;
        }
        return value;
    }

}
