/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_Venue_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_Venue_CategoryDAOImpl implements Eventful_Venue_CategoryDAO {

    private static final String TABLE = "eventful_venue_category";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_FIND_BY_VENUE_TYPE_NEW = "SELECT * FROM " + TABLE + " WHERE `venue_category` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`venue_category`) values (?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`venue_category`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_DELETE_ALL = "DELETE FROM " + TABLE + "";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_Venue_CategoryModel map(ResultSet resultSet) throws SQLException {
        Eventful_Venue_CategoryModel object = new Eventful_Venue_CategoryModel();

        object.setId(resultSet.getLong("id"));
        object.setVenue_category(resultSet.getString("venue_category"));

        return object;
    }

    @Override
    public List<Eventful_Venue_CategoryModel> list() {
        List<Eventful_Venue_CategoryModel> venues_type = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                venues_type.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return venues_type;
    }

    @Override
    public Eventful_Venue_CategoryModel find(long id) {
        Eventful_Venue_CategoryModel venue = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue;
    }
    
      @Override
    public Eventful_Venue_CategoryModel find(String venue_type_new) {
        Eventful_Venue_CategoryModel venue_type = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_VENUE_TYPE_NEW, venue_type_new);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue_type = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue_type;
    }


    @Override
    public int create(Eventful_Venue_CategoryModel c) {
        int ret = -1;

        Object[] values = {c.getVenue_category()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {

            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getLong(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_Venue_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getVenue_category());) {

            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
        @Override
    public int deleteAll() {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_ALL);) {
            int affectedrows = statement.executeUpdate();
            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return 0;
        }
    }

   
}
