/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_EventModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_EventDAOImpl implements Foursquare_EventDAO {
    private static final String TABLE = "foursquare_event";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM "+TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM "+TABLE+" WHERE `id` = ?";
     private static final String SQL_FIND_BY_API_ID = "SELECT * FROM "+TABLE+" WHERE `api_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO "+TABLE+"(`api_id`,`name`,`url`,`startAt`,`endAt`,`allDay`,`venue_id`) values (?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE "+TABLE+" SET (`api_id`,`name`,`url`,`startAt`,`endAt`,`allDay`,`venue_id`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM "+TABLE+" WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_EventModel map(ResultSet resultSet) throws SQLException {
        Foursquare_EventModel object = new Foursquare_EventModel();

  
        object.setApi_id(resultSet.getString("api_id"));
        object.setName(resultSet.getString("name"));
        object.setUrl(resultSet.getString("url"));
        object.setStartAt(resultSet.getString("startAt"));
        object.setEndAt(resultSet.getString("endAt"));
        object.setAllDay(resultSet.getBoolean("allDay"));
        object.setVenue_id(resultSet.getLong("venue_id"));

        return object;
    }

    @Override
    public List<Foursquare_EventModel> list() {
        List<Foursquare_EventModel> events = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                events.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return events;
    }

    @Override
    public Foursquare_EventModel find(long id) {
        Foursquare_EventModel event = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                event = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return event;
    }

    
@Override
    public Foursquare_EventModel find(String api_id) {
        Foursquare_EventModel event = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                event = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return event;
    }
    
    @Override
    public int create(Foursquare_EventModel c) {
        int ret = -1;
        Object[] values = { c.getApi_id(),c.getName(), c.getUrl(), c.getStartAt(),c.getEndAt(),c.isAllDay(),c.getVenue_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_EventModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getApi_id(),c.getName(), c.getUrl(), c.getStartAt(),c.getEndAt(),c.isAllDay(),c.getVenue_id());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
