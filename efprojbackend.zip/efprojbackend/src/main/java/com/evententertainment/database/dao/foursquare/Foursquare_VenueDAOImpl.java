package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_VenueModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_VenueDAOImpl implements Foursquare_VenueDAO {

    private static final String TABLE = "foursquare_venue";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_FIND_BY_API_ID = "SELECT * FROM " + TABLE + " WHERE `api_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`api_id`,`name`,`canonicalUrl`,`shortUrl`,"
            + "`checkinsCount`,`usersCount`,`tipCount`,`url`,`timezone`,`price_tier`,`price_message`,`price_currency`,`hasMenu`,`rating`,`description`,`createdAt`) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`api_id`,`name`,`canonicalUrl`,`shortUrl`,"
            + "`checkinsCount`,`usersCount`,`tipCount`,`url`,`timezone`,`price_tier`,`price_message`,`price_currency`,`hasMenu`,`rating`,`description`,`createdAt`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_VenueModel map(ResultSet resultSet) throws SQLException {
        Foursquare_VenueModel object = new Foursquare_VenueModel();

        object.setId(resultSet.getLong("id"));

        object.setApi_id(resultSet.getString("api_id"));
        object.setName(resultSet.getString("name"));

        object.setCanonicalUrl(resultSet.getString("canonicalUrl"));
        object.setShortUrl(resultSet.getString("shortUrl"));
        object.setCheckinsCount(resultSet.getLong("checkinsCount"));
        object.setUsersCount(resultSet.getLong("usersCount"));
        object.setTipCount(resultSet.getLong("tipCount"));
        object.setUrl(resultSet.getString("url"));
        object.setTimezone(resultSet.getString("timezone"));
        object.setPrice_tier(resultSet.getInt("price_tier"));
        object.setPrice_message(resultSet.getString("price_message"));
        object.setPrice_currency(resultSet.getString("price_currency"));
        object.setHasMenu(resultSet.getBoolean("hasMenu"));
        object.setRating(resultSet.getFloat("rating"));
        object.setDescription(resultSet.getString("description"));
        object.setCreatedAt(resultSet.getFloat("createdAt"));

        return object;
    }

    @Override
    public List<Foursquare_VenueModel> list() {
        List<Foursquare_VenueModel> venues_details = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                venues_details.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return venues_details;
    }

    @Override
    public Foursquare_VenueModel find(long id) {
        Foursquare_VenueModel venue_details = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue_details = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue_details;
    }

    @Override
    public Foursquare_VenueModel find(String api_id) {
        Foursquare_VenueModel venue = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue;
    }

    @Override
    public int create(Foursquare_VenueModel c) {
        int ret = -1;
        Object[] values = {c.getApi_id(), c.getName(), c.getCanonicalUrl(), c.getShortUrl(),
            c.getCheckinsCount(), c.getUsersCount(), c.getTipCount(), c.getUrl(), c.getTimezone(), c.getPrice_tier(), c.getPrice_message(),
            c.getPrice_currency(), c.isHasMenu(), c.getRating(), c.getDescription(), c.getCreatedAt()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getLong(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_VenueModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getApi_id(), c.getName(),
                        c.getCanonicalUrl(), c.getShortUrl(), c.getCheckinsCount(), c.getUsersCount(), c.getTipCount(),
                        c.getUrl(), c.getTimezone(), c.getPrice_tier(), c.getPrice_message(), c.getPrice_currency(), c.isHasMenu(),
                        c.getRating(), c.getDescription(), c.getCreatedAt());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
