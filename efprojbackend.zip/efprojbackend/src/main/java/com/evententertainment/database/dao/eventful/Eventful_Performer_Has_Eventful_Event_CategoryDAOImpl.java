/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_Performer_Has_Eventful_Event_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_Performer_Has_Eventful_Event_CategoryDAOImpl implements Eventful_Performer_Has_Eventful_Event_CategoryDAO {

    private static final String TABLE = "eventful_performer_has_eventful_event_category";
    private static final String SQL_LIST_ORDER_BY_CATEGORY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_PERFORMER_ID = "SELECT * FROM " + TABLE + " WHERE `eventful_performer_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`eventful_performer_id`,`eventful_event_category_id`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`eventful_performer_id`,`eventful_event_category_id`) WHERE `eventful_performer_id` = ?";
    private static final String SQL_DELETE_BY_PERFORMER_ID = "DELETE FROM " + TABLE + " WHERE `eventful_performer_id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_Performer_Has_Eventful_Event_CategoryModel map(ResultSet resultSet) throws SQLException {
        Eventful_Performer_Has_Eventful_Event_CategoryModel object = new Eventful_Performer_Has_Eventful_Event_CategoryModel();

        object.setEventful_performer_id(resultSet.getLong("eventful_performer_id"));
        object.setEventful_event_category_id(resultSet.getLong("eventful_event_category_id"));
        return object;
    }

    @Override
    public List<Eventful_Performer_Has_Eventful_Event_CategoryModel> list() {
        List<Eventful_Performer_Has_Eventful_Event_CategoryModel> performers_per_category = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_CATEGORY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {

                performers_per_category.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return performers_per_category;
    }

    @Override
    public Eventful_Performer_Has_Eventful_Event_CategoryModel find(long eventful_performer_id) {
        Eventful_Performer_Has_Eventful_Event_CategoryModel performer_per_category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_PERFORMER_ID, eventful_performer_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                performer_per_category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return performer_per_category;
    }

    @Override
    public int create(Eventful_Performer_Has_Eventful_Event_CategoryModel c) {
        int ret = -1;
        Object[] values = {c.getEventful_performer_id(), c.getEventful_event_category_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            return ret;

        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_Performer_Has_Eventful_Event_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getEventful_performer_id(), c.getEventful_event_category_id());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long eventful_performer_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_PERFORMER_ID, eventful_performer_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
