/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_EventHasPerformerModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_Event_Has_PerformerDAOImpl implements Eventful_Event_Has_PerformerDAO {

    private static final String TABLE = "eventful_event_has_performer";
    private static final String SQL_LIST_ORDER_BY_EVENT_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_EVENT_ID = "SELECT * FROM " + TABLE + " WHERE `event_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`event_id`,`performer_id`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`event_id`,`performer_id`) WHERE `event_id` = ?";
    private static final String SQL_DELETE_BY_EVENT_ID = "DELETE FROM " + TABLE + " WHERE `event_id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_EventHasPerformerModel map(ResultSet resultSet) throws SQLException {
        Eventful_EventHasPerformerModel object = new Eventful_EventHasPerformerModel();

        object.setEvent_id(resultSet.getLong("event_id"));
        object.setPerformer_id(resultSet.getLong("performer_id"));

        return object;
    }

    @Override
    public List<Eventful_EventHasPerformerModel> list() {
        List<Eventful_EventHasPerformerModel> eventsperformers = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_EVENT_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {

                eventsperformers.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return eventsperformers;
    }

    @Override
    public Eventful_EventHasPerformerModel find(long event_id) {
        Eventful_EventHasPerformerModel eventperformer = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_EVENT_ID, event_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                eventperformer = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return eventperformer;
    }

    @Override
    public int create(Eventful_EventHasPerformerModel c) {
        int ret = -1;
        Object[] values = {c.getEvent_id(), c.getPerformer_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            return ret;

        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_EventHasPerformerModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getEvent_id(), c.getPerformer_id());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long event_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_EVENT_ID, event_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
