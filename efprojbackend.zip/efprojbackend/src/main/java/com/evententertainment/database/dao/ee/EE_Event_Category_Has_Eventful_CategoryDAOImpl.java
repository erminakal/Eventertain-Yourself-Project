/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.EE_Event_Category_Has_Eventful_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EE_Event_Category_Has_Eventful_CategoryDAOImpl implements EE_Event_Category_Has_Eventful_CategoryDAO {

    private static final String TABLE = "ee_event_category_has_eventful_category";
    private static final String SQL_LIST_ORDER_BY_EE_EVENT_CATEGORY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_EE_EVENT_CATEGORY_ID = "SELECT * FROM " + TABLE + " WHERE `ee_event_category_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`ee_event_category_id`,`eventful_event_category_id`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`ee_event_category_id`,`eventful_event_category_id`) WHERE `ee_event_category_id` = ?";
    private static final String SQL_DELETE_BY_EE_EVENT_CATEGORY_ID = "DELETE FROM " + TABLE + " WHERE `ee_event_category_id` = ?";
    private static final String SQL_DELETE_ALL = "DELETE FROM " + TABLE + "";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static EE_Event_Category_Has_Eventful_CategoryModel map(ResultSet resultSet) throws SQLException {
        EE_Event_Category_Has_Eventful_CategoryModel object = new EE_Event_Category_Has_Eventful_CategoryModel();

        object.setEe_event_category_id(resultSet.getLong("ee_event_category_id"));
        object.setEventful_event_category_id(resultSet.getLong("eventful_event_category_id"));
        return object;
    }

    @Override
    public int deleteAll() {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_ALL);) {
            int affectedrows = statement.executeUpdate();
            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return 0;
        }
    }

    @Override
    public List<EE_Event_Category_Has_Eventful_CategoryModel> list() {
        List<EE_Event_Category_Has_Eventful_CategoryModel> eventful_categories = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_EE_EVENT_CATEGORY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                eventful_categories.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return eventful_categories;
    }

    @Override
    public EE_Event_Category_Has_Eventful_CategoryModel find(long ee_event_category_id) {
        EE_Event_Category_Has_Eventful_CategoryModel eventful_category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_EE_EVENT_CATEGORY_ID, ee_event_category_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                eventful_category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return eventful_category;
    }
    


    @Override
    public long create(EE_Event_Category_Has_Eventful_CategoryModel c) {
        int ret = -1;
        Object[] values = {c.getEe_event_category_id(),c.getEventful_event_category_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }
  return ret;
               } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(EE_Event_Category_Has_Eventful_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE,c.getEe_event_category_id(),c.getEventful_event_category_id());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long ee_event_category_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_EE_EVENT_CATEGORY_ID, ee_event_category_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
