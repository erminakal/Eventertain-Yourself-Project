/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

/**
 *
 * @author user
 */
public class Foursquare_SectionModel {
    
    private long id;
    private long menu_parts_id;
    private long entries_count;
    private String section_name;
    private String sectionId;
    private String description;
    
    public Foursquare_SectionModel(){
        
    }

    public Foursquare_SectionModel(long id, long menu_parts_id, long entries_count, String section_name,String sectionId, String description) {
        this.id = id;
        this.menu_parts_id = menu_parts_id;
        this.entries_count = entries_count;
        this.section_name = section_name;
        this.sectionId=sectionId;
        this.description = description;
    }

   //relation
    private Foursquare_EntryModel entryModel=null;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getMenu_parts_id() {
        return menu_parts_id;
    }

    public void setMenu_parts_id(long menu_parts_id) {
        this.menu_parts_id = menu_parts_id;
    }

    public long getEntries_count() {
        return entries_count;
    }

    public void setEntries_count(long entries_count) {
        this.entries_count = entries_count;
    }

    public String getSection_name() {
        return section_name;
    }

    public void setSection_name(String section_name) {
        this.section_name = section_name;
    }

    public String getSectionId() {
        return sectionId;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }
    
    

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Foursquare_EntryModel getEntryModel() {
        return entryModel;
    }

    public void setEntryModel(Foursquare_EntryModel entryModel) {
        this.entryModel = entryModel;
    }

    @Override
    public String toString() {
        return "Foursquare_SectionModel{" + "id=" + id + ", menu_parts_id=" + menu_parts_id + ", entries_count=" + entries_count + ", section_name=" + section_name + ", sectionId=" + sectionId + ", description=" + description + ", entryModel=" + entryModel + '}';
    }


   

    public void print (){
        System.out.println("Section name: "+section_name+" and entries count: "+entries_count);
    }
}
