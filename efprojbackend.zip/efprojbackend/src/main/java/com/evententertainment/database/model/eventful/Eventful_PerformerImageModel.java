/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.eventful;

/**
 *
 * @author user
 */
public class Eventful_PerformerImageModel {

    private long id;
    private String api_id;
    private String image_url;
    private int width;
    private int height;
    private Long performer_id;

    public Eventful_PerformerImageModel() {
    }

    public Eventful_PerformerImageModel(long id, String api_id, String image_url, int width, int height, Long performer_id) {
        this.id = id;
        this.api_id = api_id;
        this.image_url = image_url;
        this.width = width;
        this.height = height;
        this.performer_id = performer_id;
    }

    public void print() {
//"Performer with id: " + performer_id +
        System.out.println(" and api id: " + api_id
                + " has the image with url: " + image_url);
        System.out.println("The width of image is : " + this.getWidth());
        System.out.println("The height of image is: " + this.getHeight());

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public Long getPerformer_id() {
        return performer_id;
    }

    public void setPerformer_id(Long performer_id) {
        this.performer_id = performer_id;
    }
    @Override
    public String toString() {
        return "Eventful_PerformerImageModel{" + "id=" + id + ", api_id=" + api_id + ", image_url=" + image_url + ", width=" + width + ", height=" + height + '}';
    }

}
