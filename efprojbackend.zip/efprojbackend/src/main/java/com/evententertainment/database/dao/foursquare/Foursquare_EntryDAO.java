/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.model.foursquare.Foursquare_EntryModel;
import java.util.List;

public interface Foursquare_EntryDAO {
    public List<Foursquare_EntryModel> list();

    public Foursquare_EntryModel find(long id);

    public int create(Foursquare_EntryModel c);

    public int update(Foursquare_EntryModel c);

    public int delete(long id);   
}
