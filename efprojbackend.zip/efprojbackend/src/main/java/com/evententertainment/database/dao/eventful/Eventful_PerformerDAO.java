/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_PerformerModel;
import java.util.List;

public interface Eventful_PerformerDAO {
    public List<Eventful_PerformerModel> list();

    public Eventful_PerformerModel find(long id);
    
    // public Eventful_PerformerModel find(String perf_name);
     
  
    public Eventful_PerformerModel find(String api_id);

    public int create(Eventful_PerformerModel c);

    public int update(Eventful_PerformerModel c);

    public int delete(long id);  

    public int deleteAll();
}
