/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

/**
 *
 * @author user
 */
public class Foursquare_Menu_PartsModel {

    private long id;
    private long venue_menu_id;
    private String menuId;
    private String name;
    private String description;
    private long sections_count;


    public Foursquare_Menu_PartsModel() {

    }

    //relationships
    private Foursquare_EntryModel entryModel = null;
    private Foursquare_SectionModel sectionModel=null;

    public Foursquare_Menu_PartsModel(long id, long venue_menu_id, String menuId, String name, String description, long sections_count) {
        this.id = id;
        this.venue_menu_id = venue_menu_id;
        this.menuId = menuId;
        this.name = name;
        this.description = description;
        this.sections_count = sections_count;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVenue_menu_id() {
        return venue_menu_id;
    }

    public void setVenue_menu_id(long venue_menu_id) {
        this.venue_menu_id = venue_menu_id;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getSections_count() {
        return sections_count;
    }

    public void setSections_count(long sections_count) {
        this.sections_count = sections_count;
    }

    public Foursquare_EntryModel getEntryModel() {
        return entryModel;
    }

    public void setEntryModel(Foursquare_EntryModel entryModel) {
        this.entryModel = entryModel;
    }

    public Foursquare_SectionModel getSectionModel() {
        return sectionModel;
    }

    public void setSectionModel(Foursquare_SectionModel sectionModel) {
        this.sectionModel = sectionModel;
    }

    @Override
    public String toString() {
        return "Foursquare_Menu_PartsModel{" + "id=" + id + ", venue_menu_id=" + venue_menu_id + ", menuId=" + menuId + ", name=" + name + ", description=" + description + ", sections_count=" + sections_count + ", entryModel=" + entryModel + ", sectionModel=" + sectionModel + '}';
    }

  

  

    public void print() {
        System.out.println("The menu we present has id " + venue_menu_id + " and we can say a few wors. " + description + ". This menu is consisted of " + sections_count + " sections.");
    }

}
