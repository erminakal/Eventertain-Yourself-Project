/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_Performer_Has_Eventful_Event_CategoryModel;
import java.util.List;
 
public interface Eventful_Performer_Has_Eventful_Event_CategoryDAO {
    public List<Eventful_Performer_Has_Eventful_Event_CategoryModel> list();

    public Eventful_Performer_Has_Eventful_Event_CategoryModel find(long eventful_performer_id);

    public int create(Eventful_Performer_Has_Eventful_Event_CategoryModel c);

    public int update(Eventful_Performer_Has_Eventful_Event_CategoryModel c);

    public int delete(long eventful_performer_id); 
}
