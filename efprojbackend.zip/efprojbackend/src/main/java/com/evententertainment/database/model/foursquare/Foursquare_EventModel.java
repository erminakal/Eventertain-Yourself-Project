/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

import java.util.ArrayList;

public class Foursquare_EventModel {

    private long id;
    private String api_id;
    private String name;
    private String url;
    private String startAt;
    private String endAt;
    private boolean allDay;
    private long venue_id;

    public Foursquare_EventModel() {

    }

    public Foursquare_EventModel(long id, String api_id, String name, String url, String startAt, String endAt, boolean allDay, long venue_id) {
        this.id = id;
        this.api_id = api_id;
        this.name = name;
        this.url = url;
        this.startAt = startAt;
        this.endAt = endAt;
        this.allDay = allDay;
        this.venue_id = venue_id;
    }

    //relationships
    private ArrayList<Foursquare_CategoryModel> categories = new ArrayList<>();
    private Foursquare_Event_Has_Foursquare_CategoryModel fecModel = null;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getStartAt() {
        return startAt;
    }

    public void setStartAt(String startAt) {
        this.startAt = startAt;
    }

    public String getEndAt() {
        return endAt;
    }

    public void setEndAt(String endAt) {
        this.endAt = endAt;
    }

    public boolean isAllDay() {
        return allDay;
    }

    public void setAllDay(boolean allDay) {
        this.allDay = allDay;
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }

    public ArrayList<Foursquare_CategoryModel> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<Foursquare_CategoryModel> categories) {
        this.categories = categories;
    }

    public Foursquare_Event_Has_Foursquare_CategoryModel getFecModel() {
        return fecModel;
    }

    public void setFecModel(Foursquare_Event_Has_Foursquare_CategoryModel fecModel) {
        this.fecModel = fecModel;
    }

    @Override
    public String toString() {
        return "Foursquare_EventModel{" + "id=" + id + ", api_id=" + api_id + ", name=" + name + ", url=" + url + ", startAt=" + startAt + ", endAt=" + endAt + ", allDay=" + allDay + ", venue_id=" + venue_id + ", categories=" + categories + ", fecModel=" + fecModel + '}';
    }


    public void print() {
        System.out.println("In the venue with id: " + venue_id + " will happen the event: " + name + " which will start at "
                + startAt + " and end at " + endAt + ". You can find more information here: " + url + ".");
    }

}
