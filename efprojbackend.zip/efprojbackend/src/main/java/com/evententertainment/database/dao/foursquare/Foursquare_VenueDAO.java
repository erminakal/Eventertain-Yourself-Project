/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

/**
 *
 * @author user
 */
import com.evententertainment.database.model.foursquare.Foursquare_VenueModel;
import java.util.List;

public interface Foursquare_VenueDAO {
    public List<Foursquare_VenueModel> list();

    public Foursquare_VenueModel find(long id);

     public Foursquare_VenueModel find(String api_id);
    
    public int create(Foursquare_VenueModel c);

    public int update(Foursquare_VenueModel c);

    public int delete(long id);   
}
