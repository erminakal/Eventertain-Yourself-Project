/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.eventful;

/**
 *
 * @author user
 */
public class Eventful_Venue_Connect_Venue_CategoryModel {

    private Long eventful_venue_id;
    private Long eventful_venue_category_id;

  
// relationships:
    public Eventful_Venue_Connect_Venue_CategoryModel() {
    }

    public Eventful_Venue_Connect_Venue_CategoryModel(Long eventful_venue_id, Long eventful_venue_category_id) {
        this.eventful_venue_id = eventful_venue_id;
        this.eventful_venue_category_id = eventful_venue_category_id;
    }


    public Long getEventful_venue_id() {
        return eventful_venue_id;
    }

    public void setEventful_venue_id(Long eventful_venue_id) {
        this.eventful_venue_id = eventful_venue_id;
    }

    public Long getEventful_venue_category_id() {
        return eventful_venue_category_id;
    }

    public void setEventful_venue_category_id(Long eventful_venue_category_id) {
        this.eventful_venue_category_id = eventful_venue_category_id;
    }

    @Override
    public String toString() {
        return "Eventful_Venue_Connect_Venue_CategoryModel{" + "eventful_venue_id=" + eventful_venue_id + ", eventful_venue_category_id=" + eventful_venue_category_id + '}';
    }

  

   
  




    
}
