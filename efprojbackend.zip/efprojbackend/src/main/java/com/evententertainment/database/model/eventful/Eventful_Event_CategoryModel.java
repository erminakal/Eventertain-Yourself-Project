package com.evententertainment.database.model.eventful;

import com.evententertainment.database.model.ee.EE_Venue_Category_Has_Eventful_CategoryModel;
import com.evententertainment.database.model.ee.EE_Venue_Category_Has_Foursquare_CategoryModel;

public class Eventful_Event_CategoryModel {

    private long id;
    private String api_id;
    private String name;

    // relationships:
    private Eventful_EventHasCategoryModel ehcModel = null;

      private EE_Venue_Category_Has_Eventful_CategoryModel cecModel=null;

    private EE_Venue_Category_Has_Foursquare_CategoryModel cfcModel = null;

    
    private Eventful_Performer_Has_Eventful_Event_CategoryModel phcModel = null;
    
    public Eventful_Event_CategoryModel() {
    }

    public Eventful_Event_CategoryModel(long id, String api_id, String name) {

        this.id = id;
        this.api_id = api_id;
        this.name = name;

    }

    public void print() {
        System.out.println("Name of category: " + this.getApi_id());
        System.out.println("Description of category: " + this.getName());
        System.out.println("-----------------------------------------------");

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Eventful_EventHasCategoryModel getEhcModel() {
        return ehcModel;
    }

    public void setEhcModel(Eventful_EventHasCategoryModel ehcModel) {
        this.ehcModel = ehcModel;
    }

    public EE_Venue_Category_Has_Eventful_CategoryModel getCecModel() {
        return cecModel;
    }

    public void setCecModel(EE_Venue_Category_Has_Eventful_CategoryModel cecModel) {
        this.cecModel = cecModel;
    }

    public EE_Venue_Category_Has_Foursquare_CategoryModel getCfcModel() {
        return cfcModel;
    }

    public void setCfcModel(EE_Venue_Category_Has_Foursquare_CategoryModel cfcModel) {
        this.cfcModel = cfcModel;
    }

    public Eventful_Performer_Has_Eventful_Event_CategoryModel getPhcModel() {
        return phcModel;
    }

    public void setPhcModel(Eventful_Performer_Has_Eventful_Event_CategoryModel phcModel) {
        this.phcModel = phcModel;
    }

    @Override
    public String toString() {
        return "Eventful_Event_CategoryModel{" + "id=" + id + ", api_id=" + api_id + ", name=" + name + ", ehcModel=" + ehcModel + ", cecModel=" + cecModel + ", cfcModel=" + cfcModel + ", phcModel=" + phcModel + '}';
    }

  
    
   

}
