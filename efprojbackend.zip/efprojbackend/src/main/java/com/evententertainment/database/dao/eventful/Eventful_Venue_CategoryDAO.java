/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_Venue_CategoryModel;
import java.util.List;

public interface Eventful_Venue_CategoryDAO {
    public List<Eventful_Venue_CategoryModel> list();

    public Eventful_Venue_CategoryModel find(long id);
    
    public Eventful_Venue_CategoryModel find(String venue_type_new);

    public int create(Eventful_Venue_CategoryModel c);

    public int update(Eventful_Venue_CategoryModel c);

    public int delete(long id);  
    
     public int deleteAll();
}
