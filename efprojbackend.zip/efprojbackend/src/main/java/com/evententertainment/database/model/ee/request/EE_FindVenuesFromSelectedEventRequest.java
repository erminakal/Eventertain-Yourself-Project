/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.request;

/**
 *
 * @author user
 */
public class EE_FindVenuesFromSelectedEventRequest {

    private String eventApiId;
    private Long  selectedVenueCategory;
    private double latitude;
    private double longitude;
    private double distance;

    public EE_FindVenuesFromSelectedEventRequest() {
    }

    public EE_FindVenuesFromSelectedEventRequest(String eventApiId, Long selectedVenueCategory, double latitude, double longitude, double distance) {
        this.eventApiId = eventApiId;
        this.selectedVenueCategory = selectedVenueCategory;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
    }

  




    public String getEventApiId() {
        return eventApiId;
    }

    public void setEventApiId(String eventApiId) {
        this.eventApiId = eventApiId;
    }

//    public long getVenue_id() {
//        return venue_id;
//    }
//
//    public void setVenue_id(long venue_id) {
//        this.venue_id = venue_id;
//    }


    

    public Long getSelectedVenueCategory() {
        return selectedVenueCategory;
    }

    public void setSelectedVenueCategory(Long selectedVenueCategory) {
        this.selectedVenueCategory = selectedVenueCategory;
    }

   

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    @Override
    public String toString() {
        return "EE_FindVenuesFromSelectedEventRequest{" + "eventApiId=" + eventApiId + ", selectedVenueCategory=" + selectedVenueCategory + ", latitude=" + latitude + ", longitude=" + longitude + ", distance=" + distance + '}';
    }





   

  

  


    


}
