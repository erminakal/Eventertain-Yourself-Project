package com.evententertainment.database.model.foursquare;

import com.evententertainment.database.model.foursquare.Foursquare_CategoryModel;
import java.util.ArrayList;

public class Foursquare_VenueHasCategoryModel {

    private long venue_id;
    private long category_id;

    public Foursquare_VenueHasCategoryModel(long venue_id, long category_id) {
        this.venue_id = venue_id;
        this.category_id = category_id;
    }
   
   
    public void print() {
        System.out.println("Venue with id: "+this.getVenue_id()+" belongs to the category id: "+this.getCategory_id());
    }

  
    public Foursquare_VenueHasCategoryModel() {
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }

    public long getCategory_id() {
        return category_id;
    }

    public void setCategory_id(long category_id) {
        this.category_id = category_id;
    }

    @Override
    public String toString() {
        return "Foursquare_Venue_Has_Foursquare_SubcategoryModel{" + "venue_id=" + venue_id + ", category_id=" + category_id + '}';
    }

    
 }
