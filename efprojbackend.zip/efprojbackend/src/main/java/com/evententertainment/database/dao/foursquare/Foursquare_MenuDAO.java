/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

/**
 *
 * @author user
 */
import com.evententertainment.database.model.foursquare.Foursquare_MenuModel;
import java.util.List;

public interface Foursquare_MenuDAO {
    public List<Foursquare_MenuModel> list();

    public Foursquare_MenuModel find(long id);

    public int create(Foursquare_MenuModel c);

    public int update(Foursquare_MenuModel c);

    public int delete(long id);   
}
