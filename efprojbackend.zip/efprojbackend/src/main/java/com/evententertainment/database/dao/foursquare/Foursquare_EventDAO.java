/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.model.foursquare.Foursquare_EventModel;
import java.util.List;

public interface Foursquare_EventDAO {
    
    public List<Foursquare_EventModel> list();

    public Foursquare_EventModel find(long id);
    
     public Foursquare_EventModel find(String api_id);

    public int create(Foursquare_EventModel c);

    public int update(Foursquare_EventModel c);

    public int delete(long id);  
    
}
