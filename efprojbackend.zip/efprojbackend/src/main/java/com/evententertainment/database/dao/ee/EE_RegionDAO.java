/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.EE_RegionModel;
import java.util.List;

public interface EE_RegionDAO {

    public List<EE_RegionModel> listByName();

    public EE_RegionModel find(long id);
    
    public EE_RegionModel findByName(String name);

    public int create(EE_RegionModel c);

    public int update(EE_RegionModel c);

    public int delete(long id);

}
