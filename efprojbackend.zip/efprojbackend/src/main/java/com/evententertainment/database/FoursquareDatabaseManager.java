package com.evententertainment.database;

import com.evententertainment.database.dao.foursquare.Foursquare_ContactDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_EntryDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_EventDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_LocationDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_MenuDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_Menu_PartsDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_OperationDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_CategoryDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_SectionDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_VenueDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_VenueHasCategoryDAOImpl;

import com.evententertainment.database.model.foursquare.Foursquare_ContactModel;
import com.evententertainment.database.model.foursquare.Foursquare_EntryModel;
import com.evententertainment.database.model.foursquare.Foursquare_EventModel;
import com.evententertainment.database.model.foursquare.Foursquare_LocationModel;
import com.evententertainment.database.model.foursquare.Foursquare_MenuModel;
import com.evententertainment.database.model.foursquare.Foursquare_Menu_PartsModel;
import com.evententertainment.database.model.foursquare.Foursquare_OperationModel;
import com.evententertainment.database.model.foursquare.Foursquare_CategoryModel;
import com.evententertainment.database.model.foursquare.Foursquare_SectionModel;
import com.evententertainment.database.model.foursquare.Foursquare_VenueModel;
import com.evententertainment.database.model.foursquare.Foursquare_VenueHasCategoryModel;

import com.evententertainment.database.dao.foursquare.Foursquare_ContactDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_EntryDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_EventDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_LocationDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_MenuDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_Menu_PartsDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_OperationDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_SectionDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_VenueDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_CategoryDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_Event_Has_Foursquare_CategoryDAO;
import com.evententertainment.database.dao.foursquare.Foursquare_Event_Has_Foursquare_CategoryDAOImpl;
import com.evententertainment.database.dao.foursquare.Foursquare_VenueHasCategoryDAO;
import com.evententertainment.database.model.foursquare.Foursquare_Event_Has_Foursquare_CategoryModel;

import java.util.ArrayList;

public class FoursquareDatabaseManager {

    public void insertVenues(ArrayList<Foursquare_VenueModel> venue) {

        Foursquare_VenueDAO vdao = new Foursquare_VenueDAOImpl();
        Foursquare_LocationDAO ldao = new Foursquare_LocationDAOImpl();
        Foursquare_ContactDAO cdao = new Foursquare_ContactDAOImpl();
        Foursquare_OperationDAO opdao = new Foursquare_OperationDAOImpl();
        Foursquare_EventDAO fedao = new Foursquare_EventDAOImpl();
        Foursquare_VenueHasCategoryDAO vhcdao = new Foursquare_VenueHasCategoryDAOImpl();
        Foursquare_CategoryDAO catdao = new Foursquare_CategoryDAOImpl();
        Foursquare_Event_Has_Foursquare_CategoryDAO fecdao = new Foursquare_Event_Has_Foursquare_CategoryDAOImpl();

        for (Foursquare_VenueModel v : venue) {

            if (vdao.find(v.getApi_id()) != null) {
                System.out.println("This venue already exists");
            } else {
                vdao.create(v);

                ArrayList<Foursquare_CategoryModel> categories = v.getCategories();

                for (Foursquare_CategoryModel c : categories) {

                    String cat_api_id = c.getApi_id();
                    Foursquare_CategoryModel category = catdao.find(cat_api_id);
                    System.out.println("The category is: " + category);
                    if (category != null) {
                        long category_id = category.getId();
                        System.out.println(category_id + " is the category id.");
                        Foursquare_VenueHasCategoryModel vhc = new Foursquare_VenueHasCategoryModel();
                        vhc.setVenue_id(v.getId());
                        vhc.setCategory_id(category_id);
                        vhcdao.create(vhc);
                    } else {
                        catdao.create(c);

                        Foursquare_VenueHasCategoryModel vhc = new Foursquare_VenueHasCategoryModel();
                        vhc.setVenue_id(v.getId());
                        vhc.setCategory_id(c.getId());
                        vhcdao.create(vhc);
                        System.out.println("#####45");
                        System.out.println("New category inserted.");
                    }
               
                }

                Foursquare_EventModel eventModel = v.getEventModel();
                if (eventModel != null) {
                    eventModel.setVenue_id(v.getId());
                    fedao.create(eventModel);
                    System.out.println(eventModel);

                    for (Foursquare_CategoryModel c : categories) {

                        String cat_api_id = c.getApi_id();
                        Foursquare_CategoryModel category = catdao.find(cat_api_id);
                        System.out.println("The category is: " + category);
                        if (category != null) {
                            long category_id = category.getId();
                            System.out.println(category_id + " is the category id.");

                            Foursquare_Event_Has_Foursquare_CategoryModel fec = eventModel.getFecModel();

                            fec.setFoursquare_event_id(eventModel.getId());
                            fec.setFoursquare_category_id(category_id);
                            fecdao.create(fec);
                        } else {
                            catdao.create(c);
                            Foursquare_Event_Has_Foursquare_CategoryModel fec = eventModel.getFecModel();

                            fec.setFoursquare_event_id(eventModel.getId());
                            fec.setFoursquare_category_id(c.getId());
                            fecdao.create(fec);
                            System.out.println("#####65");
                            System.out.println("New category inserted.");
                        }
                    }
                } else {
                    eventModel = null;
                    System.out.println("There are no events at this place.");
                }
                if (eventModel.getId() == 0) {
                    System.out.println("**** 87");
                }

                Foursquare_LocationModel locationModel = v.getLocationModel();
                if (locationModel != null) {

                    locationModel.setVenue_id(v.getId());
                    ldao.create(locationModel);
                    System.out.println(locationModel);
                } else {
                    locationModel = null;
                    System.out.println("There is no location for this venue.");

                }

                Foursquare_ContactModel contactModel = v.getContactModel();
                if (contactModel != null) {

                    contactModel.setVenue_id(v.getId());
                    cdao.create(contactModel);

                } else {
                    contactModel = null;
                    System.out.println("There is no contact for this venue.");

                }

                Foursquare_OperationModel operationModel = v.getOperationModel();
                if (operationModel != null) {

                    operationModel.setVenue_id(v.getId());
                    opdao.create(operationModel);
                    System.out.println(operationModel);
                } else {
                    System.out.println("There are no operation Data");

                }

                Foursquare_MenuDAO mdao = new Foursquare_MenuDAOImpl();
                Foursquare_Menu_PartsDAO mpdao = new Foursquare_Menu_PartsDAOImpl();
                Foursquare_SectionDAO sdao = new Foursquare_SectionDAOImpl();
                Foursquare_EntryDAO edao = new Foursquare_EntryDAOImpl();

                Foursquare_MenuModel menuModel = new Foursquare_MenuModel();

                if (menuModel != null) {

                    menuModel.setVenue_id(v.getId());
                    mdao.create(menuModel);
                    if (menuModel.getId() == 0) {
                        System.out.println("##### 16");
                        System.exit(1);
                    }
                    Foursquare_Menu_PartsModel menu_partsModel = new Foursquare_Menu_PartsModel();
                    if (menu_partsModel != null) {
                        menu_partsModel.setVenue_menu_id(menuModel.getId());
                        mpdao.create(menu_partsModel);

                        if (menu_partsModel.getId() == 0) {
                            System.out.println("##### 17");
                            System.exit(1);
                        }

                    }
                    Foursquare_SectionModel sectionModel = new Foursquare_SectionModel();
                    Foursquare_EntryModel entryModel = new Foursquare_EntryModel();
                    if (sectionModel != null) {
                        sectionModel.setMenu_parts_id(menu_partsModel.getId());
                        sdao.create(sectionModel);
                        if (sectionModel.getId() == 0) {
                            System.out.println("##### 18");
                            System.exit(1);
                        }

                        if (entryModel != null) {
                            entryModel.setSection_id(sectionModel.getId());
                            edao.create(entryModel);
                            if (entryModel.getId() == 0) {
                                System.out.println("##### 19");
                                System.exit(1);
                            }

                        }

                    }
                }

            }
        }
    }
    //   public void insertEvents(ArrayList<Foursquare_EventModel>event){
    //   Foursquare_EventDAO fdao=new Foursquare_EventDAOImpl();
    //   
    //   for (Foursquare_EventModel fe : event){
    //   
    //   if (fdao.find(fe.getApi_id())!=null){
    //   System.out.println("This event already exists");
    //   }
    //   else {
    //       
    //       
    //   fdao.create(fe);
    //   
    //   }
    //   
    //   }
    //   
    //   
    //   }

    public void insertCategory(long parent_category_id, ArrayList<Foursquare_CategoryModel> category) {
        Foursquare_CategoryDAO cdao = new Foursquare_CategoryDAOImpl();

        for (Foursquare_CategoryModel c : category) {
            if (parent_category_id == 0) {
                c.setParent_category_id(null);
            } else {
                c.setParent_category_id(parent_category_id);
                //String parent_name = c.getName();
            }
            //System.out.println("The category " + c.getName() + " has as parent category: " + parent_category_id);
            if (c != null) {
                cdao.create(c);

                if (c.getId() == 0) {
                    System.out.println("#####2");
                    System.exit(1);
                }

            }

            ArrayList<Foursquare_CategoryModel> subcategories = c.getSubcategories();

            if (subcategories != null) {

                for (Foursquare_CategoryModel subcategory : subcategories) {
                    //snum += 1;
                    ArrayList<Foursquare_CategoryModel> templist = new ArrayList<>();
                    templist.add(subcategory);
                    insertCategory(c.getId(), templist);
                    //SubcategoriesNumber();

                }

            }

        }

    }

    public static long SubcategoriesNumber() {
        long num = 0;
        num += 1;

        return num;
    }
}
