/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

/**
 *
 * @author user
 */
import com.evententertainment.database.model.foursquare.Foursquare_Menu_PartsModel;
import java.util.List;

public interface Foursquare_Menu_PartsDAO {
    public List<Foursquare_Menu_PartsModel> list();

    public Foursquare_Menu_PartsModel find(long id);

    public int create(Foursquare_Menu_PartsModel c);

    public int update(Foursquare_Menu_PartsModel c);

    public int delete(long id);   
}
