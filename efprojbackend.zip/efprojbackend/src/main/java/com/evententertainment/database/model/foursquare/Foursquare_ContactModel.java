/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

/**
 *
 * @author user
 */
public class Foursquare_ContactModel {

    private long id;
    private long venue_id;
    private String phone;
    private String formattedPhone;
    private String instagram;
    private String twitter;
    private String facebook;
    private String facebookUsername;
    private String facebookName;

    public Foursquare_ContactModel() {

    }

    public void print() {
        System.out.println("The venue's phone is: " + phone + " and you can contact with it through instagram at " + instagram + ", through twitter at "
                + twitter + " and in facebook at " + facebook);
        System.out.println("you can contact with it through instagram at " + instagram );
    }

    public Foursquare_ContactModel(long id, long venue_id,String phone, String formattedPhone, String instagram, String twitter, String facebook, String facebookUsername, String facebookName) {
        this.id = id;
        this.venue_id=id;
        this.phone = phone;
        this.formattedPhone = formattedPhone;
        this.instagram = instagram;
        this.twitter = twitter;
        this.facebook = facebook;
        this.facebookUsername = facebookUsername;
        this.facebookName = facebookName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }
    
    

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFormattedPhone() {
        return formattedPhone;
    }

    public void setFormattedPhone(String formattedPhone) {
        this.formattedPhone = formattedPhone;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getFacebookUsername() {
        return facebookUsername;
    }

    public void setFacebookUsername(String facebookUsername) {
        this.facebookUsername = facebookUsername;
    }

    public String getFacebookName() {
        return facebookName;
    }

    public void setFacebookName(String facebookName) {
        this.facebookName = facebookName;
    }

    @Override
    public String toString() {
        return "Foursquare_ContactModel{" + "id=" + id + ", venue_id=" + venue_id + ", phone=" + phone + ", formattedPhone=" + formattedPhone + ", instagram=" + instagram + ", twitter=" + twitter + ", facebook=" + facebook + ", facebookUsername=" + facebookUsername + ", facebookName=" + facebookName + '}';
    }

}
