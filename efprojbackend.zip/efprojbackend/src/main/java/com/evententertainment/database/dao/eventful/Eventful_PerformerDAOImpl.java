/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_PerformerModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_PerformerDAOImpl implements Eventful_PerformerDAO {

    private static final String TABLE = "eventful_performer";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    // private static final String SQL_FIND_BY_PERFORMER_NAME = "SELECT * FROM " + TABLE + " WHERE `name` like ?";
    private static final String SQL_FIND_BY_API_ID = "SELECT * FROM " + TABLE + " WHERE `api_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`api_id`,`url`,`vanity_url`,`name`,`is_human`,"
            + "`short_bio`,`long_bio`,`created`,`creator`,`demand_count`,`demand_member_count`,`event_count`,`category`,"
            + "`withdrawn`,`withdrawn_note`) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`api_id`,`url`,`vanity_url`,`name`,`is_human`,"
            + "`short_bio`,`long_bio`,`created`,`creator`,`demand_count`,`demand_member_count`,`event_count`,`category`,"
            + "`withdrawn`,`withdrawn_note`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_DELETE_ALL = "DELETE FROM " + TABLE;

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_PerformerModel map(ResultSet resultSet) throws SQLException {
        Eventful_PerformerModel object = new Eventful_PerformerModel();

        object.setId(resultSet.getLong("id"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setUrl(resultSet.getString("url"));
        object.setVanity_url(resultSet.getString("vanity_url"));
        object.setName(resultSet.getString("name"));
        object.setIs_human(resultSet.getBoolean("is_human"));
        object.setShort_bio(resultSet.getString("short_bio"));
        object.setLong_bio(resultSet.getString("long_bio"));
        object.setCreated(resultSet.getString("created"));
        object.setCreator(resultSet.getString("creator"));
        object.setDemand_count(resultSet.getLong("demand_count"));
        object.setDemand_member_count(resultSet.getLong("demand_member_count"));
        object.setEvent_count(resultSet.getLong("event_count"));
        object.setCategory(resultSet.getString("category"));
        object.setWithdrawn(resultSet.getBoolean("withdrawn"));
        object.setWithdrawn_note(resultSet.getString("withdrawn_note"));
        return object;
    }

    @Override
    public int deleteAll() {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_ALL);) {
            int affectedrows = statement.executeUpdate();
            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return 0;
        }

    }

    @Override
    public List<Eventful_PerformerModel> list() {
        List<Eventful_PerformerModel> performers = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                performers.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return performers;
    }

    @Override
    public Eventful_PerformerModel find(long id) {
        Eventful_PerformerModel performer = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                performer = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return performer;
    }

//    public Eventful_PerformerModel find(String name) {
//        Eventful_PerformerModel performer = null;
//
//        try (Connection connection = factory.getConnection();
//                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_PERFORMER_NAME, name);
//                ResultSet resultSet = statement.executeQuery();) {
//            if (resultSet.next()) {
//                performer = map(resultSet);
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return performer;
//    }
    public Eventful_PerformerModel find(String api_id) {
        Eventful_PerformerModel performer = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                performer = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return performer;
    }

//    public boolean Eventful_PerformerModel find(String api_id) {
//        Eventful_PerformerModel performer = null;
//        boolean result = false;
//        try (Connection connection = factory.getConnection();
//                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
//                ResultSet resultSet = statement.executeQuery();) {
//            if (resultSet.next()) {
//                performer = map(resultSet);
//                result = true;
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return result;
//    }
    @Override
    public int create(Eventful_PerformerModel c) {
        int ret = -1;

//        String createdTime;
//        if (c.getCreated() != null) {
//            java.util.Date dt = new java.util.Date(((int)(Float.parseFloat(c.getCreated()))));
//
//            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//
//            createdTime = sdf.format(dt);
//        } else {
//            java.util.Date dt = new java.util.Date();
//
//            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//
//            createdTime = sdf.format(dt);
//        }
        Object[] values = {c.getApi_id(), c.getUrl(), c.getVanity_url(), c.getName(), c.isIs_human(), c.getShort_bio(),
            c.getLong_bio(), c.getCreated(), c.getCreator(), c.getDemand_count(), c.getDemand_member_count(), c.getEvent_count(),
            c.getCategory(), c.isWithdrawn(), c.getWithdrawn_note()};
//createdTime
        String error = "";

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            error = statement.toString();

            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            System.err.println("SQL statement:" + error);
            System.exit(-1);
            return -1;
        }
    }

    @Override
    public int update(Eventful_PerformerModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getApi_id(), c.getUrl(), c.getVanity_url(), c.getName(), c.isIs_human(), c.getShort_bio(),
                        c.getLong_bio(), c.getCreated(), c.getCreator(), c.getDemand_count(), c.getDemand_member_count(), c.getEvent_count(),
                        c.getCategory(), c.isWithdrawn(), c.getWithdrawn_note());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
