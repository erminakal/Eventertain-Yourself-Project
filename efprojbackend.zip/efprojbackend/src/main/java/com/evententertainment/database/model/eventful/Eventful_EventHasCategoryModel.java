/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.eventful;

/**
 *
 * @author user
 */
public class Eventful_EventHasCategoryModel {
    
    private long event_id;
   
    private long category_id;
    
    public Eventful_EventHasCategoryModel(){
    
}

    public Eventful_EventHasCategoryModel(long event_id, long category_id) {
        this.event_id = event_id;
      
        this.category_id = category_id;
    }
    
     public void print(){
        System.out.println("Event id: "+ this.getEvent_id());
        System.out.println("Category name: "+ this.getCategory_id());
    }

    public long getEvent_id() {
        return event_id;
    }

    public void setEvent_id(long event_id) {
        this.event_id = event_id;
    }

   

    public long getCategory_id() {
        return category_id;
    }

    public void setCategory_id(long category_id) {
        this.category_id = category_id;
    }

    @Override
    public String toString() {
        return "Eventful_EventHasCategoryModel{" + "event_id=" + event_id + ", category_id=" + category_id + '}';
    }

    public void setCategory_id(Eventful_Event_CategoryModel category_id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
}
