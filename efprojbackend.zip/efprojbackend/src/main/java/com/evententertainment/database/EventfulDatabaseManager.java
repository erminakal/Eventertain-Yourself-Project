/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database;

import com.evententertainment.database.dao.eventful.Eventful_Event_CategoryDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_EventDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_Event_Has_CategoryDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_Event_Has_PerformerDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_PerformerDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_PerformerImageDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_VenueDAOImpl;
import com.evententertainment.database.dao.eventful.Eventful_Performer_Has_Eventful_Event_CategoryDAOImpl;

import com.evententertainment.database.dao.eventful.Eventful_EventDAO;
import com.evententertainment.database.dao.eventful.Eventful_Event_Has_CategoryDAO;
import com.evententertainment.database.dao.eventful.Eventful_Event_Has_PerformerDAO;
import com.evententertainment.database.dao.eventful.Eventful_PerformerDAO;
import com.evententertainment.database.dao.eventful.Eventful_PerformerImageDAO;
import com.evententertainment.database.dao.eventful.Eventful_VenueDAO;
import com.evententertainment.database.dao.eventful.Eventful_Performer_Has_Eventful_Event_CategoryDAO;
import com.evententertainment.database.dao.eventful.Eventful_Venue_CategoryDAOImpl;

import com.evententertainment.database.model.eventful.Eventful_EventModel;
import com.evententertainment.database.model.eventful.Eventful_VenueModel;
import com.evententertainment.database.model.eventful.Eventful_Event_CategoryModel;
import com.evententertainment.database.model.eventful.Eventful_EventHasCategoryModel;
import com.evententertainment.database.model.eventful.Eventful_EventHasPerformerModel;
import com.evententertainment.database.model.eventful.Eventful_Performer_Has_Eventful_Event_CategoryModel;
import com.evententertainment.database.model.eventful.Eventful_PerformerImageModel;
import com.evententertainment.database.model.eventful.Eventful_PerformerModel;
import com.evententertainment.database.model.eventful.Eventful_Venue_Connect_Venue_CategoryModel;
import com.evententertainment.database.model.eventful.Eventful_Venue_CategoryModel;

import java.util.ArrayList;
import com.evententertainment.database.dao.eventful.Eventful_Event_CategoryDAO;
import com.evententertainment.database.dao.eventful.Eventful_Venue_CategoryDAO;
import com.evententertainment.database.dao.eventful.Eventful_Venue_Connect_Venue_CategoryDAO;
import com.evententertainment.database.dao.eventful.Eventful_Venue_Connect_Venue_CategoryDAOImpl;

//eisagwgh sth Database
public class EventfulDatabaseManager {

    //eisagwgh categories me elegxo an uparxei hdh tsekarontas to api_id
    public void insertCategory(ArrayList<Eventful_Event_CategoryModel> category) {
        Eventful_Event_CategoryDAO cdao = new Eventful_Event_CategoryDAOImpl();

        for (Eventful_Event_CategoryModel c : category) {
            String api_id = c.getApi_id();
            if (cdao.find(api_id) != null) {
                System.out.println("This category already exists");
            } else {
                cdao.create(c);
            }
        }
    }
    //diagrafh categories

    public void deleteCategories() {
        Eventful_Event_CategoryDAO cdao = new Eventful_Event_CategoryDAOImpl();
        cdao.deleteAll();
    }

    //eisagwgh twn venues kai twn categories kai tou endiamesou me elegxo an uparxei hdh
    public void insertVenues(ArrayList<Eventful_VenueModel> venue) {

        Eventful_VenueDAO vdao = new Eventful_VenueDAOImpl();
        Eventful_Venue_CategoryDAO vtdao = new Eventful_Venue_CategoryDAOImpl();
        Eventful_Venue_Connect_Venue_CategoryDAO vctdao = new Eventful_Venue_Connect_Venue_CategoryDAOImpl();

        for (Eventful_VenueModel v : venue) {
            String api_id = v.getApi_id();
            if (vdao.find(api_id) != null) {

                System.out.println("This venue already exists");
            } else {
                vdao.create(v);
                Long venue_id = v.getId();
                String venue_category = v.getVenue_category();

                Eventful_Venue_CategoryModel vt = new Eventful_Venue_CategoryModel();
                if (vtdao.find(venue_category) != null) {
                    System.out.println("This venue category already exists");
                } else {
                    vt.setVenue_category(venue_category);
                    vtdao.create(vt);
                }
                Eventful_Venue_Connect_Venue_CategoryModel vct = new Eventful_Venue_Connect_Venue_CategoryModel();
                vct.setEventful_venue_id(venue_id);

                if (vt != null) {
                    Long venue_category_id = vt.getId();
                    if (venue_category_id != 0) {

                        vct.setEventful_venue_category_id(venue_category_id);

                        vctdao.create(vct);
                    }
                }
            }

        }
    }

    //eisagwgh twn performers ana category. tsekarontas prwta an yparxei o performer
    //hdh sth db. epishs, eisagwgh tou table PerformerHasCategory tsekarontas an
    //uparxei hdh to category ston antistoixo pinaka wste na "traviksei" id,name 
    //alliws ginetai create ston pinaka twn categories to neo category. 
    //epipleon, ginetai eisagwgh tou table performer_image.
    public void insertPerformers(ArrayList<Eventful_PerformerModel> performer) {

        Eventful_Event_CategoryDAO cdao = new Eventful_Event_CategoryDAOImpl();
        Eventful_Performer_Has_Eventful_Event_CategoryDAO phcdao = new Eventful_Performer_Has_Eventful_Event_CategoryDAOImpl();
        Eventful_PerformerDAO pdao = new Eventful_PerformerDAOImpl();
        Eventful_PerformerImageDAO pidao = new Eventful_PerformerImageDAOImpl();

        for (Eventful_PerformerModel p : performer) {
            String api_id = p.getApi_id();
            if (pdao.find(api_id) != null) {
                System.out.println("This performer already exists");
            } else {

                pdao.create(p);

                ArrayList<Eventful_Event_CategoryModel> categories = p.getCategories();

                for (Eventful_Event_CategoryModel c : categories) {

                    String cat_api_id = p.getCategory();
//elegxos an uparxei hdh to category sth db wste na to eisagei ston PerformerHasCategory

                    if (c != null) {
                        if (cdao.find(cat_api_id) != null) {
                            Eventful_Event_CategoryModel category = cdao.find(cat_api_id);
                            long category_id = category.getId();

                            Eventful_Performer_Has_Eventful_Event_CategoryModel phc = new Eventful_Performer_Has_Eventful_Event_CategoryModel();
                            phc.setEventful_performer_id(p.getId());
                            phc.setEventful_event_category_id(category_id);
                            phcdao.create(phc);
                        } //an den uparxei edw ton dhmiourgei prwta kai meta paei k to eisagei ston PHC
                        else {

                            cdao.create(c);
                            Eventful_Event_CategoryModel category = cdao.find(cat_api_id);

                            if (category != null) {
                                long category_id = category.getId();

                                Eventful_Performer_Has_Eventful_Event_CategoryModel phc = new Eventful_Performer_Has_Eventful_Event_CategoryModel();
                                phc.setEventful_performer_id(p.getId());
                                phc.setEventful_event_category_id(category_id);
                                phcdao.create(phc);
                            }
                        }
                    } else {
                        System.out.println("####88 ");
                        System.out.println("There is no category");
                    }
                    if (p.getId() == 0) {
                        System.out.println("##### 83-Something is not working!Id seems 0.");
                        System.exit(1);
                    }
                    Eventful_PerformerImageModel performerImageModel = p.getPerformerimageModel();

                    if (performerImageModel != null) {

                        performerImageModel.setPerformer_id(p.getId());
                        pidao.create(performerImageModel);
                    } else {
                        performerImageModel = null;
                        System.out.println("There is no image for this performer.");
                    }

                }
            }

        }

    }

    public void insertEvents(ArrayList<Eventful_EventModel> event) {

        Eventful_EventDAO edao = new Eventful_EventDAOImpl();
        Eventful_VenueDAO vdao = new Eventful_VenueDAOImpl();
        Eventful_Event_Has_CategoryDAO ehcdao = new Eventful_Event_Has_CategoryDAOImpl();
        Eventful_Event_CategoryDAO cdao = new Eventful_Event_CategoryDAOImpl();
        Eventful_Event_Has_PerformerDAO ehpdao = new Eventful_Event_Has_PerformerDAOImpl();
        Eventful_PerformerDAO pdao = new Eventful_PerformerDAOImpl();

        for (Eventful_EventModel e : event) {
            String event_api = e.getApi_id();
            String venue_api = e.getVenue_api_id();

            Eventful_VenueModel venue = vdao.find(venue_api);
            if (edao.find(event_api) != null) {
                if (venue != null) {
                    if (venue.getId() != null) {
                        Long venue_id = venue.getId();
                        e.setVenue_id(venue_id);
                    } else {
                        vdao.create(venue);
                        System.out.println("New venue inserted");
                    }
                }
            } else {
                System.out.println("Venue with API ID: " + venue_api + " not found ");

            }

            // begin transaction --veltistopoihsh ptuxiakhs
            edao.create(e);

            ArrayList<Eventful_Event_CategoryModel> categories = e.getCategories();

            for (Eventful_Event_CategoryModel c : categories) {

                String cat_name = c.getApi_id();
                Eventful_Event_CategoryModel category = cdao.find(cat_name);

                if (cdao.find(cat_name) != null) {
                    System.out.println("Category has been registered");
                    long category_id = category.getId();

                    Eventful_EventHasCategoryModel ehc = new Eventful_EventHasCategoryModel();
                    ehc.setEvent_id(e.getId());
                    ehc.setCategory_id(category_id);
                    ehcdao.create(ehc);
                    System.out.println("New category registration");
                } else {

                    System.out.println("#### 38");

                }
            }

            ArrayList<Eventful_PerformerModel> performers = e.getPerformers();

            for (Eventful_PerformerModel p : performers) {

                String perf_name = p.getName();
                Eventful_PerformerModel performer = pdao.find(perf_name);

                if (performer != null) {

                    long performer_id = performer.getId();

                    Eventful_EventHasPerformerModel ehp = new Eventful_EventHasPerformerModel();
                    ehp.setEvent_id(e.getId());
                    ehp.setPerformer_id(performer_id);
                    ehpdao.create(ehp);
                } else {

                    pdao.create(p);

                    Eventful_EventHasPerformerModel ehp = new Eventful_EventHasPerformerModel();
                    ehp.setEvent_id(e.getId());
                    ehp.setPerformer_id(p.getId());
                    ehpdao.create(ehp);

                    System.out.println("New performer inserted");
                }

            }

        }
    }

}
