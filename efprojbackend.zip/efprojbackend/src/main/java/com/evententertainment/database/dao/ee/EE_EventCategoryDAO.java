/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.EE_Event_CategoryModel;
import java.util.List;

public interface EE_EventCategoryDAO {
    // TODO + impl + test

     public List<EE_Event_CategoryModel> list();
     
     public List<EE_Event_CategoryModel> listByName();

    public EE_Event_CategoryModel find(long id);    

    public long create(EE_Event_CategoryModel c);

    public int update(EE_Event_CategoryModel c);

    public int delete(long id);   

    public int deleteAll();

    
 
}
