package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_OperationModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_OperationDAOImpl implements Foursquare_OperationDAO {

    private static final String TABLE = "foursquare_operation";
    private static final String SQL_LIST_ORDER_BY_VENUE_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_VENUE_ID = "SELECT * FROM " + TABLE + " WHERE `venue_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`venue_id`,`status`,`open`,`day`,`isOpen`) values (?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`venue_id`,`status`,`open`,`day`,`isOpen`) WHERE `venue_id` = ?";
    private static final String SQL_DELETE_BY_VENUE_ID = "DELETE FROM " + TABLE + " WHERE `venue_id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_OperationModel map(ResultSet resultSet) throws SQLException {
        Foursquare_OperationModel object = new Foursquare_OperationModel();

        object.setId(resultSet.getLong("id"));

        object.setVenue_id(resultSet.getLong("venue_id"));
        object.setStatus(resultSet.getString("status"));
        object.setOpen(resultSet.getString("open"));
        object.setDay(resultSet.getString("day"));
        object.setIsOpen(resultSet.getBoolean("isOpen"));

        return object;
    }

    @Override
    public List<Foursquare_OperationModel> list() {
        List<Foursquare_OperationModel> venues_hours = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_VENUE_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                venues_hours.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return venues_hours;
    }

    @Override
    public Foursquare_OperationModel find(long venue_id) {
        Foursquare_OperationModel venue_hours = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_VENUE_ID, venue_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue_hours = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue_hours;
    }

    @Override
    public int create(Foursquare_OperationModel c) {
        int ret = -1;
        Object[] values = {c.getVenue_id(), c.getStatus(), c.getOpen(),c.getDay(),  c.getIsOpen()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getLong(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_OperationModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getVenue_id(), c.getStatus(), c.getOpen(),c.getDay(),  c.getIsOpen());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long venue_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_VENUE_ID, venue_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
