package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_Event_Has_Foursquare_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_Event_Has_Foursquare_CategoryDAOImpl implements Foursquare_Event_Has_Foursquare_CategoryDAO {

    private static final String TABLE = "foursquare_event_has_foursquare_category";
    private static final String SQL_LIST_ORDER_BY_FOURSQUARE_EVENT_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_FOURSQUARE_EVENT_ID = "SELECT * FROM " + TABLE + " WHERE `foursquare_event_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`foursquare_event_id`,`foursquare_category_id`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`foursquare_event_id`,`foursquare_category_id`) WHERE `foursquare_event_id` = ?";
    private static final String SQL_DELETE_BY_FOURSQUARE_EVENT_ID = "DELETE FROM " + TABLE + " WHERE `foursquare_event_id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_Event_Has_Foursquare_CategoryModel map(ResultSet resultSet) throws SQLException {
        Foursquare_Event_Has_Foursquare_CategoryModel object = new Foursquare_Event_Has_Foursquare_CategoryModel();

        object.setFoursquare_event_id(resultSet.getLong("foursquare_event_id"));
        object.setFoursquare_category_id(resultSet.getLong("foursquare_category_id"));
   
        return object;
    }

    @Override
    public List<Foursquare_Event_Has_Foursquare_CategoryModel> list() {
        List<Foursquare_Event_Has_Foursquare_CategoryModel> events_category = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_FOURSQUARE_EVENT_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                events_category.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return events_category;
    }

    @Override
    public Foursquare_Event_Has_Foursquare_CategoryModel find(long foursquare_event_id) {
        Foursquare_Event_Has_Foursquare_CategoryModel event_category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_FOURSQUARE_EVENT_ID, foursquare_event_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                event_category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return event_category;
    }

    @Override
    public int create(Foursquare_Event_Has_Foursquare_CategoryModel c) {
        int ret = -1;
        Object[] values = {c.getFoursquare_event_id(), c.getFoursquare_category_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }
 return ret;
             } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_Event_Has_Foursquare_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE,c.getFoursquare_event_id(), c.getFoursquare_category_id());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long foursquare_event_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_FOURSQUARE_EVENT_ID, foursquare_event_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
