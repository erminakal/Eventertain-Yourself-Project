/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.response;

/**
 *
 * @author user
 */
public class EE_VenuesResponseModel {
    
    private long id;
    private String source;
    private String api_id;
    private String url;
    private String venue_name;
    private String description;
    private String category;
    private String address;
    private String postal_code;
    private String city_name;
    private String region_name;
    private String country_name;
    private float latitude;
    private float longitude;

    
    public EE_VenuesResponseModel() {
    }

    public EE_VenuesResponseModel(long id, String source, String api_id, String url, String venue_name, String description, String category, String address, String postal_code, String city_name, String region_name, String country_name, float latitude, float longitude) {
        this.id = id;
        this.source = source;
        this.api_id = api_id;
        this.url = url;
        this.venue_name = venue_name;
        this.description = description;
        this.category = category;
        this.address = address;
        this.postal_code = postal_code;
        this.city_name = city_name;
        this.region_name = region_name;
        this.country_name = country_name;
        this.latitude = latitude;
        this.longitude = longitude;
    }


   
   
  


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getVenue_name() {
        return venue_name;
    }

    public void setVenue_name(String venue_name) {
        this.venue_name =venue_name;
    }

 

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    
    
    
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }
    
    

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "EE_VenuesResponseModel{" + "id=" + id + ", source=" + source + ", api_id=" + api_id + ", url=" + url + ",venue_name=" +venue_name + ", description=" + description + ", category=" + category + ", address=" + address + ", postal_code=" + postal_code + ", city_name=" + city_name + ", region_name=" + region_name + ", country_name=" + country_name + ", latitude=" + latitude + ", longitude=" + longitude + '}';
    }


      
        
    
 }
