
package com.evententertainment.database.model.foursquare;


public class Foursquare_LocationModel {

    private long id;
    private long venue_id;
    private String address;
    private String crossStreet;
    private double latitude;
    private double longitude;
    private long distance;
    private String postalCode;
    private String cc;
    private String city;
    private String state;
    private String country;

  

    public void print() {
        System.out.println("The venue you look for is at: " + address + " and " + crossStreet + " of city: " + city + " and state " + state + " in " + country
                + ". The postal code is: " + postalCode + " and the distance from the venue is " + distance + " meters. ");
    }

    public Foursquare_LocationModel() {

    }

    public Foursquare_LocationModel(long id, long venue_id, String address, String crossStreet, double latitude, double longitude, long distance, String postalCode, String cc, String city, String state, String country) {
        this.id = id;
        this.venue_id = venue_id;
        this.address = address;
        this.crossStreet = crossStreet;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
        this.postalCode = postalCode;
        this.cc = cc;
        this.city = city;
        this.state = state;
        this.country = country;
 
    
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }
    
    

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCrossStreet() {
        return crossStreet;
    }

    public void setCrossStreet(String crossStreet) {
        this.crossStreet = crossStreet;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public long getDistance() {
        return distance;
    }

    public void setDistance(long distance) {
        this.distance = distance;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCc() {
        return cc;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Foursquare_LocationModel{" + "id=" + id + ", venue_id=" + venue_id + ", address=" + address + ", crossStreet=" + crossStreet + ", latitude=" + latitude + ", longitude=" + longitude + ", distance=" + distance + ", postalCode=" + postalCode + ", cc=" + cc + ", city=" + city + ", state=" + state + ", country=" + country + '}';
    }



  
}
