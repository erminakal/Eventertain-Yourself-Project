/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_VenueModel;
import java.util.List;

public interface Eventful_VenueDAO {
    public List<Eventful_VenueModel> list();

    public Eventful_VenueModel find(long id);
    
    public Eventful_VenueModel find(String api_id);

    public int create(Eventful_VenueModel c);

    public int update(Eventful_VenueModel c);

    public int delete(long id);    
}
