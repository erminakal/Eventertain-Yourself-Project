package com.evententertainment.database.model.foursquare;

public class Foursquare_OperationModel {

    private long id;
    private long venue_id;
    private String status;
    private String open;
    private String day;

    private Boolean isOpen;

    public Foursquare_OperationModel() {

    }

    public void print() {

        System.out.println("On " + day + " the venue is open between the hours: " + open);
        System.out.println("Today it is: " + status);
        if (isOpen == true) {
            System.out.println("Today it is open");
        } else {
            System.out.println("Today it is closed");
        }

    }

    public Foursquare_OperationModel(long id, long venue_id, String day, String open, String status, Boolean isOpen) {
        this.id = id;
        this.venue_id = venue_id;
        this.day = day;
        this.open = open;
        this.status = status;
        this.isOpen = isOpen;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getOpen() {
        return open;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getIsOpen() {
        return isOpen;
    }

    public void setIsOpen(Boolean isOpen) {
        this.isOpen = isOpen;
    }

    @Override
    public String toString() {
        return "Foursquare_OperationModel{" + "id=" + id + ", venue_id=" + venue_id + ", day=" + day + ", open=" + open + ", status=" + status + ", isOpen=" + isOpen + '}';
    }

}
