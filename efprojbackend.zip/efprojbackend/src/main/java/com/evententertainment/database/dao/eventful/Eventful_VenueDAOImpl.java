/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_VenueModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_VenueDAOImpl implements Eventful_VenueDAO {

    private static final String TABLE = "eventful_venue";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_FIND_BY_API_ID = "SELECT * FROM " + TABLE + " WHERE `api_id` like ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`api_id`,`url`,`name`,`description`,`venue_category`,`address`"
            + ",`city_name`,`region_name`,`postal_code`,`country_name`,`latitude`,`longitude`,"
            + "`geocode_type`,`created`) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`api_id`,`url`,`name`,`description`,`venue_category`,`address`"
            + ",`city_name`,`region_name`,`postal_code`,`country_name`,`latitude`,`longitude`"
            + "`geocode_type`,`created`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_VenueModel map(ResultSet resultSet) throws SQLException {
        Eventful_VenueModel object = new Eventful_VenueModel();

        object.setId(resultSet.getLong("id"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setUrl(resultSet.getString("url"));
        object.setName(resultSet.getString("name"));
        object.setDescription(resultSet.getString("description"));
        object.setVenue_category(resultSet.getString("venue_category"));
        object.setAddress(resultSet.getString("address"));
        object.setCity_name(resultSet.getString("city_name"));
        object.setRegion_name(resultSet.getString("region_name"));
        object.setPostal_code(resultSet.getString("postal_code"));
        object.setCountry_name(resultSet.getString("country_name"));
        object.setLatitude(resultSet.getFloat("latitude"));
        object.setLongitude(resultSet.getFloat("longitude"));
        object.setGeocode_type(resultSet.getString("geocode_type"));

        object.setCreated(resultSet.getString("created"));

        return object;
    }

    @Override
    public List<Eventful_VenueModel> list() {
        List<Eventful_VenueModel> venues = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                venues.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return venues;
    }

    @Override
    public Eventful_VenueModel find(long id) {
        Eventful_VenueModel venue = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue;
    }

    @Override
    public Eventful_VenueModel find(String api_id) {
        Eventful_VenueModel venue = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue;
    }

    @Override
    public int create(Eventful_VenueModel c) {
        int ret = -1;

        Object[] values = {c.getApi_id(), c.getUrl(), c.getName(), c.getDescription(), c.getVenue_category(), c.getAddress(), c.getCity_name(),
            c.getRegion_name(), c.getPostal_code(), c.getCountry_name(), c.getLatitude(), c.getLongitude(), c.getGeocode_type(), c.getCreated()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getLong(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_VenueModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getApi_id(), c.getUrl(), c.getName(),
                        c.getDescription(), c.getVenue_category(), c.getAddress(), c.getCity_name(),
                        c.getRegion_name(), c.getPostal_code(), c.getCountry_name(), c.getLatitude(), c.getLongitude(), c.getGeocode_type(),
                        c.getCreated());) {

            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
