/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee;

/**
 *
 * @author user
 */
public class EE_Venue_Category_Has_Foursquare_CategoryModel {

    private long ee_venue_category_id;
    private long foursquare_category_id;

    public EE_Venue_Category_Has_Foursquare_CategoryModel() {
    }

    public EE_Venue_Category_Has_Foursquare_CategoryModel(long ee_venue_category_id, long foursquare_category_id) {
        this.ee_venue_category_id = ee_venue_category_id;
        this.foursquare_category_id = foursquare_category_id;
    }

    public long getEe_venue_category_id() {
        return ee_venue_category_id;
    }

    public void setEe_venue_category_id(long ee_venue_category_id) {
        this.ee_venue_category_id = ee_venue_category_id;
    }

 

    public long getFoursquare_category_id() {
        return foursquare_category_id;
    }

    public void setFoursquare_category_id(long foursquare_category_id) {
        this.foursquare_category_id = foursquare_category_id;
    }

    @Override
    public String toString() {
        return "EE_Venue_Category_Has_Foursquare_CategoryModel{" + "ee_venue_category_id=" + ee_venue_category_id + ", foursquare_category_id=" + foursquare_category_id + '}';
    }

    
    
    


}
