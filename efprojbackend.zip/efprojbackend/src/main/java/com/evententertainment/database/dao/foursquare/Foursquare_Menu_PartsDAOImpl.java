/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_Menu_PartsModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_Menu_PartsDAOImpl implements Foursquare_Menu_PartsDAO {

    private static final String TABLE = "foursquare_menu_parts";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`venue_menu_id`,`menuId`,`name`,`description`,`sections_count`) values (?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`venue_menu_id`,`menuId`,`name`,`description`,`sections_count`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_Menu_PartsModel map(ResultSet resultSet) throws SQLException {
        Foursquare_Menu_PartsModel object = new Foursquare_Menu_PartsModel();

        object.setVenue_menu_id(resultSet.getLong("venue_menu_id"));
        object.setMenuId(resultSet.getString("menuId"));
        object.setName(resultSet.getString("name"));
        object.setDescription(resultSet.getString("description"));
        object.setSections_count(resultSet.getLong("sections_count"));

        return object;
    }

    @Override
    public List<Foursquare_Menu_PartsModel> list() {
        List<Foursquare_Menu_PartsModel> menu_parts = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                menu_parts.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return menu_parts;
    }

    @Override
    public Foursquare_Menu_PartsModel find(long id) {
        Foursquare_Menu_PartsModel menu_parts = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                menu_parts = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return menu_parts;
    }

    @Override
    public int create(Foursquare_Menu_PartsModel c) {
        int ret = -1;
        Object[] values = {c.getVenue_menu_id(),c.getMenuId(),c.getName(),c.getDescription(), c.getSections_count()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_Menu_PartsModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getVenue_menu_id(),c.getMenuId(),c.getName(),c.getDescription(), c.getSections_count());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
