/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_EventHasPerformerModel;
import java.util.List;

public interface Eventful_Event_Has_PerformerDAO {
     public List<Eventful_EventHasPerformerModel> list();

    public Eventful_EventHasPerformerModel find(long id);

    public int create(Eventful_EventHasPerformerModel c);

    public int update(Eventful_EventHasPerformerModel c);

    public int delete(long id); 

}
