/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.request;

/**
 *
 * @author user
 */
public class EE_EventRequest {

    private Long selectedEventCategory;
    private String  selectedEventPlace;
    private double latitude;
    private double longitude;
    private double distance;
    private String start_time_min;
    private String start_time_max;

    public EE_EventRequest(Long selectedEventCategory, String selectedEventPlace, double latitude, double longitude, double distance, String start_time_min, String start_time_max) {
        this.selectedEventCategory = selectedEventCategory;
        this.selectedEventPlace = selectedEventPlace;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
        this.start_time_min = start_time_min;
        this.start_time_max = start_time_max;
    }

   

  
    public EE_EventRequest() {
    }

    public Long getSelectedEventCategory() {
        return selectedEventCategory;
    }

    public void setSelectedEventCategory(Long selectedEventCategory) {
        this.selectedEventCategory = selectedEventCategory;
    }

   

    public String getSelectedEventPlace() {
        return selectedEventPlace;
    }

    public void setSelectedEventPlace(String selectedEventPlace) {
        this.selectedEventPlace = selectedEventPlace;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getStart_time_min() {
        return start_time_min;
    }

    public void setStart_time_min(String start_time_min) {
        this.start_time_min = start_time_min;
    }

    public String getStart_time_max() {
        return start_time_max;
    }

    public void setStart_time_max(String start_time_max) {
        this.start_time_max = start_time_max;
    }

    @Override
    public String toString() {
        return "EE_EventRequest{" + "selectedEventCategory=" + selectedEventCategory + ", selectedEventPlace=" + selectedEventPlace + ", latitude=" + latitude + ", longitude=" + longitude + ", distance=" + distance + ", start_time_min=" + start_time_min + ", start_time_max=" + start_time_max + '}';
    }

  
}
