/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

/**
 *
 * @author user
 */
import com.evententertainment.database.model.foursquare.Foursquare_Event_Has_Foursquare_CategoryModel;
import java.util.List;

public interface Foursquare_Event_Has_Foursquare_CategoryDAO {
    public List<Foursquare_Event_Has_Foursquare_CategoryModel> list();

    public Foursquare_Event_Has_Foursquare_CategoryModel find(long foursquare_event_id);

    public int create(Foursquare_Event_Has_Foursquare_CategoryModel c);

    public int update(Foursquare_Event_Has_Foursquare_CategoryModel c);

    public int delete(long foursquare_event_id);   
}
