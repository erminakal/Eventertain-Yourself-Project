package com.evententertainment.database.model.foursquare;

import java.util.ArrayList;

public class Foursquare_VenueModel {

    private long id;
    private String api_id;
    private String name;
    private String canonicalUrl;
    private String shortUrl;
    private long checkinsCount;
    private long usersCount;
    private long tipCount;
    private String url;
    private int price_tier;
    private String price_message;
    private String price_currency;
    private String timezone;
    private boolean hasMenu;
    private float rating;
    private String description;
    private float createdAt;
    
    private ArrayList<Foursquare_CategoryModel> categories = new ArrayList<>();

    public void print() {
        System.out.println("--------------------------------------------------------------");
        System.out.println("The venue we want is " + name + " with api_id :" + api_id);
        System.out.println(" It has canonical url: " + canonicalUrl + " and it belongs to : " + timezone);
        System.out.println(+ rating + " is its ratiing and we can say it is "+price_message+" as the cost concerns.");
        System.out.println(" Some more things about this venue: " + description);
        System.out.println("--------------------------------------------------------------");
    }
    // relationships:
    private Foursquare_CategoryModel categoryModel = null;
    private Foursquare_ContactModel contactModel = null;
    private Foursquare_EventModel eventModel = null;
    private Foursquare_OperationModel operationModel = null;
    private Foursquare_MenuModel menuModel = null;
    private Foursquare_LocationModel locationModel = null;
    private Foursquare_VenueHasCategoryModel vhcModel = null;

    public Foursquare_VenueModel() {

    }

    public Foursquare_VenueModel(long id, String api_id, String name, String canonicalUrl, String shortUrl, long checkinsCount, long usersCount, long tipCount, String url, int price_tier, String price_message, String price_currency, String timezone, boolean hasMenu, float rating, String description, float createdAt) {
        this.id = id;
        this.api_id = api_id;
        this.name = name;
        this.canonicalUrl = canonicalUrl;
        this.shortUrl = shortUrl;
        this.checkinsCount = checkinsCount;
        this.usersCount = usersCount;
        this.tipCount = tipCount;
        this.url = url;
        this.price_tier = price_tier;
        this.price_message = price_message;
        this.price_currency = price_currency;
        this.timezone = timezone;
        this.hasMenu = hasMenu;
        this.rating = rating;
        this.description = description;
        this.createdAt = createdAt;
    }





    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCanonicalUrl() {
        return canonicalUrl;
    }

    public void setCanonicalUrl(String canonicalUrl) {
        this.canonicalUrl = canonicalUrl;
    }

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }

    public long getCheckinsCount() {
        return checkinsCount;
    }

    public void setCheckinsCount(long checkinsCount) {
        this.checkinsCount = checkinsCount;
    }

    public long getUsersCount() {
        return usersCount;
    }

    public void setUsersCount(long usersCount) {
        this.usersCount = usersCount;
    }

    public long getTipCount() {
        return tipCount;
    }

    public void setTipCount(long tipCount) {
        this.tipCount = tipCount;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getPrice_tier() {
        return price_tier;
    }

    public void setPrice_tier(int price_tier) {
        this.price_tier = price_tier;
    }

    public String getPrice_message() {
        return price_message;
    }

    public void setPrice_message(String price_message) {
        this.price_message = price_message;
    }

    public String getPrice_currency() {
        return price_currency;
    }

    public void setPrice_currency(String price_currency) {
        this.price_currency = price_currency;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }
    
    

    public boolean isHasMenu() {
        return hasMenu;
    }

    public void setHasMenu(boolean hasMenu) {
        this.hasMenu = hasMenu;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(float createdAt) {
        this.createdAt = createdAt;
    }

    public Foursquare_ContactModel getContactModel() {
        return contactModel;
    }

    public void setContactModel(Foursquare_ContactModel contactModel) {
        this.contactModel = contactModel;
    }

    public Foursquare_EventModel getEventModel() {
        return eventModel;
    }

    public void setEventModel(Foursquare_EventModel eventModel) {
        this.eventModel = eventModel;
    }

    public Foursquare_OperationModel getOperationModel() {
        return operationModel;
    }

    public void setOperationModel(Foursquare_OperationModel operationModel) {
        this.operationModel = operationModel;
    }

    public Foursquare_MenuModel getMenuModel() {
        return menuModel;
    }

    public void setMenuModel(Foursquare_MenuModel menuModel) {
        this.menuModel = menuModel;
    }

    public Foursquare_LocationModel getLocationModel() {
        return locationModel;
    }

    public void setLocationModel(Foursquare_LocationModel locationModel) {
        this.locationModel = locationModel;
    }

    public Foursquare_CategoryModel getCategoryModel() {
        return categoryModel;
    }

    public void setCategoryModel(Foursquare_CategoryModel categoryModel) {
        this.categoryModel = categoryModel;
    }

    public Foursquare_VenueHasCategoryModel getVhcModel() {
        return vhcModel;
    }

    public void setVhcModel(Foursquare_VenueHasCategoryModel vhcModel) {
        this.vhcModel = vhcModel;
    }

    public ArrayList<Foursquare_CategoryModel> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<Foursquare_CategoryModel> categories) {
        this.categories = categories;
    }

    @Override
    public String toString() {
        return "Foursquare_VenueModel{" + "id=" + id + ", api_id=" + api_id + ", name=" + name + ", canonicalUrl=" + canonicalUrl + ", shortUrl=" + shortUrl + ", checkinsCount=" + checkinsCount + ", usersCount=" + usersCount + ", tipCount=" + tipCount + ", url=" + url + ", price_tier=" + price_tier + ", price_message=" + price_message + ", price_currency=" + price_currency + ", timezone=" + timezone + ", hasMenu=" + hasMenu + ", rating=" + rating + ", description=" + description + ", createdAt=" + createdAt + ", categories=" + categories + ", categoryModel=" + categoryModel + ", contactModel=" + contactModel + ", eventModel=" + eventModel + ", operationModel=" + operationModel + ", menuModel=" + menuModel + ", locationModel=" + locationModel + ", vhcModel=" + vhcModel + '}';
    }

   

}
