package com.evententertainment.database.model.eventful;

import java.util.ArrayList;

public class Eventful_EventModel {

    private long id;
    private String api_id;

    private String url;
    private String title;
    private String description;
    private String start_time;
    private String stop_time;

    private String venue_api_id;

    private String venue_name;
    private String venue_type;
    private boolean venue_display;
    private String venue_address;
    private String city_name;
    private String region_name;

    private String postal_code;
    private String country_name;

    private int all_day;
    private float latitude;
    private float longitude;
    private String geocode_type;

    private String created;
    private String owner;
    private String modified;

    private String olson_path;

    private int privacy;
    private boolean free;
    private String price;
    private boolean withdrawn;
    private String withdrawn_note;
    private Long venue_id;
    private String tag;

    private ArrayList<Eventful_PerformerModel> performers = new ArrayList<>();

    private ArrayList<Eventful_Event_CategoryModel> categories = new ArrayList<>();

    public void print() {
        System.out.print("----------------------------------------" + "\n");
        System.out.print("api_id=" + api_id + "\n");
        System.out.println("title=" + title);
        System.out.println("url:" + url);
        System.out.println("description:" + description);
        System.out.println("start time:" + start_time);
        System.out.println("stop time:" + stop_time);
        System.out.println("Venue's api id is:" + venue_api_id + "The venue " + venue_name + " is at " + venue_address + " " + postal_code + " and its type is:" + venue_type + "and display value is:" + venue_display);
        System.out.println("City name:" + city_name + " in region " + region_name + " in country " + country_name);
        System.out.println("all day: " + all_day);

        System.out.println("latitude of event:" + latitude + " and longitude:" + longitude);
        System.out.println("geocode type is: " + geocode_type);
        System.out.println("the event was created on " + created + "by " + owner + ". It was modified on " + modified);
        System.out.println("Olson path: " + olson_path);
        System.out.println("As for the privacy we have value:" + privacy + " and as for the cost we have the value " + price + " so you can understand if it is free from the value " + free);
        System.out.println("If the event is withdrawn we understand it from value " + withdrawn + " and the reasons seem here:" + withdrawn_note);

        System.out.println("---------------------------------------");
    }
    // relationships:
    private Eventful_ImageModel imageModel = null;

    private Eventful_VenueModel venueModel = null;

    private Eventful_EventHasCategoryModel ehcModel = null;

    private Eventful_EventHasPerformerModel ehpModel = null;

    public Eventful_EventModel() {
    }

    public Eventful_EventModel(long id, String api_id, String url, String title, String description, String start_time, String stop_time, String venue_api_id, String venue_name, String venue_type, boolean venue_display, String venue_address, String city_name, String region_name, String postal_code, String country_name, int all_day, float latitude, float longitude, String geocode_type, String created, String owner, String modified, String olson_path, int privacy, boolean free, String price, boolean withdrawn, String withdrawn_note, Long venue_id, String tag) {
        this.id = id;
        this.api_id = api_id;
        this.url = url;
        this.title = title;
        this.description = description;
        this.start_time = start_time;
        this.stop_time = stop_time;
        this.venue_api_id = venue_api_id;
        this.venue_name = venue_name;
        this.venue_type = venue_type;
        this.venue_display = venue_display;
        this.venue_address = venue_address;
        this.city_name = city_name;
        this.region_name = region_name;
        this.postal_code = postal_code;
        this.country_name = country_name;
        this.all_day = all_day;
        this.latitude = latitude;
        this.longitude = longitude;
        this.geocode_type = geocode_type;
        this.created = created;
        this.owner = owner;
        this.modified = modified;
        this.olson_path = olson_path;
        this.privacy = privacy;
        this.free = free;
        this.price = price;
        this.withdrawn = withdrawn;
        this.withdrawn_note = withdrawn_note;
        this.venue_id = venue_id;
        this.tag = tag;
    }
    
    

    

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getStop_time() {
        return stop_time;
    }

    public void setStop_time(String stop_time) {
        this.stop_time = stop_time;
    }

    public Long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(Long venue_id) {
        this.venue_id = venue_id;
    }

    public String getVenue_api_id() {
        return venue_api_id;
    }

    public void setVenue_api_id(String venue_api_id) {
        this.venue_api_id = venue_api_id;
    }

    public String getVenue_name() {
        return venue_name;
    }

    public void setVenue_name(String venue_name) {
        this.venue_name = venue_name;
    }

    public String getVenue_type() {
        return venue_type;
    }

    public void setVenue_type(String venue_type) {
        this.venue_type = venue_type;
    }

    public boolean isVenue_display() {
        return venue_display;
    }

    public void setVenue_display(boolean venue_display) {
        this.venue_display = venue_display;
    }

    public String getVenue_address() {
        return venue_address;
    }

    public void setVenue_address(String venue_address) {
        this.venue_address = venue_address;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public int getAll_day() {
        return all_day;
    }

    public void setAll_day(int all_day) {
        this.all_day = all_day;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getGeocode_type() {
        return geocode_type;
    }

    public void setGeocode_type(String geocode_type) {
        this.geocode_type = geocode_type;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getModified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    public String getOlson_path() {
        return olson_path;
    }

    public void setOlson_path(String olson_path) {
        this.olson_path = olson_path;
    }

    public int getPrivacy() {
        return privacy;
    }

    public void setPrivacy(int privacy) {
        this.privacy = privacy;
    }

    public boolean isFree() {
        return free;
    }

    public void setFree(boolean free) {
        this.free = free;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public boolean isWithdrawn() {
        return withdrawn;
    }

    public void setWithdrawn(boolean withdrawn) {
        this.withdrawn = withdrawn;
    }

    public String getWithdrawn_note() {
        return withdrawn_note;
    }

    public void setWithdrawn_note(String withdrawn_note) {
        this.withdrawn_note = withdrawn_note;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
    
    

    public ArrayList<Eventful_Event_CategoryModel> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<Eventful_Event_CategoryModel> categories) {
        this.categories = categories;
    }

    public ArrayList<Eventful_PerformerModel> getPerformers() {
        return performers;
    }

    public void setPerformers(ArrayList<Eventful_PerformerModel> performers) {
        this.performers = performers;
    }

    public Eventful_ImageModel getImageModel() {
        return imageModel;
    }

    public void setImageModel(Eventful_ImageModel imageModel) {
        this.imageModel = imageModel;
    }

    public Eventful_VenueModel getVenueModel() {
        return venueModel;
    }

    public void setVenueModel(Eventful_VenueModel venueModel) {
        this.venueModel = venueModel;
    }

    public Eventful_EventHasCategoryModel getEhcModel() {
        return ehcModel;
    }

    public void setEhcModel(Eventful_EventHasCategoryModel ehcModel) {
        this.ehcModel = ehcModel;
    }

    public Eventful_EventHasPerformerModel getEhpModel() {
        return ehpModel;
    }

    public void setEhpModel(Eventful_EventHasPerformerModel ehpModel) {
        this.ehpModel = ehpModel;
    }

    @Override
    public String toString() {
        return "Eventful_EventModel{" + "id=" + id + ", api_id=" + api_id + ", url=" + url + ", title=" + title + ", description=" + description + ", start_time=" + start_time + ", stop_time=" + stop_time + ", venue_api_id=" + venue_api_id + ", venue_name=" + venue_name + ", venue_type=" + venue_type + ", venue_display=" + venue_display + ", venue_address=" + venue_address + ", city_name=" + city_name + ", region_name=" + region_name + ", postal_code=" + postal_code + ", country_name=" + country_name + ", all_day=" + all_day + ", latitude=" + latitude + ", longitude=" + longitude + ", geocode_type=" + geocode_type + ", created=" + created + ", owner=" + owner + ", modified=" + modified + ", olson_path=" + olson_path + ", privacy=" + privacy + ", free=" + free + ", price=" + price + ", withdrawn=" + withdrawn + ", withdrawn_note=" + withdrawn_note + ", venue_id=" + venue_id + ", tag=" + tag + ", performers=" + performers + ", categories=" + categories + ", imageModel=" + imageModel + ", venueModel=" + venueModel + ", ehcModel=" + ehcModel + ", ehpModel=" + ehpModel + '}';
    }
    
    

   

}
