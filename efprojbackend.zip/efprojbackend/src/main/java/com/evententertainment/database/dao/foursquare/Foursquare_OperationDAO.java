/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.model.foursquare.Foursquare_OperationModel;
import java.util.List;


public interface Foursquare_OperationDAO {
    public List<Foursquare_OperationModel> list();

    public Foursquare_OperationModel find(long venue_id);

    public int create(Foursquare_OperationModel c);

    public int update(Foursquare_OperationModel c);

    public int delete(long venue_id);   
}

