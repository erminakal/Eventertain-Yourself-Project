/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

import java.util.ArrayList;

public class Foursquare_Event_Has_Foursquare_CategoryModel {
    
    private long foursquare_event_id;
    private long foursquare_category_id;
    
    public Foursquare_Event_Has_Foursquare_CategoryModel(){
        
    }

    public Foursquare_Event_Has_Foursquare_CategoryModel(long foursquare_event_id, long foursquare_category_id) {
        this.foursquare_event_id = foursquare_event_id;
        this.foursquare_category_id = foursquare_category_id;
    }

    
    //relationships
    private ArrayList<Foursquare_CategoryModel> categories = new ArrayList<>();

    
    
    public long getFoursquare_event_id() {
        return foursquare_event_id;
    }

    public void setFoursquare_event_id(long foursquare_event_id) {
        this.foursquare_event_id = foursquare_event_id;
    }

    public long getFoursquare_category_id() {
        return foursquare_category_id;
    }

    public void setFoursquare_category_id(long foursquare_category_id) {
        this.foursquare_category_id = foursquare_category_id;
    }

    public ArrayList<Foursquare_CategoryModel> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<Foursquare_CategoryModel> categories) {
        this.categories = categories;
    }

    @Override
    public String toString() {
        return "Foursquare_Event_Has_Foursquare_CategoryModel{" + "foursquare_event_id=" + foursquare_event_id + ", foursquare_category_id=" + foursquare_category_id + ", categories=" + categories + '}';
    }


 

    
    
}
