/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_LocationModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_LocationDAOImpl implements Foursquare_LocationDAO {

    private static final String TABLE = "foursquare_location";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`venue_id`,`address`,`crossStreet`,`latitude`,`longitude`,`postalCode`,`cc`,`city`,`state`,`country`) values (?,?,?,?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`venue_id`,`address`,`crossStreet`,`latitude`,`longitude`,`postalCode`,`cc`,`city`,`state`,`country`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_LocationModel map(ResultSet resultSet) throws SQLException {
        
        Foursquare_LocationModel object = new Foursquare_LocationModel();

        object.setId(resultSet.getLong("id"));
        object.setVenue_id(resultSet.getLong("venue_id"));
        object.setAddress(resultSet.getString("address"));
        object.setCrossStreet(resultSet.getString("crossStreet"));
        object.setLatitude(resultSet.getDouble("latitude"));
        object.setLongitude(resultSet.getDouble("longitude"));
        object.setPostalCode(resultSet.getString("postalCode"));
        object.setCc(resultSet.getString("cc"));
        object.setCity(resultSet.getString("city"));
        object.setState(resultSet.getString("state"));
        object.setCountry(resultSet.getString("country"));

        return object;
    }

    @Override
    public List<Foursquare_LocationModel> list() {
        List<Foursquare_LocationModel> locations = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                locations.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return locations;
    }

    @Override
    public Foursquare_LocationModel find(long id) {
        Foursquare_LocationModel location = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                location = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return location;
    }

    @Override
    public int create(Foursquare_LocationModel c) {
        int ret = -1;
        Object[] values = {c.getVenue_id(), c.getAddress(), c.getCrossStreet(), c.getLatitude(), c.getLongitude(), c.getPostalCode(), c.getCc(), c.getCity(), c.getState(), c.getCountry()};

        try (Connection connection = factory.getConnection();
PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getLong(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_LocationModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getVenue_id(), c.getAddress(), c.getCrossStreet(), c.getLatitude(), c.getLongitude(), c.getPostalCode(), c.getCc(), c.getCity(), c.getState(), c.getCountry());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
