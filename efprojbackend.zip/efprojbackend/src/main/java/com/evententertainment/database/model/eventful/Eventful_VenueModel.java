/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.eventful;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Eventful_VenueModel {

    private Long id;
    private String api_id;
    private String url;
    private String name;
    private String description;
    private String venue_category;
    private String address;
    private String city_name;
    private String region_name;
    private String postal_code;
    private String country_name;
    private float latitude;
    private float longitude;
    private String geocode_type;
    private String created;
    private String tag;

    private ArrayList<Eventful_Venue_CategoryModel> categories = new ArrayList<>();

    // relationships
    private Eventful_Venue_Connect_Venue_CategoryModel vccModel = null;

    public Eventful_VenueModel() {
    }

    public Eventful_VenueModel(Long id, String api_id, String url, String name, String description, String venue_category, String address, String city_name, String region_name, String postal_code, String country_name, float latitude, float longitude, String geocode_type, String created, String tag) {
        this.id = id;
        this.api_id = api_id;
        this.url = url;
        this.name = name;
        this.description = description;
        this.venue_category = venue_category;
        this.address = address;
        this.city_name = city_name;
        this.region_name = region_name;
        this.postal_code = postal_code;
        this.country_name = country_name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.geocode_type = geocode_type;
        this.created = created;
        this.tag = tag;
    }

    

    public void print() {
        System.out.println("----------------------------------------");
        System.out.println("Venue's id: " + this.getApi_id());
        System.out.println("Venue's name is: " + this.getName());
        System.out.println("Venue's url is: " + this.getUrl());
        System.out.println("A few words about this place: " + this.getDescription());
        System.out.println("The place is at " + this.getAddress() + " in city " + this.getCity_name()
                + " in " + this.getRegion_name());
        System.out.println("Postal Code : " + this.getPostal_code());
        System.out.println("Country name : " + this.getCountry_name());
        System.out.println("latitude : " + this.getLatitude());
        System.out.println("longitude : " + this.getLongitude());
        System.out.println("geocode_type : " + this.getGeocode_type());
        System.out.println("venue type : " + this.getVenue_category());
        System.out.println("created: " + this.getCreated());
        System.out.println("----------------------------------------");

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVenue_category() {
        return venue_category;
    }

    public void setVenue_category(String venue_category) {
        this.venue_category = venue_category;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getGeocode_type() {
        return geocode_type;
    }

    public void setGeocode_type(String geocode_type) {
        this.geocode_type = geocode_type;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
    
    

    public ArrayList<Eventful_Venue_CategoryModel> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<Eventful_Venue_CategoryModel> categories) {
        this.categories = categories;
    }

    public Eventful_Venue_Connect_Venue_CategoryModel getVccModel() {
        return vccModel;
    }

    public void setVccModel(Eventful_Venue_Connect_Venue_CategoryModel vccModel) {
        this.vccModel = vccModel;
    }

    @Override
    public String toString() {
        return "Eventful_VenueModel{" + "id=" + id + ", api_id=" + api_id + ", url=" + url + ", name=" + name + ", description=" + description + ", venue_category=" + venue_category + ", address=" + address + ", city_name=" + city_name + ", region_name=" + region_name + ", postal_code=" + postal_code + ", country_name=" + country_name + ", latitude=" + latitude + ", longitude=" + longitude + ", geocode_type=" + geocode_type + ", created=" + created + ", tag=" + tag + ", categories=" + categories + ", vccModel=" + vccModel + '}';
    }

    

}
