/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.request;


public class EE_Free_Search_VenuesRequest {
    
    
    String tag;

    public EE_Free_Search_VenuesRequest() {
    }

    
    
    public EE_Free_Search_VenuesRequest(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    @Override
    public String toString() {
        return "EE_Free_Search_VenuesRequest{" + "tag=" + tag + '}';
    }

    

  
    
    
    
    
    
}
