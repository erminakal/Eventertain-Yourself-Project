/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_EventHasCategoryModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_Event_Has_CategoryDAOImpl implements Eventful_Event_Has_CategoryDAO {
 private static final String TABLE = "eventful_event_has_category";   
    private static final String SQL_LIST_ORDER_BY_EVENT_ID = "SELECT * FROM " +TABLE;
    private static final String SQL_FIND_BY_EVENT_ID = "SELECT * FROM " +TABLE+" WHERE `event_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " +TABLE+" (`event_id`,`category_id` ) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " +TABLE+" SET (`event_id`,`category_id`) WHERE `event_id` = ?";
    private static final String SQL_DELETE_BY_EVENT_ID = "DELETE FROM " +TABLE+" WHERE `event_id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_EventHasCategoryModel map(ResultSet resultSet) throws SQLException {
       Eventful_EventHasCategoryModel object = new Eventful_EventHasCategoryModel();

        object.setEvent_id(resultSet.getLong("event_id"));
        object.setCategory_id(resultSet.getLong("category_id"));
    

        return object;
    }

    @Override
    public List<Eventful_EventHasCategoryModel> list() {
        List<Eventful_EventHasCategoryModel> events = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_EVENT_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                events.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return events;
    }

    @Override
    public Eventful_EventHasCategoryModel find(long event_id) {
        Eventful_EventHasCategoryModel event = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_EVENT_ID, event_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                event = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return event;
    }

    @Override
    public int create(Eventful_EventHasCategoryModel c) {
        int ret = -1;
        Object[] values = {c.getEvent_id(), c.getCategory_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }
            
            return 1;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_EventHasCategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE,c.getEvent_id(),c.getCategory_id());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long event_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_EVENT_ID, event_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
