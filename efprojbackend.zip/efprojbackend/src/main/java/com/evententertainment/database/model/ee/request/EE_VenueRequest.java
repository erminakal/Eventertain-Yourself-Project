/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.request;

/**
 *
 * @author user
 */
public class EE_VenueRequest {
      private Long selectedVenueCategory;
    private String selectedVenuePlace;
    private double latitude;
    private double longitude;
    private double distance;
    
    

    public EE_VenueRequest(Long selectedVenueCategory, String selectedVenuePlace, double latitude, double longitude, double distance) {
        this.selectedVenueCategory = selectedVenueCategory;
        this.selectedVenuePlace = selectedVenuePlace;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
    }

    public EE_VenueRequest() {
    }

  

    public Long getSelectedVenueCategory() {
        return selectedVenueCategory;
    }

    public void setSelectedVenueCategory(Long selectedVenueCategory) {
        this.selectedVenueCategory = selectedVenueCategory;
    }

   

    public String getSelectedVenuePlace() {
        return selectedVenuePlace;
    }

    public void setSelectedVenuePlace(String selectedVenuePlace) {
        this.selectedVenuePlace = selectedVenuePlace;
    }

    
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    @Override
    public String toString() {
        return "EE_VenueRequest{" + "selectedVenueCategory=" + selectedVenueCategory + ", selectedVenuePlace=" + selectedVenuePlace + ", latitude=" + latitude + ", longitude=" + longitude + ", distance=" + distance + '}';
    }

 
    
    
    
}
