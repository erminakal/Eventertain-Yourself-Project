/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

/**
 *
 * @author user
 */
import com.evententertainment.database.model.foursquare.Foursquare_VenueHasCategoryModel;
import java.util.List;

public interface Foursquare_VenueHasCategoryDAO {
    public List<Foursquare_VenueHasCategoryModel> list();

    public Foursquare_VenueHasCategoryModel find(long venue_id);

    public int create(Foursquare_VenueHasCategoryModel c);

    public int update(Foursquare_VenueHasCategoryModel c);

    public int delete(long venue_id);   
}
