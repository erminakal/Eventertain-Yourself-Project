
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_ContactModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_ContactDAOImpl implements Foursquare_ContactDAO{
    private static final String TABLE = "foursquare_contact";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM "+TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM "+TABLE+" WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO "+TABLE+"(`venue_id`,`phone`,`formattedPhone`,`instagram`,`twitter`,`facebook`,`facebookUsername`,`facebookName`) values (?,?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE "+TABLE+" SET (`venue_id`,`phone`,`formattedPhone`,`instagram`,`twitter`,`facebook`,`facebookUsername`,`facebookName`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM "+TABLE+" WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_ContactModel map(ResultSet resultSet) throws SQLException {
        Foursquare_ContactModel object = new Foursquare_ContactModel();
      
        object.setId(resultSet.getLong("id"));
        object.setVenue_id(resultSet.getLong("venue_id"));
        object.setPhone(resultSet.getString("phone"));
        object.setFormattedPhone(resultSet.getString("formattedPhone"));
        object.setInstagram(resultSet.getString("instagram"));
        object.setTwitter(resultSet.getString("twitter"));
        object.setFacebook(resultSet.getString("facebook"));
        object.setFacebookUsername(resultSet.getString("facebookUsername"));
        object.setFacebookName(resultSet.getString("facebookName"));
       
        return object;
    }

    @Override
    public List<Foursquare_ContactModel> list() {
        List<Foursquare_ContactModel> contacts = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                contacts.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return contacts;
    }

    @Override
    public Foursquare_ContactModel find(long id) {
        Foursquare_ContactModel contact = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                contact = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return contact;
    }

    @Override
    public int create(Foursquare_ContactModel c) {
        int ret = -1;
        Object[] values = {c.getVenue_id(),c.getPhone(), c.getFormattedPhone(), c.getInstagram(), c.getTwitter(), c.getFacebook(), c.getFacebookUsername(), c.getFacebookName()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_ContactModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE,c.getVenue_id(), c.getPhone(), c.getFormattedPhone(), c.getInstagram(), c.getTwitter(), c.getFacebook(), c.getFacebookUsername(), c.getFacebookName());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long  id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}