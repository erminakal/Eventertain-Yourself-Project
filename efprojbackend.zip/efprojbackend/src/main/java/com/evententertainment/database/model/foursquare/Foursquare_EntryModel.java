/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

/**
 *
 * @author user
 */
public class Foursquare_EntryModel {
    
    private long id;
    private long section_id;
    private String entryId;
    private String entry_name;
    private String price;
    
    public Foursquare_EntryModel(){
        
    }

    public Foursquare_EntryModel(long id, long section_id, String entryId, String entry_name, String price) {
        this.id = id;
        this.section_id = section_id;
        this.entryId = entryId;
        this.entry_name = entry_name;
        this.price = price;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSection_id() {
        return section_id;
    }

    public void setSection_id(long section_id) {
        this.section_id = section_id;
    }

    public String getEntryId() {
        return entryId;
    }

    public void setEntryId(String entryId) {
        this.entryId = entryId;
    }

    public String getEntry_name() {
        return entry_name;
    }

    public void setEntry_name(String entry_name) {
        this.entry_name = entry_name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Foursquare_EntriesModel{" + "id=" + id + ", section_id=" + section_id + ", entryId=" + entryId + ", entry_name=" + entry_name + ", price=" + price + '}';
    }

   

    
   

    public void print (){
        System.out.println("Price: "+price+", entry_id: "+entryId+", entry name: "+entry_name);
    }
}
