package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_SectionModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_SectionDAOImpl implements Foursquare_SectionDAO {

    private static final String TABLE = "foursquare_section";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`menu_parts_id`,`entries_count`,`section_name`,`sectionId`,`description`) values (?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`menu_parts_id`,`entries_count`,`section_name`,`sectionId`,`description`) WHERE `venue_id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_SectionModel map(ResultSet resultSet) throws SQLException {
        Foursquare_SectionModel object = new Foursquare_SectionModel();

        object.setMenu_parts_id(resultSet.getLong("menu_parts_id"));
        object.setEntries_count(resultSet.getLong("entries_count"));
        object.setSection_name(resultSet.getString("section_name"));
        object.setSectionId(resultSet.getString("sectionId"));       
        object.setDescription(resultSet.getString("description"));

        return object;
    }

    @Override
    public List<Foursquare_SectionModel> list() {
        List<Foursquare_SectionModel> sections = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                sections.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return sections;
    }

    @Override
    public Foursquare_SectionModel find(long id) {
        Foursquare_SectionModel section = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                section = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return section;
    }

    @Override
    public int create(Foursquare_SectionModel c) {
        int ret = -1;
        Object[] values = {c.getMenu_parts_id(), c.getEntries_count(),c.getSection_name(),c.getSectionId(),c.getDescription()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_SectionModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getMenu_parts_id(), c.getEntries_count(),c.getSection_name(),c.getSectionId(),c.getDescription());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
