/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

/**
 *
 * @author user
 */
import com.evententertainment.database.model.foursquare.Foursquare_CategoryModel;
import java.util.List;

public interface Foursquare_CategoryDAO {

    public List<Foursquare_CategoryModel> list();

    public Foursquare_CategoryModel find(long parent_category_id,long id);
    
    public Foursquare_CategoryModel find(long id);

    public Foursquare_CategoryModel find(String api_id);

    public int create(Foursquare_CategoryModel c);

    public int update(Foursquare_CategoryModel c);

    public int delete(long id);
}
