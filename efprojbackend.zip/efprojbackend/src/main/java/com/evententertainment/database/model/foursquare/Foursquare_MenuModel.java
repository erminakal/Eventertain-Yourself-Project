/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.foursquare;

/**
 *
 * @author user
 */
public class Foursquare_MenuModel {

    private long id;
    private long venue_id;
    private int menus_count;
    
    public Object getMenus_count;


    public Foursquare_MenuModel() {

    }

    //relationships
    private Foursquare_EntryModel entryModel = null;
    private Foursquare_Menu_PartsModel menu_partsModel=null;
    private Foursquare_SectionModel sectionModel=null;

    public Foursquare_MenuModel(long id, long venue_id, int menus_count, Object getMenus_count) {
        this.id = id;
        this.venue_id = venue_id;
        this.menus_count = menus_count;
        this.getMenus_count = getMenus_count;
    }

   

    

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }

    public int getMenus_count() {
        return menus_count;
    }

    public void setMenus_count(int menus_count) {
        this.menus_count = menus_count;
    }

    public Object getGetMenus_count() {
        return getMenus_count;
    }

    public void setGetMenus_count(Object getMenus_count) {
        this.getMenus_count = getMenus_count;
    }

    
    
    public Foursquare_EntryModel getEntryModel() {
        return entryModel;
    }

    public void setEntryModel(Foursquare_EntryModel entryModel) {
        this.entryModel = entryModel;
    }

    public Foursquare_Menu_PartsModel getMenu_partsModel() {
        return menu_partsModel;
    }

    public void setMenu_partsModel(Foursquare_Menu_PartsModel menu_partsModel) {
        this.menu_partsModel = menu_partsModel;
    }

    public Foursquare_SectionModel getSectionModel() {
        return sectionModel;
    }

    public void setSectionModel(Foursquare_SectionModel sectionModel) {
        this.sectionModel = sectionModel;
    }

    @Override
    public String toString() {
        return "Foursquare_MenuModel{" + "id=" + id + ", venue_id=" + venue_id + ", menus_count=" + menus_count + ", getMenus_count=" + getMenus_count + ", entryModel=" + entryModel + ", menu_partsModel=" + menu_partsModel + ", sectionModel=" + sectionModel + '}';
    }

  
    

   
  

    public void print() {
        System.out.println("The venue with id "+venue_id+" is consisted of "+menus_count+ " menus.");
    }

    
}
