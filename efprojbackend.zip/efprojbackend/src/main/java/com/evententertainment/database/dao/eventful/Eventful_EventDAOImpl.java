/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.eventful.Eventful_EventModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_EventDAOImpl implements Eventful_EventDAO {

    private static final String TABLE = "eventful_event";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_FIND_BY_API_ID = "SELECT * FROM " + TABLE + " WHERE `api_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`api_id`,"
            + "`url`,`title`,`description`,`start_time`,`stop_time`,`venue_id`,"
            + "`venue_api_id`,`venue_name`,`venue_type`,`venue_display`,`venue_address`,`city_name`,`region_name`,"
            + "`postal_code`,`country_name`,`all_day`,`latitude`,`longitude`,"
            + "`geocode_type`,`created`,`owner`,`modified`,`olson_path`,"
            + "`privacy`,`free`,`price`,`withdrawn`,`withdrawn_note`,`tag`)values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`api_id`,"
            + "`url`,`title`,`description`,`start_time`,`stop_time`,`venue_id`,"
            + "`venue_api_id`,`venue_name`,`venue_type`,`venue_display`,`venue_address`,`city_name`,`region_name`,"
            + "`postal_code`,`country_name`,`all_day`,`latitude`,`longitude`,"
            + "`geocode_type`,`created`,`owner`,`modified`,`olson_path`,"
            + "`privacy`,`free`,`price`,`withdrawn`,`withdrawn_note`,`tag`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_EventModel map(ResultSet resultSet) throws SQLException {
        Eventful_EventModel object = new Eventful_EventModel();

        object.setId(resultSet.getLong("id"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setUrl(resultSet.getString("url"));
        object.setTitle(resultSet.getString("title"));
        object.setDescription(resultSet.getString("description"));
        object.setStart_time(resultSet.getString("start_time"));
        object.setStop_time(resultSet.getString("stop_time"));
        object.setVenue_id(resultSet.getLong("venue_id"));
        object.setVenue_api_id(resultSet.getString("venue_api_id"));
        object.setVenue_name(resultSet.getString("venue_name"));
        object.setVenue_type(resultSet.getString("venue_type"));
        object.setVenue_display(resultSet.getBoolean("venue_display"));
        object.setVenue_address(resultSet.getString("venue_address"));
        object.setCity_name(resultSet.getString("city_name"));
        object.setRegion_name(resultSet.getString("region_name"));
        object.setPostal_code(resultSet.getString("postal_code"));
        object.setCountry_name(resultSet.getString("country_name"));
        object.setAll_day(resultSet.getInt("all_day"));
        object.setLatitude(resultSet.getFloat("latitude"));
        object.setLongitude(resultSet.getFloat("longitude"));
        object.setGeocode_type(resultSet.getString("geocode_type"));
        object.setCreated(resultSet.getString("created"));
        object.setOwner(resultSet.getString("owner"));
        object.setModified(resultSet.getString("modified"));
        object.setOlson_path(resultSet.getString("olson_path"));   
        object.setPrivacy(resultSet.getInt("privacy"));
        object.setFree(resultSet.getBoolean("free"));
        object.setPrice(resultSet.getString("price"));
        object.setWithdrawn(resultSet.getBoolean("withdrawn"));
        object.setWithdrawn_note(resultSet.getString("withdrawn_note"));
        object.setTag(resultSet.getString("tag"));

        return object;
    }

    @Override
    public List<Eventful_EventModel> list() {
        List<Eventful_EventModel> events = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                events.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return events;
    }

    @Override
    public Eventful_EventModel find(long id) {
        Eventful_EventModel event = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                event = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return event;
    }
    
    @Override
    public Eventful_EventModel find(String api_id) {
        Eventful_EventModel event = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                event = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return event;
    }

     
        @Override
    public int create(Eventful_EventModel c) {
        int ret = -1;
        Object[] values = {c.getApi_id(), c.getUrl(), c.getTitle(), c.getDescription(), c.getStart_time(), c.getStop_time(),
            c.getVenue_id(),
            c.getVenue_api_id(), c.getVenue_name(), c.getVenue_type(), c.isVenue_display(), c.getVenue_address(),
            c.getCity_name(), c.getRegion_name(), c.getPostal_code(), c.getCountry_name(),
            c.getAll_day(), c.getLatitude(), c.getLongitude(), c.getGeocode_type(),
            c.getCreated(), c.getOwner(), c.getModified(),
            c.getOlson_path(), c.getPrivacy(), c.isFree(), c.getPrice(), c.isWithdrawn(),
            c.getWithdrawn_note(),c.getTag()};
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getLong(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_EventModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getApi_id(), c.getUrl(), c.getTitle(), c.getDescription(), c.getStart_time(), c.getStop_time(),
                        c.getVenue_id(),
                        c.getVenue_api_id(), c.getVenue_name(), c.getVenue_type(), c.isVenue_display(), c.getVenue_address(),
                        c.getCity_name(), c.getRegion_name(), c.getPostal_code(), c.getCountry_name(),
                        c.getAll_day(), c.getLatitude(), c.getLongitude(), c.getGeocode_type(),
                        c.getCreated(), c.getOwner(), c.getModified(),
                        c.getOlson_path(),c.getPrivacy(), c.isFree(), c.getPrice(), c.isWithdrawn(),
                        c.getWithdrawn_note(),c.getTag());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
