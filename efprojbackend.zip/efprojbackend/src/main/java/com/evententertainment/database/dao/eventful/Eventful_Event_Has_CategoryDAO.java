/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_EventHasCategoryModel;
import java.util.List;


public interface Eventful_Event_Has_CategoryDAO {
    public List<Eventful_EventHasCategoryModel> list();

    public Eventful_EventHasCategoryModel find(long event_id);

    public int create(Eventful_EventHasCategoryModel c);

    public int update(Eventful_EventHasCategoryModel c);

    public int delete(long event_id);   
}

