/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_EntryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_EntryDAOImpl implements Foursquare_EntryDAO{
    private static final String TABLE="foursquare_entry";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM "+TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM "+TABLE+" WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO "+TABLE+"(`section_id`,`entryId`,`entry_name`,`price`) values (?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE "+TABLE+" SET (`section_id`,`entryId`,`entry_name`,`price`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM "+TABLE+" WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_EntryModel map(ResultSet resultSet) throws SQLException {
        Foursquare_EntryModel object = new Foursquare_EntryModel();
        
        object.setSection_id(resultSet.getLong("section_id"));
        object.setEntryId(resultSet.getString("entryId"));
        object.setEntry_name(resultSet.getString("entry_name"));
        object.setPrice(resultSet.getString("price"));
        return object;
    }

    @Override
    public List<Foursquare_EntryModel> list() {
        List<Foursquare_EntryModel> entries = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                entries.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return entries;
    }

    @Override
    public Foursquare_EntryModel find(long id) {
        Foursquare_EntryModel entry = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                entry = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return entry;
    }

    @Override
    public int create(Foursquare_EntryModel c) {
        int ret = -1;
        Object[] values = {c.getSection_id(), c.getEntryId(),c.getEntry_name(),c.getPrice()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_EntryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getSection_id(), c.getEntryId(),c.getEntry_name(),c.getPrice());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long  id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
