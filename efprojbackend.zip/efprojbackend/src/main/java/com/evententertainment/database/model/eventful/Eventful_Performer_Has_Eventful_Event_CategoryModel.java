
package com.evententertainment.database.model.eventful;

public class Eventful_Performer_Has_Eventful_Event_CategoryModel {

    private long eventful_performer_id;
    private long eventful_event_category_id;

    public Eventful_Performer_Has_Eventful_Event_CategoryModel() {
    }

    public Eventful_Performer_Has_Eventful_Event_CategoryModel(long eventful_performer_id, long eventful_event_category_id) {
        this.eventful_performer_id = eventful_performer_id;
        this.eventful_event_category_id = eventful_event_category_id;
    }

    

    public void print() {
        System.out.println("performer id: " + this.getEventful_performer_id());
        System.out.println("Category id: " + this.getEventful_event_category_id());
    }

    public long getEventful_performer_id() {
        return eventful_performer_id;
    }

    public void setEventful_performer_id(long eventful_performer_id) {
        this.eventful_performer_id = eventful_performer_id;
    }

    public long getEventful_event_category_id() {
        return eventful_event_category_id;
    }

    public void setEventful_event_category_id(long eventful_event_category_id) {
        this.eventful_event_category_id = eventful_event_category_id;
    }

    @Override
    public String toString() {
        return "Eventful_Performer_Has_Eventful_Event_CategoryModel{" + "eventful_performer_id=" + eventful_performer_id + ", eventful_event_category_id=" + eventful_event_category_id + '}';
    }

  

   
}

