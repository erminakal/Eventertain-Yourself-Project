/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.eventful;

public class Eventful_EventHasPerformerModel {
    private long event_id;
    private long performer_id;

    public Eventful_EventHasPerformerModel() {
    }

    public Eventful_EventHasPerformerModel(long event_id, long performer_id) {
        this.event_id = event_id;
        this.performer_id = performer_id;
    }
    
    public void print(){
        System.out.println("Event id: "+ this.getEvent_id());
        System.out.println("Performer id: "+ this.getPerformer_id());
    }

    public long getEvent_id() {
        return event_id;
    }

    public void setEvent_id(long event_id) {
        this.event_id = event_id;
    }

    public long getPerformer_id() {
        return performer_id;
    }

    public void setPerformer_id(long performer_id) {
        this.performer_id = performer_id;
    }

    @Override
    public String toString() {
        return "Eventful_EventHasPerformerModel{" + "event_id=" + event_id + ", performer_id=" + performer_id + '}';
    }
    
       public void setPerformer_id(Eventful_PerformerModel performer_id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
