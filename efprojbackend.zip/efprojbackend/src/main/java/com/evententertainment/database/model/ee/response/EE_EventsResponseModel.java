/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.response;

/**
 *
 * @author user
 */
public class EE_EventsResponseModel {

    private long id;
    private String source;
    private String api_id;
    private String title;
    private String url;
    private String tag;
    private String description;
    private String category;
    private float latitude;
    private float longitude;
    private String start_time;
    private String stop_time;
    private long venue_id;
    private String venue_name;
    private String venue_address;
    private String city_name;
    private String region_name;
    private String country_name;
    private boolean free;
    private String price;
    private int privacy;
    private boolean withdrawn;
    private String withdrawn_note;
    private String performer_api_id;
    private String performer_name;
    private String performer_category;
    private String performer_bio;
    private String performer_url;

    public EE_EventsResponseModel() {
    }

    public EE_EventsResponseModel(long id, String source, String api_id, String title, String url, String tag, String description, String category, float latitude, float longitude, String start_time, String stop_time, long venue_id, String venue_name, String venue_address, String city_name, String region_name, String country_name, boolean free, String price, int privacy, boolean withdrawn, String withdrawn_note, String performer_api_id, String performer_name, String performer_category, String performer_bio, String performer_url) {
        this.id = id;
        this.source = source;
        this.api_id = api_id;
        this.title = title;
        this.url = url;
        this.tag = tag;
        this.description = description;
        this.category = category;
        this.latitude = latitude;
        this.longitude = longitude;
        this.start_time = start_time;
        this.stop_time = stop_time;
        this.venue_id = venue_id;
        this.venue_name = venue_name;
        this.venue_address = venue_address;
        this.city_name = city_name;
        this.region_name = region_name;
        this.country_name = country_name;
        this.free = free;
        this.price = price;
        this.privacy = privacy;
        this.withdrawn = withdrawn;
        this.withdrawn_note = withdrawn_note;
        this.performer_api_id = performer_api_id;
        this.performer_name = performer_name;
        this.performer_category = performer_category;
        this.performer_bio = performer_bio;
        this.performer_url = performer_url;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getStop_time() {
        return stop_time;
    }

    public void setStop_time(String stop_time) {
        this.stop_time = stop_time;
    }

    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }

    public String getVenue_name() {
        return venue_name;
    }

    public void setVenue_name(String venue_name) {
        this.venue_name = venue_name;
    }

    public String getVenue_address() {
        return venue_address;
    }

    public void setVenue_address(String venue_address) {
        this.venue_address = venue_address;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isFree() {
        return free;
    }

    public void setFree(boolean free) {
        this.free = free;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getPrivacy() {
        return privacy;
    }

    public void setPrivacy(int privacy) {
        this.privacy = privacy;
    }

    public boolean isWithdrawn() {
        return withdrawn;
    }

    public void setWithdrawn(boolean withdrawn) {
        this.withdrawn = withdrawn;
    }

    public String getWithdrawn_note() {
        return withdrawn_note;
    }

    public void setWithdrawn_note(String withdrawn_note) {
        this.withdrawn_note = withdrawn_note;
    }

    public String getPerformer_api_id() {
        return performer_api_id;
    }

    public void setPerformer_api_id(String performer_api_id) {
        this.performer_api_id = performer_api_id;
    }

    public String getPerformer_name() {
        return performer_name;
    }

    public void setPerformer_name(String performer_name) {
        this.performer_name = performer_name;
    }

    public String getPerformer_category() {
        return performer_category;
    }

    public void setPerformer_category(String performer_category) {
        this.performer_category = performer_category;
    }

    public String getPerformer_bio() {
        return performer_bio;
    }

    public void setPerformer_bio(String performer_bio) {
        this.performer_bio = performer_bio;
    }

    public String getPerformer_url() {
        return performer_url;
    }

    public void setPerformer_url(String performer_url) {
        this.performer_url = performer_url;
    }

    @Override
    public String toString() {
        return "EE_EventsResponseModel{" + "id=" + id + ", source=" + source + ", api_id=" + api_id + ", title=" + title + ", url=" + url + ", tag=" + tag + ", description=" + description + ", category=" + category + ", latitude=" + latitude + ", longitude=" + longitude + ", start_time=" + start_time + ", stop_time=" + stop_time + ", venue_id=" + venue_id + ", venue_name=" + venue_name + ", venue_address=" + venue_address + ", city_name=" + city_name + ", region_name=" + region_name + ", country_name=" + country_name + ", free=" + free + ", price=" + price + ", privacy=" + privacy + ", withdrawn=" + withdrawn + ", withdrawn_note=" + withdrawn_note + ", performer_api_id=" + performer_api_id + ", performer_name=" + performer_name + ", performer_category=" + performer_category + ", performer_bio=" + performer_bio + ", performer_url=" + performer_url + '}';
    }

}
