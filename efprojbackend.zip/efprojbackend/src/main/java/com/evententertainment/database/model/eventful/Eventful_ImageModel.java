/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.eventful;

public class Eventful_ImageModel {
    
    private Long id;
    private String image_url;
    private int width;
    private int height;
  
    
    public Eventful_ImageModel(){
}

    public Eventful_ImageModel(Long id, String image_url, int width, int height) {
        this.id = id;
        this.image_url = image_url;
        this.width = width;
        this.height = height;
       
    }
    
    public void print(){
        System.out.println("Image Url: "+this.getImage_url());
        System.out.println("Image has width: "+this.getWidth()+" pixels and height "+this.getHeight()+ " pixels.");
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "Eventful_ImageModel{" + "id=" + id + ", image_url=" + image_url + ", width=" + width + ", height=" + height + '}';
    }

 
    
}
