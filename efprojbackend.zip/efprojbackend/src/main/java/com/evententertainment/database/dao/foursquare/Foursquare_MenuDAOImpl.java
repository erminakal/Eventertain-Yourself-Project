/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.foursquare;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.foursquare.Foursquare_MenuModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_MenuDAOImpl implements Foursquare_MenuDAO {

    private static final String TABLE = "foursquare_menu";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`venue_id`,`menus_count`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`venue_id`,`menus_count`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_MenuModel map(ResultSet resultSet) throws SQLException {
        Foursquare_MenuModel object = new Foursquare_MenuModel();

        object.setVenue_id(resultSet.getLong("venue_id"));
        object.setMenus_count(resultSet.getInt("menus_count"));

        return object;
    }

    @Override
    public List<Foursquare_MenuModel> list() {
        List<Foursquare_MenuModel> menus = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                menus.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return menus;
    }

    @Override
    public Foursquare_MenuModel find(long id) {
        Foursquare_MenuModel menu = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                menu = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return menu;
    }

    @Override
    public int create(Foursquare_MenuModel c) {
        int ret = -1;
        Object[] values = {c.getVenue_id(),  c.getMenus_count()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Foursquare_MenuModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getVenue_id(),  c.getMenus_count());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
