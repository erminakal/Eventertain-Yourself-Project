/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.eventful;

import com.evententertainment.database.model.eventful.Eventful_ImageModel;
import java.util.List;

public interface Eventful_ImageDAO {
    public List<Eventful_ImageModel> list();

    public Eventful_ImageModel find(long id);
    
    public int create(Eventful_ImageModel c);

    public int update(Eventful_ImageModel c);

    public int delete(long id);    
    
}
