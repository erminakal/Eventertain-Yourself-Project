package com.evententertainment.database.model.ee;

public class EE_RegionModel {

    private long id;
    private String name;
    private String description;
    private double latitude;
    private double longitude;

    public EE_RegionModel() {
    }

    public EE_RegionModel(long id, String name, String description, double latitude, double longitude) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public EE_RegionModel(String name, String description, double latitude, double longitude) {
        this.name = name;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
    }
    

    public void print() {
        System.out.println("Latitude: " + latitude + " ,longitude: " + longitude);
        System.out.println("of the " + name + " region that is " + description);
        System.out.println("-----------------------------------------------");

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "EE_RegionModel{" + "id=" + id + ", name=" + name + ", description=" + description + ", latitude=" + latitude + ", longitude=" + longitude + '}';
    }

}
