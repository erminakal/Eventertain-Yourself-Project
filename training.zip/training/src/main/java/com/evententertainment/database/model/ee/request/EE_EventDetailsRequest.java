/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.request;

/**
 *
 * @author user
 */
public class EE_EventDetailsRequest {

    private String api_id;

    public EE_EventDetailsRequest(String api_id) {
        this.api_id = api_id;
    }

    public EE_EventDetailsRequest() {
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    @Override
    public String toString() {
        return "EE_EventDetailsRequest{" + "api_id=" + api_id + '}';
    }

   
   
}
