/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.request.EE_EventRequest;
import com.evententertainment.database.model.ee.request.EE_FindEventsFromSelectedVenueRequest;
import com.evententertainment.database.model.ee.request.EE_Free_Search_EventsRequest;
import com.evententertainment.database.model.ee.response.EE_EventsDetailsEventfulModel;
import com.evententertainment.database.model.ee.response.EE_EventsResponseModel;
import java.util.List;

public interface EE_EventsResponseDAO {
 

    public List<EE_EventsResponseModel> list();
    
    public List<EE_EventsDetailsEventfulModel> list_details();
    
    public List<EE_EventsResponseModel> search(EE_EventRequest request);
    
    public EE_EventsResponseModel find_by_api_id(String api_id);
  
    public List<EE_EventsResponseModel> search_events_close_to_venue(EE_FindEventsFromSelectedVenueRequest request);
    
    public List<EE_EventsResponseModel> search_all(EE_Free_Search_EventsRequest request);


 
}
