
package com.evententertainment.database.model.ee.request;


public class EE_FindEventsFromSelectedVenueRequest {

   
    private long venue_id; 
    private Long  selectedEventCategory;
    private double latitude;
    private double longitude;
    private double distance;

    public EE_FindEventsFromSelectedVenueRequest() {
    }

    public EE_FindEventsFromSelectedVenueRequest(long venue_id, Long selectedEventCategory, double latitude, double longitude, double distance) {
        this.venue_id = venue_id;
        this.selectedEventCategory = selectedEventCategory;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
    }




    public long getVenue_id() {
        return venue_id;
    }

    public void setVenue_id(long venue_id) {
        this.venue_id = venue_id;
    }

    public Long getSelectedEventCategory() {
        return selectedEventCategory;
    }

    public void setSelectedEventCategory(Long selectedEventCategory) {
        this.selectedEventCategory = selectedEventCategory;
    }

    

    

   

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    @Override
    public String toString() {
        return "EE_FindEventsFromSelectedVenueRequest{" + "venue_id=" + venue_id + ", selectedEventCategory=" + selectedEventCategory + ", latitude=" + latitude + ", longitude=" + longitude + ", distance=" + distance + '}';
    }



   

  

  


    


   
   
}
