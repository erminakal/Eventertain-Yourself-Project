
package com.evententertainment.database.model.ee;

public class EE_Event_Category_Has_Eventful_CategoryModel {

    private long ee_event_category_id;
    private long eventful_event_category_id;

    public EE_Event_Category_Has_Eventful_CategoryModel() {
    }

    public EE_Event_Category_Has_Eventful_CategoryModel(long ee_event_category_id, long eventful_event_category_id) {
        this.ee_event_category_id = ee_event_category_id;
        this.eventful_event_category_id = eventful_event_category_id;
    }

    
    public long getEe_event_category_id() {
        return ee_event_category_id;
    }

    public void setEe_event_category_id(long ee_event_category_id) {
        this.ee_event_category_id = ee_event_category_id;
    }

    public long getEventful_event_category_id() {
        return eventful_event_category_id;
    }

    public void setEventful_event_category_id(long eventful_event_category_id) {
        this.eventful_event_category_id = eventful_event_category_id;
    }

    @Override
    public String toString() {
        return "EE_Event_Category_Has_Eventful_CategoryModel{" + "ee_event_category_id=" + ee_event_category_id + ", eventful_event_category_id=" + eventful_event_category_id + '}';
    }

  
}
