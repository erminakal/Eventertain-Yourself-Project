/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.response;

/**
 *
 * @author user
 */
public class EE_VenuesDetailsFoursquareModel {
    
    private String phone;
    private String facebook;
    private String instagram;
    private String twitter;
    private String status;
    private String open;
    private String day;
    private Boolean Isopen;
    private Boolean hasMenu;

    private long menus_count;
    private String menuId;
    private String menu_name;
    private String menu_description;
    private long sections_count;

    private String section_name;
    private String sectionId;
    private String section_description;
    private long entries_count;
   
    private String entryId;
    private String entry_name;
    private String price;
   
    
    public EE_VenuesDetailsFoursquareModel() {
    }

    public EE_VenuesDetailsFoursquareModel(String phone, String facebook, String instagram, String twitter, String status, String open, String day, Boolean Isopen, Boolean hasMenu, long menus_count, String menuId, String menu_name, String menu_description, long sections_count, String section_name, String sectionId, String section_description, long entries_count, String entryId, String entry_name, String price) {
        this.phone = phone;
        this.facebook = facebook;
        this.instagram = instagram;
        this.twitter = twitter;
        this.status = status;
        this.open = open;
        this.day = day;
        this.Isopen = Isopen;
        this.hasMenu = hasMenu;
        this.menus_count = menus_count;
        this.menuId = menuId;
        this.menu_name = menu_name;
        this.menu_description = menu_description;
        this.sections_count = sections_count;
        this.section_name = section_name;
        this.sectionId = sectionId;
        this.section_description = section_description;
        this.entries_count = entries_count;
        this.entryId = entryId;
        this.entry_name = entry_name;
        this.price = price;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOpen() {
        return open;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public Boolean getIsopen() {
        return Isopen;
    }

    public void setIsopen(Boolean Isopen) {
        this.Isopen = Isopen;
    }

    public Boolean getHasMenu() {
        return hasMenu;
    }

    public void setHasMenu(Boolean hasMenu) {
        this.hasMenu = hasMenu;
    }

    public long getMenus_count() {
        return menus_count;
    }

    public void setMenus_count(long menus_count) {
        this.menus_count = menus_count;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getMenu_name() {
        return menu_name;
    }

    public void setMenu_name(String menu_name) {
        this.menu_name = menu_name;
    }

    public String getMenu_description() {
        return menu_description;
    }

    public void setMenu_description(String menu_description) {
        this.menu_description = menu_description;
    }

    public long getSections_count() {
        return sections_count;
    }

    public void setSections_count(long sections_count) {
        this.sections_count = sections_count;
    }

    public String getSection_name() {
        return section_name;
    }

    public void setSection_name(String section_name) {
        this.section_name = section_name;
    }

    public String getSectionId() {
        return sectionId;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }

    public String getSection_description() {
        return section_description;
    }

    public void setSection_description(String section_description) {
        this.section_description = section_description;
    }

    public long getEntries_count() {
        return entries_count;
    }

    public void setEntries_count(long entries_count) {
        this.entries_count = entries_count;
    }

    public String getEntryId() {
        return entryId;
    }

    public void setEntryId(String entryId) {
        this.entryId = entryId;
    }

    public String getEntry_name() {
        return entry_name;
    }

    public void setEntry_name(String entry_name) {
        this.entry_name = entry_name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "EE_VenuesDetailsFoursquareModel{" + "phone=" + phone + ", facebook=" + facebook + ", instagram=" + instagram + ", twitter=" + twitter + ", status=" + status + ", open=" + open + ", day=" + day + ", Isopen=" + Isopen + ", hasMenu=" + hasMenu + ", menus_count=" + menus_count + ", menuId=" + menuId + ", menu_name=" + menu_name + ", menu_description=" + menu_description + ", sections_count=" + sections_count + ", section_name=" + section_name + ", sectionId=" + sectionId + ", section_description=" + section_description + ", entries_count=" + entries_count + ", entryId=" + entryId + ", entry_name=" + entry_name + ", price=" + price + '}';
    }
    

}