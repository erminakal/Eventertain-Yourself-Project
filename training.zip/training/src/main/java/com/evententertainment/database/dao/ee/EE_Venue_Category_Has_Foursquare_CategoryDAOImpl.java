/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.EE_Venue_Category_Has_Foursquare_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EE_Venue_Category_Has_Foursquare_CategoryDAOImpl implements EE_Venue_Category_Has_Foursquare_CategoryDAO {

    private static final String TABLE = "ee_venue_category_has_foursquare_category";
    private static final String SQL_LIST_ORDER_BY_EE_VENUE_CATEGORY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_EE_VENUE_CATEGORY_ID = "SELECT * FROM " + TABLE + " WHERE `ee_venue_category_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`ee_venue_category_id`,`foursquare_category_id`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`ee_venue_category_id`,`foursquare_category_id`) WHERE `ee_venue_category_id` = ?";
    private static final String SQL_DELETE_BY_EE_VENUE_CATEGORY_ID = "DELETE FROM " + TABLE + " WHERE `ee_venue_category_id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static EE_Venue_Category_Has_Foursquare_CategoryModel map(ResultSet resultSet) throws SQLException {
        EE_Venue_Category_Has_Foursquare_CategoryModel object = new EE_Venue_Category_Has_Foursquare_CategoryModel();

        object.setEe_venue_category_id(resultSet.getLong("ee_venue_category_id"));
        object.setFoursquare_category_id(resultSet.getLong("foursquare_category_id"));

        return object;
    }

    @Override
    public List<EE_Venue_Category_Has_Foursquare_CategoryModel> list() {
        List<EE_Venue_Category_Has_Foursquare_CategoryModel> venue_eventful_categories = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_EE_VENUE_CATEGORY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                venue_eventful_categories.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return venue_eventful_categories;
    }

    @Override
    public EE_Venue_Category_Has_Foursquare_CategoryModel find(long ee_venue_category_id) {
        EE_Venue_Category_Has_Foursquare_CategoryModel venue_category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_EE_VENUE_CATEGORY_ID, ee_venue_category_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                venue_category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return venue_category;
    }

    @Override
    public int create(EE_Venue_Category_Has_Foursquare_CategoryModel c) {
        int ret = -1;

        Object[] values = {c.getEe_venue_category_id(), c.getFoursquare_category_id()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {

            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }
            return ret;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(EE_Venue_Category_Has_Foursquare_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getEe_venue_category_id(), c.getFoursquare_category_id());) {

            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long ee_venue_category_id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_EE_VENUE_CATEGORY_ID, ee_venue_category_id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

}
