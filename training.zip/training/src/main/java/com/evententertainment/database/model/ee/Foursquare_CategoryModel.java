package com.evententertainment.database.model.ee;

import java.util.ArrayList;

public class Foursquare_CategoryModel {

    private long id;
    private Long parent_category_id;
    private String api_id;
    private String name;
    private String pluralName;
    private String shortName;


    //relationships
    private ArrayList<Foursquare_CategoryModel> subcategories = new ArrayList<Foursquare_CategoryModel>();
     private EE_Venue_Category_Has_Eventful_CategoryModel cecModel=null;

    private EE_Venue_Category_Has_Foursquare_CategoryModel cfcModel = null;

    public Foursquare_CategoryModel() {

    }

    public Foursquare_CategoryModel(long id, Long parent_category_id, String api_id, String name, String pluralName, String shortName) {
        this.id = id;
        this.parent_category_id = parent_category_id;
        this.api_id = api_id;
        this.name = name;
        this.pluralName = pluralName;
        this.shortName = shortName;
       
    }

    public void print(String spaces) {
        System.out.println(spaces + " + " + name + " with unique id: " + api_id
                + ". The short name is: " + shortName + " and the plural is " + pluralName);

        for (Foursquare_CategoryModel o : subcategories) {
            o.print(spaces + "    ");
        }
    }

    public void print() {
        String spaces = "";
        print(spaces);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Long getParent_category_id() {
        return parent_category_id;
    }

    public void setParent_category_id(Long parent_category_id) {
        this.parent_category_id = parent_category_id;
    }

    public String getApi_id() {
        return api_id;
    }

    public void setApi_id(String api_id) {
        this.api_id = api_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPluralName() {
        return pluralName;
    }

    public void setPluralName(String pluralName) {
        this.pluralName = pluralName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public ArrayList<Foursquare_CategoryModel> getSubcategories() {
        return subcategories;
    }

    public void setSubcategories(ArrayList<Foursquare_CategoryModel> subcategories) {
        this.subcategories = subcategories;
    }

    public EE_Venue_Category_Has_Eventful_CategoryModel getCecModel() {
        return cecModel;
    }

    public void setCecModel(EE_Venue_Category_Has_Eventful_CategoryModel cecModel) {
        this.cecModel = cecModel;
    }

    public EE_Venue_Category_Has_Foursquare_CategoryModel getCfcModel() {
        return cfcModel;
    }

    public void setCfcModel(EE_Venue_Category_Has_Foursquare_CategoryModel cfcModel) {
        this.cfcModel = cfcModel;
    }

   
    
    public Long setParent_category_id() {
        return parent_category_id;
    }

    @Override
    public String toString() {
        return "Foursquare_CategoryModel{" + "id=" + id + ", parent_category_id=" + parent_category_id + ", api_id=" + api_id + ", name=" + name + ", pluralName=" + pluralName + ", shortName=" + shortName + ", subcategories=" + subcategories + ", cecModel=" + cecModel + ", cfcModel=" + cfcModel + '}';
    }

    
    
}
