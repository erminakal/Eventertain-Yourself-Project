/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.Eventful_Event_CategoryModel;
import com.evententertainment.database.model.ee.Eventful_Event_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Eventful_Event_CategoryDAOImpl implements Eventful_Event_CategoryDAO {

    private static final String TABLE = "eventful_event_category";
    private static final String SQL_LIST_ORDER_BY_NAME = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_FIND_BY_CATEGORY_API_ID = "SELECT * FROM " + TABLE + " WHERE `api_id` like ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`api_id`,`name`) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`api_id`,`name`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_DELETE_ALL = "DELETE FROM " + TABLE + "";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Eventful_Event_CategoryModel map(ResultSet resultSet) throws SQLException {
        Eventful_Event_CategoryModel object = new Eventful_Event_CategoryModel();

        object.setId(resultSet.getInt("id"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setName(resultSet.getString("name"));

        return object;
    }

    @Override
    public int deleteAll() {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_ALL);) {
            int affectedrows = statement.executeUpdate();
            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return 0;
        }
    }

  @Override
    public List<Eventful_Event_CategoryModel> listByName() {
        List<Eventful_Event_CategoryModel> categories = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_NAME);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                categories.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return categories;
    }

    @Override
    public Eventful_Event_CategoryModel find(long id) {
        Eventful_Event_CategoryModel category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return category;
    }
    public Eventful_Event_CategoryModel find(String api_id) {
        Eventful_Event_CategoryModel category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_CATEGORY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return category;
    }

    @Override
    public int create(Eventful_Event_CategoryModel c) {
        int ret = -1;
        Object[] values = {c.getApi_id(), c.getName()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(Eventful_Event_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getApi_id(), c.getName());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
