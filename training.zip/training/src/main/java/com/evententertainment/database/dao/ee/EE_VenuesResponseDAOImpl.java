package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.request.EE_FindVenuesFromSelectedEventRequest;
import com.evententertainment.database.model.ee.request.EE_Free_Search_VenuesRequest;
import com.evententertainment.database.model.ee.request.EE_VenueRequest;
import com.evententertainment.database.model.ee.response.EE_VenuesDetailsFoursquareModel;
import com.evententertainment.database.model.ee.response.EE_VenuesResponseModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EE_VenuesResponseDAOImpl implements EE_VenuesResponseDAO {

    private static final String SQL_LIST_DETAILS = "select\n"
            + "fco.formattedPhone as phone,"
            + "fco.facebook,"
            + "fco.instagram,"
            + "fco.twitter,"
            + "fop.status,"
            + "fop.open,"
            + "fop.day,"
            + "fop.isOpen,"
            + "fv.hasMenu,"
            + "fm.menus_count,"
            + "fmp.menuId,"
            + "fmp.name as menu_name,"
            + "fmp.description as menu_description,"
            + "fmp.sections_count,"
            + "fs.section_name,"
            + "fs.sectionId,"
            + "fs.description as section_description,"
            + "fs.entries_count,"
            + "fen.entryId,"
            + "fen.entry_name,"
            + "fen.price"
            + "from foursquare_venue fv"
            + "inner join foursquare_location fl on fv.id=fl.venue_id"
            + "inner join foursquare_contact fco on fv.id=fco.venue_id"
            + "inner join foursquare_operation fop on fv.id=fop.venue_id"
            + "inner join foursquare_menu fm on fv.id=fm.venue_id"
            + "inner join foursquare_menu_parts fmp on fm.id=fmp.venue_menu_id"
            + "inner join foursquare_section fs on fmp.id=fs.menu_parts_id"
            + "inner join foursquare_entry fen on fs.id=fen.section_id"
            + "left outer join foursquare_venue_has_category fvhs on fv.id=fvhs.venue_id ";

    private static final String SQL_SEARCH_BY_NAME = "select \n"
            + " ev.id,\n"
            + " \"eventful\" as source,\n"
            + " ev.api_id,\n"
            + " ev.url,\n"
            + " ev.name as venue_name,\n"
            + " ev.description,\n"
            + " eevc.name as category,\n"
            + " ev.address,\n"
            + " ev.postal_code,\n"
            + " ev.city_name,\n"
            + " ev.region_name,\n"
            + " ev.country_name,\n"
            + " ev.latitude,\n"
            + " ev.longitude,\n"
            + "  null as phone,\n"
            + " null as facebook,\n"
            + " null as instagram,\n"
            + " null as twitter,\n"
            + " null as status,\n"
            + "  null as open,\n"
            + " null as day,\n"
            + " null as isOpen,\n"
            + " null as hasMenu,\n"
            + "   null as menus_count,\n"
            + " null as menuId,\n"
            + " null as menu_name,\n"
            + " null as menu_description,\n"
            + "  null as sections_count,\n"
            + " null as section_name,\n"
            + " null as sectionId,\n"
            + " null as section_description,\n"
            + " null as entries_count,\n"
            + " null as entryId,\n"
            + " null as entry_name,\n"
            + "  null as price \n"
            + " "
            + "from eventful_venue ev\n"
            + "\n"
            + "left outer join eventful_event ee on ev.id=ee.venue_id\n"
            + "inner join eventful_venue_has_venue_category evhvc on ev.id=evhvc.eventful_venue_id\n"
            + "inner join eventful_venue_category evc on evc.id=evhvc.eventful_venue_category_id\n"
            + "inner join ee_venue_category_has_eventful_category eevcec on evc.id=eevcec.eventful_venue_category_id\n"
            + "inner join ee_venue_category eevc on eevc.id=eevcec.ee_venue_category_id\n"
            + ""
            + "where \n "
            + "eevc.id = ? and \n "
            + "ev.city_name = ? and \n "
            + "st_distance_sphere(Point(ev.latitude,ev.longitude),Point(?,?)) <= ? "
            + "\n"
            + "union all\n"
            + "\n"
            + "select\n"
            + " fv.id,\n"
            + " \"foursquare\" as source,\n"
            + " fv.api_id,\n"
            + " fv.url,\n"
            + " fv.name as venue_name,\n"
            + " fv.description,\n"
            + "eevc.name as category,\n"
            + " fl.address,\n"
            + " fl.postalCode,\n"
            + " fl.city as city_name,\n"
            + " fl.state as region_name,\n"
            + " fl.country as country_name,\n"
            + " fl.latitude,\n"
            + " fl.longitude,\n"
            + " fco.formattedPhone as phone,\n"
            + " fco.facebook,\n"
            + " fco.instagram,\n"
            + " fco.twitter,\n"
            + " fop.status,\n"
            + " fop.open,\n"
            + " fop.day,\n"
            + " fop.isOpen,\n"
            + " fv.hasMenu,\n"
            + "  fm.menus_count,\n"
            + "  fmp.menuId,\n"
            + "  fmp.name as menu_name,\n"
            + " fmp.description as menu_description,\n"
            + " fmp.sections_count,\n"
            + " fs.section_name,\n"
            + " fs.sectionId,\n"
            + " fs.description as section_description,\n"
            + " fs.entries_count,\n"
            + " fen.entryId,\n"
            + " fen.entry_name,\n"
            + " fen.price\n"
            + " \n"
            + "from foursquare_venue fv\n"
            + "\n"
            + "inner join foursquare_location fl on fv.id=fl.venue_id\n"
            + " inner join foursquare_contact fco on fv.id=fco.venue_id\n"
            + " left outer join foursquare_operation fop on fv.id=fop.venue_id\n"
            + " inner join foursquare_menu fm on fv.id=fm.venue_id\n"
            + " inner join foursquare_menu_parts fmp on fm.id=fmp.venue_menu_id\n"
            + " inner join foursquare_section fs on fmp.id=fs.menu_parts_id\n"
            + " inner join foursquare_entry fen on fs.id=fen.section_id\n"
            + "\n"
            + "left outer join foursquare_venue_has_category fvhs on fv.id=fvhs.venue_id \n"
            + "left outer join foursquare_category fc on fc.id = fvhs.category_id    \n"
            + "left outer join ee_venue_category_has_foursquare_category eevcfc on eevcfc.foursquare_category_id=fc.id\n"
            + "left outer join ee_venue_category eevc on eevc.id=eevcfc.ee_venue_category_id "
            + "\n"
            + "where \n"
            + "eevc.id= ? and\n "
            + " fl.city= ?  and\n"
            + "st_distance_sphere(Point(fl.latitude,fl.longitude),Point(?,?)) <= ? ";

    private static final String SQL_SEARCH_VENUES_FROM_SELECTED_EVENT = "select \n"
            + " ev.id,\n"
            + " \"eventful\" as source,\n"
            + " ev.api_id,\n"
            + " ev.url,\n"
            + " ev.name as venue_name,\n"
            + " ev.description,\n"
            + " eevc.name as category,\n"
            + " ev.address,\n"
            + " ev.postal_code,\n"
            + " ev.city_name,\n"
            + " ev.region_name,\n"
            + " ev.country_name,\n"
            + " ev.latitude,\n"
            + " ev.longitude,\n"
            + "  null as phone,\n"
            + " null as facebook,\n"
            + " null as instagram,\n"
            + " null as twitter,\n"
            + " null as status,\n"
            + "  null as open,\n"
            + " null as day,\n"
            + " null as isOpen,\n"
            + " null as hasMenu,\n"
            + "   null as menus_count,\n"
            + " null as menuId,\n"
            + " null as menu_name,\n"
            + " null as menu_description,\n"
            + "  null as sections_count,\n"
            + " null as section_name,\n"
            + " null as sectionId,\n"
            + " null as section_description,\n"
            + " null as entries_count,\n"
            + " null as entryId,\n"
            + " null as entry_name,\n"
            + "  null as price \n"
            + " "
            + "from eventful_venue ev\n"
            + "\n"
            + "left outer join eventful_event ee on ev.id=ee.venue_id\n"
            + "inner join eventful_venue_has_venue_category evhvc on ev.id=evhvc.eventful_venue_id\n"
            + "inner join eventful_venue_category evc on evc.id=evhvc.eventful_venue_category_id\n"
            + "inner join ee_venue_category_has_eventful_category eevcec on evc.id=eevcec.eventful_venue_category_id\n"
            + "inner join ee_venue_category eevc on eevc.id=eevcec.ee_venue_category_id\n"
            + ""
            + "where \n "
            + "ee.api_id= ? and \n"
            + "eevc.id = ? and \n "
            + "st_distance_sphere(Point(ee.latitude,ee.longitude),Point(?,?)) <= ? "
            + "\n"
            + "union all\n"
            + "\n"
            + "select\n"
            + " fv.id,\n"
            + " \"foursquare\" as source,\n"
            + " fv.api_id,\n"
            + " fv.url,\n"
            + " fv.name as venue_name,\n"
            + " fv.description,\n"
            + "eevc.name as category,\n"
            + " fl.address,\n"
            + " fl.postalCode,\n"
            + " fl.city as city_name,\n"
            + " fl.state as region_name,\n"
            + " fl.country as country_name,\n"
            + " fl.latitude,\n"
            + " fl.longitude,\n"
            + " fco.formattedPhone as phone,\n"
            + " fco.facebook,\n"
            + " fco.instagram,\n"
            + " fco.twitter,\n"
            + " fop.status,\n"
            + " fop.open,\n"
            + " fop.day,\n"
            + " fop.isOpen,\n"
            + " fv.hasMenu,\n"
            + "  fm.menus_count,\n"
            + "  fmp.menuId,\n"
            + "  fmp.name as menu_name,\n"
            + " fmp.description as menu_description,\n"
            + " fmp.sections_count,\n"
            + " fs.section_name,\n"
            + " fs.sectionId,\n"
            + " fs.description as section_description,\n"
            + " fs.entries_count,\n"
            + " fen.entryId,\n"
            + " fen.entry_name,\n"
            + " fen.price\n"
            + " \n"
            + "from foursquare_venue fv\n"
            + "\n"
            + "inner join foursquare_location fl on fv.id=fl.venue_id\n"
            + " inner join foursquare_contact fco on fv.id=fco.venue_id\n"
            + " left outer join foursquare_operation fop on fv.id=fop.venue_id\n"
            + " inner join foursquare_menu fm on fv.id=fm.venue_id\n"
            + " inner join foursquare_menu_parts fmp on fm.id=fmp.venue_menu_id\n"
            + " inner join foursquare_section fs on fmp.id=fs.menu_parts_id\n"
            + " inner join foursquare_entry fen on fs.id=fen.section_id\n"
            + "inner join foursquare_event fe on fe.venue_id=fv.id \n"
            + "\n"
            + "left outer join foursquare_venue_has_category fvhs on fv.id=fvhs.venue_id \n"
            + "left outer join foursquare_category fc on fc.id = fvhs.category_id    \n"
            + "left outer join ee_venue_category_has_foursquare_category eevcfc on eevcfc.foursquare_category_id=fc.id\n"
            + "left outer join ee_venue_category eevc on eevc.id=eevcfc.ee_venue_category_id "
            + "\n"
            + "where \n"
            + "fe.api_id=? and\n"
            + "eevc.id= ? and\n "
            + "st_distance_sphere(Point(fl.latitude,fl.longitude),Point(?,?)) <= ? ";

    private static final String SQL_SEARCH_ALL = "select \n"
            + " ev.id,\n"
            + " \"eventful\" as source,\n"
            + " ev.api_id,\n"
            + " ev.url,\n"
            + " ev.name as venue_name,\n"
            + " ev.description,\n"
            + " eevc.name as category,\n"
            + " ev.address,\n"
            + " ev.postal_code,\n"
            + " ev.city_name,\n"
            + " ev.region_name,\n"
            + " ev.country_name,\n"
            + " ev.latitude,\n"
            + " ev.longitude,\n"
            + "  null as phone,\n"
            + " null as facebook,\n"
            + " null as instagram,\n"
            + " null as twitter,\n"
            + " null as status,\n"
            + "  null as open,\n"
            + " null as day,\n"
            + " null as isOpen,\n"
            + " null as hasMenu,\n"
            + "   null as menus_count,\n"
            + " null as menuId,\n"
            + " null as menu_name,\n"
            + " null as menu_description,\n"
            + "  null as sections_count,\n"
            + " null as section_name,\n"
            + " null as sectionId,\n"
            + " null as section_description,\n"
            + " null as entries_count,\n"
            + " null as entryId,\n"
            + " null as entry_name,\n"
            + "  null as price \n"
            + " \n"
            + "from eventful_venue ev\n"
            + "\n"
            + "left outer join eventful_event ee on ev.id=ee.venue_id\n"
            + "inner join eventful_venue_has_venue_category evhvc on ev.id=evhvc.eventful_venue_id\n"
            + "inner join eventful_venue_category evc on evc.id=evhvc.eventful_venue_category_id\n"
            + "inner join ee_venue_category_has_eventful_category eevcec on evc.id=eevcec.eventful_venue_category_id\n"
            + "inner join ee_venue_category evc on evc.id=eevcec.ee_venue_category_id"
            + ""
            + "where \n "
            + "ev.tag like ?"
            + "\n"
            + "union all\n"
            + "\n"
            + "select\n"
            + " fv.id,\n"
            + " \"foursquare\" as source,\n"
            + " fv.api_id,\n"
            + " fv.url,\n"
            + " fv.name as venue_name,\n"
            + " fv.description,\n"
            + "eevc.name as category,\n"
            + " fl.address,\n"
            + " fl.postalCode,\n"
            + " fl.city as city_name,\n"
            + " fl.state as region_name,\n"
            + " fl.country as country_name,\n"
            + " fl.latitude,\n"
            + " fl.longitude,\n"
            + " fco.formattedPhone as phone,\n"
            + " fco.facebook,\n"
            + " fco.instagram,\n"
            + " fco.twitter,\n"
            + " fop.status,\n"
            + " fop.open,\n"
            + " fop.day,\n"
            + " fop.isOpen,\n"
            + " fv.hasMenu,\n"
            + "  fm.menus_count,\n"
            + "  fmp.menuId,\n"
            + "  fmp.name as menu_name,\n"
            + " fmp.description as menu_description,\n"
            + " fmp.sections_count,\n"
            + " fs.section_name,\n"
            + " fs.sectionId,\n"
            + " fs.description as section_description,\n"
            + " fs.entries_count,\n"
            + " fen.entryId,\n"
            + " fen.entry_name,\n"
            + " fen.price\n"
            + " \n"
            + "from foursquare_venue fv\n"
            + "\n"
            + "inner join foursquare_location fl on fv.id=fl.venue_id\n"
            + " inner join foursquare_contact fco on fv.id=fco.venue_id\n"
            + " left outer join foursquare_operation fop on fv.id=fop.venue_id\n"
            + " inner join foursquare_menu fm on fv.id=fm.venue_id\n"
            + " inner join foursquare_menu_parts fmp on fm.id=fmp.venue_menu_id\n"
            + " inner join foursquare_section fs on fmp.id=fs.menu_parts_id\n"
            + " inner join foursquare_entry fen on fs.id=fen.section_id\n"
            + "\n"
            + "left outer join foursquare_venue_has_category fvhs on fv.id=fvhs.venue_id \n"
            + "left outer join foursquare_category fc on fc.id = fvhs.category_id    \n"
            + "left outer join ee_venue_category_has_foursquare_category eevcfc on eevcfc.foursquare_category_id=fc.id\n"
            + "left outer join ee_venue_category evc on evc.id=eevcfc.ee_venue_category_id "
            + "\n"
            + "where \n"
            + "fv.tag like ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static EE_VenuesResponseModel map(ResultSet resultSet) throws SQLException {
        EE_VenuesResponseModel object = new EE_VenuesResponseModel();

        object.setId(resultSet.getLong("id"));
        object.setSource(resultSet.getString("source"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setUrl(resultSet.getString("url"));
        object.setVenue_name(resultSet.getString("venue_name"));
        object.setDescription(resultSet.getString("description"));
        object.setCategory(resultSet.getString("category"));
        object.setAddress(resultSet.getString("address"));
        object.setPostal_code(resultSet.getString("postal_code"));
        object.setCity_name(resultSet.getString("city_name"));
        object.setRegion_name(resultSet.getString("region_name"));
        object.setCountry_name(resultSet.getString("country_name"));
        object.setLatitude(resultSet.getFloat("latitude"));
        object.setLongitude(resultSet.getFloat("longitude"));

        return object;
    }

    private static EE_VenuesDetailsFoursquareModel map_details(ResultSet resultSet) throws SQLException {
        EE_VenuesDetailsFoursquareModel object = new EE_VenuesDetailsFoursquareModel();
        object.setPhone(resultSet.getString("phone"));
        object.setFacebook(resultSet.getString("facebook"));
        object.setInstagram(resultSet.getString("instagram"));
        object.setTwitter(resultSet.getString("twitter"));
        object.setStatus(resultSet.getString("status"));
        object.setOpen(resultSet.getString("open"));
        object.setDay(resultSet.getString("day"));
        object.setIsopen(resultSet.getBoolean("Isopen"));
        object.setHasMenu(resultSet.getBoolean("hasMenu"));
        object.setMenus_count(resultSet.getLong("menus_count"));
        object.setMenuId(resultSet.getString("menuId"));
        object.setMenu_name(resultSet.getString("menu_name"));
        object.setMenu_description(resultSet.getString("menu_description"));
        object.setSections_count(resultSet.getLong("sections_count"));
        object.setSection_name(resultSet.getString("section_name"));
        object.setSectionId(resultSet.getString("sectionId"));
        object.setSection_description(resultSet.getString("section_description"));
        object.setEntries_count(resultSet.getLong("entries_count"));
        object.setEntryId(resultSet.getString("entryId"));
        object.setEntry_name(resultSet.getString("entry_name"));
        object.setPrice(resultSet.getString("price"));

        return object;
    }

    @Override
    public List<EE_VenuesResponseModel> list() {
        List<EE_VenuesResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_BY_NAME);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_VenuesDetailsFoursquareModel> list_details() {
        List<EE_VenuesDetailsFoursquareModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_DETAILS);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                result.add(map_details(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_VenuesResponseModel> search(EE_VenueRequest request) {
        List<EE_VenuesResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_BY_NAME);) {
            statement.setLong(1, request.getSelectedVenueCategory());
            statement.setString(2, request.getSelectedVenuePlace());
            statement.setDouble(3, request.getLatitude());
            statement.setDouble(4, request.getLongitude());
            statement.setDouble(5, request.getDistance() * 1000);

            statement.setLong(6, request.getSelectedVenueCategory());
            statement.setString(7, request.getSelectedVenuePlace());
            statement.setDouble(8, request.getLatitude());
            statement.setDouble(9, request.getLongitude());
            statement.setDouble(10, request.getDistance() * 1000);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_VenuesResponseModel> search_all(EE_Free_Search_VenuesRequest request) {
        List<EE_VenuesResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_ALL);) {

            statement.setString(1, request.getTag());
            statement.setString(2, request.getTag());

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_VenuesResponseModel> search_venues_close_to_event(EE_FindVenuesFromSelectedEventRequest request) {
        List<EE_VenuesResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_VENUES_FROM_SELECTED_EVENT);) {
            
            statement.setString(1, request.getEventApiId());
            statement.setLong(2, request.getSelectedVenueCategory());
            statement.setDouble(3, request.getLatitude());
            statement.setDouble(4, request.getLongitude());
            statement.setDouble(5, request.getDistance() * 1000);
            statement.setString(6, request.getEventApiId());
            statement.setLong(7, request.getSelectedVenueCategory());

            statement.setDouble(8, request.getLatitude());
            statement.setDouble(9, request.getLongitude());
            statement.setDouble(10, request.getDistance() * 1000);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
        return result;
    }

}
