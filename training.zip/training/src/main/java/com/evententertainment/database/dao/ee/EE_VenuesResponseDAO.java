/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.request.EE_FindVenuesFromSelectedEventRequest;
import com.evententertainment.database.model.ee.request.EE_Free_Search_VenuesRequest;
import com.evententertainment.database.model.ee.request.EE_VenueRequest;
import com.evententertainment.database.model.ee.response.EE_VenuesDetailsFoursquareModel;
import com.evententertainment.database.model.ee.response.EE_VenuesResponseModel;
import java.util.List;

public interface EE_VenuesResponseDAO {

    public List<EE_VenuesResponseModel> list();

    public List<EE_VenuesDetailsFoursquareModel> list_details();

    public List<EE_VenuesResponseModel> search_all(EE_Free_Search_VenuesRequest request);

    public List<EE_VenuesResponseModel> search(EE_VenueRequest request);

    public List<EE_VenuesResponseModel> search_venues_close_to_event(EE_FindVenuesFromSelectedEventRequest request);

}
