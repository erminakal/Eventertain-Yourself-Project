package com.evententertainment.database.model.ee;

public class Eventful_Venue_CategoryModel {

    private Long id;
    private String venue_category;

       // relationships
    //private Eventful_Venue_Connect_Venue_CategoryModel venue_connect_categorycModel = null;  
     
    
    public Eventful_Venue_CategoryModel() {
    }

    public Eventful_Venue_CategoryModel(Long id, String venue_category) {
        this.id = id;
        this.venue_category = venue_category;
    }

    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVenue_category() {
        return venue_category;
    }

    public void setVenue_category(String venue_category) {
        this.venue_category = venue_category;
    }

//    public Eventful_Venue_Connect_Venue_CategoryModel getVenue_connect_categorycModel() {
//        return venue_connect_categorycModel;
//    }
//
//    public void setVenue_connect_categorycModel(Eventful_Venue_Connect_Venue_CategoryModel venue_connect_categorycModel) {
//        this.venue_connect_categorycModel = venue_connect_categorycModel;
//    }

    @Override
    public String toString() {
        return "Eventful_Venue_CategoryModel{" + "id=" + id + ", venue_category=" + venue_category + '}';
    }

  
    
    

}
