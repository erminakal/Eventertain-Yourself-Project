/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.model.ee.request;


public class EE_Free_Search_EventsRequest {
    
    
    String tagword;

    public EE_Free_Search_EventsRequest() {
    }
    
    

    public EE_Free_Search_EventsRequest(String tagword) {
        this.tagword = tagword;
    }

    public String getTagword() {
        return tagword;
    }

    public void setTagword(String tagword) {
        this.tagword = tagword;
    }

    @Override
    public String toString() {
        return "EE_Free_Search_EventsRequest{" + "tagword=" + tagword + '}';
    }

  

    
   
  
    
    
    
    
    
}
