package com.evententertainment.database.model.ee;

public class EE_Venue_Category_Has_Eventful_CategoryModel {

    private long ee_venue_category_id;
    private long eventful_venue_category_id;

    public EE_Venue_Category_Has_Eventful_CategoryModel() {
    }

    public EE_Venue_Category_Has_Eventful_CategoryModel(long ee_venue_category_id, long eventful_venue_category_id) {
        this.ee_venue_category_id = ee_venue_category_id;
        this.eventful_venue_category_id = eventful_venue_category_id;
    }

    public long getEe_venue_category_id() {
        return ee_venue_category_id;
    }

    public void setEe_venue_category_id(long ee_venue_category_id) {
        this.ee_venue_category_id = ee_venue_category_id;
    }

    public long getEventful_venue_category_id() {
        return eventful_venue_category_id;
    }

    public void setEventful_venue_category_id(long eventful_venue_category_id) {
        this.eventful_venue_category_id = eventful_venue_category_id;
    }

    @Override
    public String toString() {
        return "EE_Venue_Category_Has_Eventful_CategoryModel{" + "ee_venue_category_id=" + ee_venue_category_id + ", eventful_venue_category_id=" + eventful_venue_category_id + '}';
    }

}
