/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.Eventful_Event_CategoryModel;
import java.util.List;

public interface Eventful_Event_CategoryDAO {

    /**
     *
     * @return
     */
    public List<Eventful_Event_CategoryModel> listByName();

    public Eventful_Event_CategoryModel find(long category_id);
    
    public Eventful_Event_CategoryModel find(String cat_api_id);

    public int create(Eventful_Event_CategoryModel c);

    public int update(Eventful_Event_CategoryModel c);

    public int delete(long category_id);   

    public int deleteAll();

    
}
