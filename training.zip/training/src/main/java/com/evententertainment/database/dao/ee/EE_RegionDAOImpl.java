/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

/**
 *
 * @author/* To change this license header, choose License Headers in Project
 * Properties. To change this template file, choose Tools | Templates and open
 * the template in the editor.
 */
import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.EE_RegionModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EE_RegionDAOImpl implements EE_RegionDAO {

    private static final String TABLE = "ee_region";
    private static final String SQL_LIST_ORDER_BY_NAME = "SELECT * FROM " + TABLE + " order by name asc";
    private static final String SQL_FIND_BY_NAME = "SELECT * FROM " + TABLE + " WHERE `name` = ?";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`name`,`description`,`latitude`,`longitude`) values (?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`name`,`description`,`latitude`,`longitude`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";
        private static final String SQL_DELETE_ALL = "DELETE FROM " + TABLE ;

    

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static EE_RegionModel map(ResultSet resultSet) throws SQLException {
        EE_RegionModel object = new EE_RegionModel();

        object.setId(resultSet.getInt("id"));
        object.setName(resultSet.getString("name"));
        object.setDescription(resultSet.getString("description"));
        object.setLatitude(resultSet.getDouble("latitude"));
        object.setLongitude(resultSet.getDouble("longitude"));

        return object;
    }

    @Override
    public List<EE_RegionModel> listByName() {
        List<EE_RegionModel> regions = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_NAME);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                regions.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return regions;
    }

    @Override
    public EE_RegionModel find(long id) {
        EE_RegionModel region = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                region = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return region;
    }

    @Override
    public EE_RegionModel findByName(String name) {
        EE_RegionModel region = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_NAME, name);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                region = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return region;
    }

    @Override
    public int create(EE_RegionModel c) {
        int ret = -1;
        Object[] values = {c.getName(), c.getDescription(), c.getLatitude(), c.getLongitude()};

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
            int affectedRows = statement.executeUpdate();
            ret = affectedRows;
            if (ret == 0) {
                System.err.println("Creating user failed, no rows affected.");
                return ret;
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    c.setId(generatedKeys.getInt(1));
                    return ret;
                } else {
                    System.err.println("Creating user failed, no generated key obtained.");
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return -1;
        }
    }

    @Override
    public int update(EE_RegionModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getName(), c.getDescription(), c.getLatitude(), c.getLongitude());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
@Override
    public void deleteAll() {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_ALL);) {
            int affectedrows = statement.executeUpdate();

        } catch (SQLException e) {
            System.err.println(e.getMessage());

        }
    }
}
