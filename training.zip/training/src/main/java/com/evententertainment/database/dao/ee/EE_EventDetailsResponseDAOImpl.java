package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.request.EE_EventDetailsRequest;
import com.evententertainment.database.model.ee.response.EE_EventsDetailsEventfulModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EE_EventDetailsResponseDAOImpl implements EE_EventDetailsResponseDAO {

    private static final String SQL_SEARCH_DETAILS = "select \n"
            + "\n"
            + "ee.title,\n"
            + "ee.description,\n"
            + "ee.url,\n"
            + "eec.name as category,\n"
            + "ee.price,\n"
            + "ee.start_time,\n"
            + "ee.venue_name,\n"
            + "ee.venue_address,\n"
            + "ee.city_name,\n"
            + "ee.region_name,\n"
            + "ee.country_name,\n"
            + "ep.name as performer_name,\n"
            + "ep.url as performer_url\n"
            + "\n"
            + "from eventful_event ee\n"
            + "\n"
            + "inner join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "inner join eventful_performer ep on ep.id=ehp.performer_id\n"
            + "inner join eventful_event_has_category eehc on eehc.event_id=ee.id\n"
            + "inner join eventful_event_category eec on eec.id=eehc.category_id\n"
            + "\n"
            + "where ee.api_id=? \n"
            + "\n"
            + "union all\n"
            + "\n"
            + "select \n"
            + "\n"
            + "    fe.name as title,\n"
            + "    null as description,\n"
            + "    fe.url, \n"
            + "    eec.name as category,\n"
            + "    null as price,\n"
            + "    fe.startAt as start_time, \n"
            + "    fv.name as venue_name,\n"
            + "    fl.address as venue_address,\n"
            + "    fl.city as city_name,\n"
            + "    fl.state as region_name,\n"
            + "    fl.country as country_name,\n"
            + "    null as performer_name,\n"
            + "    null as performer_url\n"
            + "    \n"
            + "    from foursquare_event fe\n"
            + "      inner join foursquare_venue fv on fe.venue_id=fv.id\n"
            + "      inner join foursquare_location fl on fl.venue_id = fv.id\n"
            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id\n"
            + "    \n"
            + "    where fe.api_id=? ";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static EE_EventsDetailsEventfulModel map_details(ResultSet resultSet) throws SQLException {
        EE_EventsDetailsEventfulModel object = new EE_EventsDetailsEventfulModel();

        object.setTitle(resultSet.getString("title"));
        object.setDescription(resultSet.getString("description"));
        object.setUrl(resultSet.getString("url"));
        object.setCategory(resultSet.getString("category"));
        object.setPrice(resultSet.getString("price"));
        object.setStart_time(resultSet.getString("start_time"));
        object.setVenue_name(resultSet.getString("venue_name"));
        object.setVenue_address(resultSet.getString("venue_address"));
        object.setCity_name(resultSet.getString("city_name"));
        object.setRegion_name(resultSet.getString("region_name"));
        object.setCountry_name(resultSet.getString("country_name"));
        object.setPerformer_name(resultSet.getString("performer_name"));
        object.setPerformer_url(resultSet.getString("performer_url"));

        return object;
    }

    @Override
    public List<EE_EventsDetailsEventfulModel> list() {
        List<EE_EventsDetailsEventfulModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_DETAILS);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                result.add(map_details(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_EventsDetailsEventfulModel> search_details(EE_EventDetailsRequest request) {
        List<EE_EventsDetailsEventfulModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_DETAILS);) {

            statement.setString(1, request.getApi_id());
            statement.setString(2, request.getApi_id());

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map_details(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
        return result;
    }
}
