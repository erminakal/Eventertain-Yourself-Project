/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.Foursquare_CategoryModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Foursquare_CategoryDAOImpl implements Foursquare_CategoryDAO {

    private static final String TABLE = "foursquare_category";
    private static final String SQL_LIST_ORDER_BY_ID = "SELECT * FROM " + TABLE;
    private static final String SQL_FIND_BY_API_ID = "SELECT * FROM " + TABLE + " WHERE `api_id` like ?";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM " + TABLE + " WHERE `id`=?";
    private static final String SQL_FIND_ID_BY_PARENT_CATEGORY_ID = "SELECT * FROM " + TABLE + " WHERE `parent_category_id` = ?";
    private static final String SQL_INSERT = "INSERT INTO " + TABLE + "(`parent_category_id`,`api_id`,`name`,`pluralName`,`shortName`) values (?,?,?,?,?)";
    private static final String SQL_INSERT_WITHOUT_PARENT = "INSERT INTO " + TABLE + "(`api_id`,`name`,`pluralName`,`shortName`) values (?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE " + TABLE + " SET (`parent_category_id`,`api_id`,`name`,`pluralName`,`shortName`) WHERE `id` = ?";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM " + TABLE + " WHERE `id` = ?";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static Foursquare_CategoryModel map(ResultSet resultSet) throws SQLException {
        Foursquare_CategoryModel object = new Foursquare_CategoryModel();

        object.setId(resultSet.getLong("id"));

        object.setParent_category_id(resultSet.getLong("parent_category_id"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setName(resultSet.getString("name"));
        object.setPluralName(resultSet.getString("pluralName"));
        object.setShortName(resultSet.getString("shortName"));

        return object;
    }

    @Override
    public List<Foursquare_CategoryModel> list() {
        List<Foursquare_CategoryModel> categories = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_ORDER_BY_ID);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                categories.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return categories;
    }

    @Override
    public Foursquare_CategoryModel find(String api_id) {
        Foursquare_CategoryModel category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return category;
    }

    @Override
    public Foursquare_CategoryModel find(long parent_category_id, long id) {
        Foursquare_CategoryModel category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_ID_BY_PARENT_CATEGORY_ID, parent_category_id, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return category;
    }
    
        @Override
    public Foursquare_CategoryModel find(long id) {
        Foursquare_CategoryModel category = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_ID, id);
                ResultSet resultSet = statement.executeQuery();) {
            if (resultSet.next()) {
                category = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return category;
    }

    @Override
    public int create(Foursquare_CategoryModel c) {
        int ret = -1;
        if (c.getParent_category_id() != null) {
            Object[] values = {c.getParent_category_id(), c.getApi_id(), c.getName(), c.getPluralName(), c.getShortName()};

            try (Connection connection = factory.getConnection();
                    PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT, values);) {
                int affectedRows = statement.executeUpdate();
                ret = affectedRows;
                if (ret == 0) {
                    System.err.println("Creating user failed, no rows affected.");
                    return ret;
                }

                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        c.setId(generatedKeys.getLong(1));
                        return ret;
                    } else {
                        System.err.println("Creating user failed, no generated key obtained.");
                        return -1;
                    }
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
                return -1;
            }
        } else {
            Object[] values = {c.getApi_id(), c.getName(), c.getPluralName(), c.getShortName()};

            try (Connection connection = factory.getConnection();
                    PreparedStatement statement = DAOUtil.prepareInsertStatement(connection, SQL_INSERT_WITHOUT_PARENT, values);) {
                int affectedRows = statement.executeUpdate();
                ret = affectedRows;
                if (ret == 0) {
                    System.err.println("Creating user failed, no rows affected.");
                    return ret;
                }

                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        c.setId(generatedKeys.getLong(1));
                        return ret;
                    } else {
                        System.err.println("Creating user failed, no generated key obtained.");
                        return -1;
                    }
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
                return -1;
            }
        }
    }

    @Override
    public int update(Foursquare_CategoryModel c) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_UPDATE, c.getParent_category_id(), c.getApi_id(), c.getName(), c.getPluralName(), c.getShortName());) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }

    @Override
    public int delete(long id) {
        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_DELETE_BY_ID, id);) {
            int affectedrows = statement.executeUpdate();

            return affectedrows;
        } catch (SQLException e) {
            System.err.println(e.getMessage());

            return -1;
        }
    }
}
