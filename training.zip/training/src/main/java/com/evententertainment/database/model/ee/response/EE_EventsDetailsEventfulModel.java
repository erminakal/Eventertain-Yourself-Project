package com.evententertainment.database.model.ee.response;

import java.util.logging.Logger;

public class EE_EventsDetailsEventfulModel {

    private String title;
    private String description;
    private String url;
    private String category;
    private String price;
    private String start_time;
    private String venue_name;
    private String venue_address;
    private String city_name;
    private String region_name;
    private String country_name;
    private String performer_name;
    private String performer_url;
    
    public EE_EventsDetailsEventfulModel() {
    }

    public EE_EventsDetailsEventfulModel(String title, String description, String url, String category, String price, String start_time, String venue_name, String venue_address, String city_name, String region_name, String country_name, String performer_name, String performer_url) {
        this.title = title;
        this.description = description;
        this.url = url;
        this.category = category;
        this.price = price;
        this.start_time = start_time;
        this.venue_name = venue_name;
        this.venue_address = venue_address;
        this.city_name = city_name;
        this.region_name = region_name;
        this.country_name = country_name;
        this.performer_name = performer_name;
        this.performer_url = performer_url;
    }

    
    
    

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getVenue_name() {
        return venue_name;
    }

    public void setVenue_name(String venue_name) {
        this.venue_name = venue_name;
    }

    public String getVenue_address() {
        return venue_address;
    }

    public void setVenue_address(String venue_address) {
        this.venue_address = venue_address;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getRegion_name() {
        return region_name;
    }

    public void setRegion_name(String region_name) {
        this.region_name = region_name;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public String getPerformer_name() {
        return performer_name;
    }

    public void setPerformer_name(String performer_name) {
        this.performer_name = performer_name;
    }

    public String getPerformer_url() {
        return performer_url;
    }

    public void setPerformer_url(String performer_url) {
        this.performer_url = performer_url;
    }

    @Override
    public String toString() {
        return "EE_EventsDetailsEventfulModel{" + "title=" + title + ", description=" + description + ", url=" + url + ", category=" + category + ", price=" + price + ", start_time=" + start_time + ", venue_name=" + venue_name + ", venue_address=" + venue_address + ", city_name=" + city_name + ", region_name=" + region_name + ", country_name=" + country_name + ", performer_name=" + performer_name + ", performer_url=" + performer_url + '}';
    }

    
    
   
    
    

}
