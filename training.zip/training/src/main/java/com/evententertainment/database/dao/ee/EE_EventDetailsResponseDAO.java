/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.request.EE_EventDetailsRequest;
import com.evententertainment.database.model.ee.request.EE_EventRequest;
import com.evententertainment.database.model.ee.request.EE_Free_Search_EventsRequest;
import com.evententertainment.database.model.ee.response.EE_EventsDetailsEventfulModel;
import com.evententertainment.database.model.ee.response.EE_EventsResponseModel;
import java.util.List;

public interface EE_EventDetailsResponseDAO {
 

    public List<EE_EventsDetailsEventfulModel> list();

     public List<EE_EventsDetailsEventfulModel> search_details(EE_EventDetailsRequest request);
    
   
    
   
}
