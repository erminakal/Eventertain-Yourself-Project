/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.evententertainment.database.dao.ee;

import com.evententertainment.database.model.ee.EE_Venue_Category_Has_Eventful_CategoryModel;
import java.util.List;

public interface EE_Venue_Category_Has_Eventful_CategoryDAO {
    public List<EE_Venue_Category_Has_Eventful_CategoryModel> list();

    public EE_Venue_Category_Has_Eventful_CategoryModel find(long ee_venue_category_id);
    

    public int create(EE_Venue_Category_Has_Eventful_CategoryModel c);

    public int update(EE_Venue_Category_Has_Eventful_CategoryModel c);

    public int delete(long ee_venue_category_id);    
}
