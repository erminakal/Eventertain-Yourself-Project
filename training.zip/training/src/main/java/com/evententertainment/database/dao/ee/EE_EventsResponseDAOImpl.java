package com.evententertainment.database.dao.ee;

import com.evententertainment.database.ConnectionFactory;
import com.evententertainment.database.DAOUtil;
import com.evententertainment.database.model.ee.request.EE_EventRequest;
import com.evententertainment.database.model.ee.request.EE_FindEventsFromSelectedVenueRequest;
import com.evententertainment.database.model.ee.request.EE_Free_Search_EventsRequest;
import com.evententertainment.database.model.ee.response.EE_EventsDetailsEventfulModel;
import com.evententertainment.database.model.ee.response.EE_EventsResponseModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class EE_EventsResponseDAOImpl implements EE_EventsResponseDAO {

    private static final String SQL_SEARCH_BY_NAME = "select \n"
            + "	ee.id, \n"
            + "    \"eventful\" as source,\n"
            + "    ee.api_id, \n"
            + "    ee.title as title,\n"
            + "    ee.description,\n"
            + "    eec.name as category,\n"
            + "    eec.id as category_id,\n"
            + "    ee.url,   \n"
            + "    ee.tag,\n"
            + "    ee.latitude, \n"
            + "    ee.longitude,\n"
            + "    ee.start_time,\n"
            + "    ee.stop_time,\n"
            + "    ee.venue_id,\n"
            + "    ee.venue_name,\n"
            + "    ee.venue_address,\n"
            + "    ee.city_name,\n"
            + "    ee.region_name,\n"
            + "    ee.country_name,\n"
            + "    ee.free,\n"
            + "    ee.price,\n"
            + "    ee.privacy,\n"
            + "    ee.withdrawn,\n"
            + "    ee.withdrawn_note,\n"
            + "    ep.api_id as performer_api_id,\n"
            + "    ep.name as performer_name,\n"
            + "    ep.category as performer_category,\n"
            + "    ep.long_bio as performer_bio,\n"
            + "    ep.url as performer_url\n"
            + "    \n"
            + "from eventful_event ee\n"
            + "left outer join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "    left outer join eventful_performer ep on ehp.performer_id=ep.id\n"
            + "	 left outer join eventful_event_has_category ehc on ehc.event_id = ee.id\n"
            + "    left outer join eventful_event_category eevc on ehc.category_id = eevc.id\n"
            + "    left outer  join ee_event_category_has_eventful_category echec on eevc.id = echec.eventful_event_category_id\n"
            + "    left outer  join ee_event_category eec on eec.id = echec.ee_event_category_id\n"
            + "    \n"
            + "\n"
            + "    "
            + "    where \n"
            + "	   ee.city_name = ? and\n"
            + "	   eec.id = ? and\n"
            + "    ee.start_time >= ? and\n"
            + "    ee.start_time <= ? and\n"
            + "    st_distance_sphere(Point(ee.latitude,ee.longitude),Point(?,?)) <= ? \n"
            + "union all\n"
            + "select \n"
            + "	fe.id, \n"
            + "    \"foursquare\" as source,\n"
            + "    fe.api_id, \n"
            + "    fe.name as title,\n"
            + "    fe.url, \n"
            + "    fe.tag,\n"
            + "    null as description,\n"
            + "    eec.name as category,\n"
            + "    eec.id as category_id,\n"
            + "    fl.latitude as latitude,\n"
            + "    fl.longitude as longitude,\n"
            + "    fe.startAt as start_time, \n"
            + "    fe.endAt as stop_time, \n"
            + "    fe.venue_id,\n"
            + "    fv.name as venue_name,\n"
            + "    fl.address as venue_address,\n"
            + "    fl.city as city_name,\n"
            + "    fl.state as region_name,\n"
            + "    fl.country as country_name,\n"
            + "    null as free,\n"
            + "    null as price,\n"
            + "    null as privacy,\n"
            + "    null as withdrawn,\n"
            + "    null as withdrawn_note,\n"
            + "    null as performer_api_id,\n"
            + "    null as performer_name,\n"
            + "    null as performer_category,\n"
            + "    null as performer_bio,\n"
            + "    null as performer_url    \n"
            + "from foursquare_event fe\n"
            + "inner join foursquare_venue fv on fe.venue_id=fv.id\n"
            + "inner join foursquare_location fl on fl.venue_id = fv.id\n"
            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id"
            + "    where \n"
            + "	   fl.city = ? and\n"
            + "	   eec.id = ?  and\n"
            + "    fe.startAt >= ? and\n"
            + "    fe.startAt <= ? and\n"
            + "    st_distance_sphere(Point(fl.latitude,fl.longitude),Point(?,?)) <= ?     \n"
            + "    order by title\n";

    private static final String SQL_FIND_BY_API_ID = "select \n"
            + "	ee.id, \n"
            + "    \"eventful\" as source,\n"
            + "    ee.api_id as api_id, \n"
            + "    ee.title as title,\n"
            + "    ee.description,\n"
            + "    eec.name as category,\n"
            + "    eec.id as category_id,\n"
            + "    ee.url,   \n"
            + "    ee.tag,\n"
            + "    ee.latitude, \n"
            + "    ee.longitude,\n"
            + "    ee.start_time,\n"
            + "    ee.stop_time,\n"
            + "    ee.venue_id,\n"
            + "    ee.venue_name,\n"
            + "    ee.venue_address,\n"
            + "    ee.city_name,\n"
            + "    ee.region_name,\n"
            + "    ee.country_name,\n"
            + "    ee.free,\n"
            + "    ee.price,\n"
            + "    ee.privacy,\n"
            + "    ee.withdrawn,\n"
            + "    ee.withdrawn_note,\n"
            + "    ep.api_id as performer_api_id,\n"
            + "    ep.name as performer_name,\n"
            + "    ep.category as performer_category,\n"
            + "    ep.long_bio as performer_bio,\n"
            + "    ep.url as performer_url\n"
            + "    \n"
            + "from eventful_event ee\n"
            + "left outer join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "    left outer join eventful_performer ep on ehp.performer_id=ep.id\n"
            + "	 left outer join eventful_event_has_category ehc on ehc.event_id = ee.id\n"
            + "    left outer join eventful_event_category eevc on ehc.category_id = eevc.id\n"
            + "    left outer  join ee_event_category_has_eventful_category echec on eevc.id = echec.eventful_event_category_id\n"
            + "    left outer  join ee_event_category eec on eec.id = echec.ee_event_category_id\n"
            + "    \n"
            + "\n"
            + "    "
            + "    where \n"
            + "	   ee.api_id = ? \n";
//              + "union all\n"
//            + "select \n"
//            + "	fe.id, \n"
//            + "    \"foursquare\" as source,\n"
//            + "    fe.api_id, \n"
//            + "    fe.name as title,\n"
//            + "    null as description,\n"
//              + "    eec.name as category,\n"
//             + "    eec.id as category_id,\n"
//            + "    fe.url, \n"
//            + "    fe.tag,\n"                   
//            + "    fl.latitude as latitude,\n"
//            + "    fl.longitude as longitude,\n"
//            + "    fe.startAt as start_time, \n"
//            + "    fe.endAt as stop_time, \n"
//            + "    fe.venue_id,\n"
//            + "    fv.name as venue_name,\n"
//            + "    fl.address as venue_address,\n"
//            + "    fl.city as city_name,\n"
//            + "    fl.state as region_name,\n"
//            + "    fl.country as country_name,\n"
//            + "    null as free,\n"
//            + "    null as price,\n"
//            + "    null as privacy,\n"
//            + "    null as withdrawn,\n"
//            + "    null as withdrawn_note,\n"
//            + "    null as performer_api_id,\n"
//            + "    null as performer_name,\n"
//            + "    null as performer_category,\n"
//            + "    null as performer_bio,\n"
//            + "    null as performer_url    \n"
//            + "from foursquare_event fe\n"
//            + "inner join foursquare_venue fv on fe.venue_id=fv.id\n"
//            + "inner join foursquare_location fl on fl.venue_id = fv.id\n"
//            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
//            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
//            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
//            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id"
//            + "    where \n"
//             + "fe.api_id = ? \n";

    private static final String SQL_LIST_DETAILS = "select \n"
            + "\n"
            + "ee.title,\n"
            + "ee.description,\n"
            + "ee.url,\n"
            + "eec.name as category,\n"
            + "ee.price,\n"
            + "ee.start_time,\n"
            + "ee.venue_name,\n"
            + "ee.venue_address,\n"
            + "ee.city_name,\n"
            + "ee.region_name,\n"
            + "ee.country_name,\n"
            + "ep.name as performer_name,\n"
            + "ep.url as performer_url\n"
            + "\n"
            + "from eventful_event ee\n"
            + "\n"
            + "inner join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "inner join eventful_performer ep on ep.id=ehp.performer_id\n"
            + "inner join eventful_event_has_category eehc on eehc.event_id=ee.id\n"
            + "inner join eventful_event_category eec on eec.id=eehc.category_id\n"
            + "\n";
//            + "where ee.api_id=? \n"
//            + "\n"
//            + "union all\n"
//            + "\n"
//            + "select \n"
//            + "\n"
//            + "    fe.name as title,\n"
//            + "    null as description,\n"
//            + "    fe.url, \n"
//            + "    eec.name as category,\n"
//            + "    null as price,\n"
//            + "    fe.startAt as start_time, \n"
//            + "    fv.name as venue_name,\n"
//            + "    fl.address as venue_address,\n"
//            + "    fl.city as city_name,\n"
//            + "    fl.state as region_name,\n"
//            + "    fl.country as country_name,\n"
//            + "    null as performer_name,\n"
//            + "    null as performer_url\n"
//            + "    \n"
//            + "    from foursquare_event fe\n"
//            + "      inner join foursquare_venue fv on fe.venue_id=fv.id\n"
//            + "      inner join foursquare_location fl on fl.venue_id = fv.id\n"
//            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
//            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
//            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
//            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id\n"
//            + "    \n"
//            + "    where fe.api_id=? ";

    private static final String SQL_SEARCH_EVENTS_FROM_SELECTED_VENUE = "select \n"
            + "	ee.id, \n"
            + "    \"eventful\" as source,\n"
            + "    ee.api_id, \n"
            + "    ee.title as title,\n"
            + "    ee.description,\n"
            + "    eec.name as category,\n"
            + "    eec.id as category_id,\n"
            + "    ee.url,   \n"
            + "    ee.tag,\n"
            + "    ee.latitude, \n"
            + "    ee.longitude,\n"
            + "    ee.start_time,\n"
            + "    ee.stop_time,\n"
            + "    ee.venue_id,\n"
            + "    ee.venue_name,\n"
            + "    ee.venue_address,\n"
            + "    ee.city_name,\n"
            + "    ee.region_name,\n"
            + "    ee.country_name,\n"
            + "    ee.free,\n"
            + "    ee.price,\n"
            + "    ee.privacy,\n"
            + "    ee.withdrawn,\n"
            + "    ee.withdrawn_note,\n"
            + "    ep.api_id as performer_api_id,\n"
            + "    ep.name as performer_name,\n"
            + "    ep.category as performer_category,\n"
            + "    ep.long_bio as performer_bio,\n"
            + "    ep.url as performer_url\n"
            + "    \n"
            + "from eventful_event ee\n"
            + "left outer join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "    left outer join eventful_performer ep on ehp.performer_id=ep.id\n"
            + "	 left outer join eventful_event_has_category ehc on ehc.event_id = ee.id\n"
            + "    left outer join eventful_event_category eevc on ehc.category_id = eevc.id\n"
            + "    left outer  join ee_event_category_has_eventful_category echec on eevc.id = echec.eventful_event_category_id\n"
            + "    left outer  join ee_event_category eec on eec.id = echec.ee_event_category_id\n"
            + "    \n"
            + "\n"
            + "    "
            + "    where \n"
            + "	   ee.venue_id=? or eec.id=? and \n"
            + "    st_distance_sphere(Point(ee.latitude,ee.longitude),Point(?,?)) <= ? \n"
            + "union all\n"
            + "select \n"
            + "	fe.id, \n"
            + "    \"foursquare\" as source,\n"
            + "    fe.api_id, \n"
            + "    fe.name as title,\n"
            + "    fe.url, \n"
            + "    fe.tag,\n"
            + "    null as description,\n"
            + "    eec.name as category,\n"
            + "    eec.id as category_id,\n"
            + "    fl.latitude as latitude,\n"
            + "    fl.longitude as longitude,\n"
            + "    fe.startAt as start_time, \n"
            + "    fe.endAt as stop_time, \n"
            + "    fe.venue_id,\n"
            + "    fv.name as venue_name,\n"
            + "    fl.address as venue_address,\n"
            + "    fl.city as city_name,\n"
            + "    fl.state as region_name,\n"
            + "    fl.country as country_name,\n"
            + "    null as free,\n"
            + "    null as price,\n"
            + "    null as privacy,\n"
            + "    null as withdrawn,\n"
            + "    null as withdrawn_note,\n"
            + "    null as performer_api_id,\n"
            + "    null as performer_name,\n"
            + "    null as performer_category,\n"
            + "    null as performer_bio,\n"
            + "    null as performer_url    \n"
            + "from foursquare_event fe\n"
            + "inner join foursquare_venue fv on fe.venue_id=fv.id\n"
            + "inner join foursquare_location fl on fl.venue_id = fv.id\n"
            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id"
            + "    where \n"
            + "	   fe.venue_id = ? or\n"
            + "	   eec.id = ?  and\n"
            + "    st_distance_sphere(Point(fl.latitude,fl.longitude),Point(?,?)) <= ?     \n"
            + "    order by title\n";

    private static final String SQL_SEARCH_ALL = "select \n"
            + "	     ee.id, \n"
            + "    \"eventful\" as source,\n"
            + "    ee.api_id, \n"
            + "    ee.title,\n"
            + "    ee.url,\n"
            + "    ee.tag,\n"
            + "    ee.description,\n"
            + "    eec.name as category, \n"
            + "    ee.latitude, \n"
            + "    ee.longitude,\n"
            + "    ee.start_time,\n"
            + "    ee.stop_time,\n"
            + "    ee.venue_id,\n"
            + "    ee.venue_name,\n"
            + "    ee.venue_address,\n"
            + "    ee.city_name,\n"
            + "    ee.region_name,\n"
            + "    ee.country_name,\n"
            + "    ee.free,\n"
            + "    ee.price,\n"
            + "    ee.privacy,\n"
            + "    ee.withdrawn,\n"
            + "    ee.withdrawn_note,\n"
            + "    ep.api_id as performer_api_id,\n"
            + "    ep.name as performer_name,\n"
            + "    ep.category as performer_category,\n"
            + "    ep.long_bio as performer_bio,\n"
            + "    ep.url as performer_url"
            + " "
            + "    from eventful_event ee \n"
            + "left outer join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "    left outer join eventful_performer ep on ehp.performer_id=ep.id\n"
            + "	 left outer join eventful_event_has_category ehc on ehc.event_id = ee.id\n"
            + "    left outer join eventful_event_category eevc on ehc.category_id = eevc.id\n"
            + "    left outer  join ee_event_category_has_eventful_category echec on eevc.id = echec.eventful_event_category_id\n"
            + "    left outer  join ee_event_category eec on eec.id = echec.ee_event_category_id\n"
            + "    "
           + "    where ee.tag like ? \n"
           //  +"where contains (ee.tag,?) \n"
            + "    union all\n"
            + "    select \n"
            + "	   fe.id, \n"
            + "    \"foursquare\" as source,\n"
            + "    fe.api_id, \n"
            + "    fe.name as title,\n"
            + "    fe.url, \n"
            + "    fe.tag,"
            + "    null as description,\n"
            + "    eec.name as category,\n"
            + "    fl.latitude as latitude,\n"
            + "    fl.longitude as longitude,\n"
            + "    fe.startAt as start_time, \n"
            + "    fe.endAt as stop_time, \n"
            + "    fe.venue_id,    \n"
            + "    fv.name as venue_name,\n"
            + "    fl.address as venue_address,\n"
            + "    fl.city as city_name,\n"
            + "    fl.state as region_name,\n"
            + "    fl.country as country_name,\n"
            + "    null as free,\n"
            + "    null as price,\n"
            + "    null as privacy,\n"
            + "    null as withdrawn,\n"
            + "    null as withdrawn_note,\n"
            + "    null as performer_api_id,\n"
            + "    null as performer_name,\n"
            + "    null as performer_category,\n"
            + "    null as performer_bio,\n"
            + "    null as performer_url    "
            + "    from foursquare_event fe\n"
            + "    inner join foursquare_venue fv on fe.venue_id=fv.id\n"
            + "    inner join foursquare_location fl on fl.venue_id = fv.id\n"
            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id"
            + "    where fe.tag like ? \n"
           // + "    where contains (fe.tag,?) \n"
            + "	   "
            + "    order by title\n";

    private static final String SQL_FIND_RELEVANT = "select \n"
            + "	     ee.id, \n"
            + "    \"eventful\" as source,\n"
            + "    ee.api_id, \n"
            + "    ee.title,\n"
            + "    ee.url,\n"
            + "    ee.tag,\n"
            + "    ee.description,\n"
            + "    eec.name as category, \n"
            + "    ee.latitude, \n"
            + "    ee.longitude,\n"
            + "    ee.start_time,\n"
            + "    ee.stop_time,\n"
            + "    ee.venue_id,\n"
            + "    ee.venue_name,\n"
            + "    ee.venue_address,\n"
            + "    ee.city_name,\n"
            + "    ee.region_name,\n"
            + "    ee.country_name,\n"
            + "    ee.free,\n"
            + "    ee.price,\n"
            + "    ee.privacy,\n"
            + "    ee.withdrawn,\n"
            + "    ee.withdrawn_note,\n"
            + "    ep.api_id as performer_api_id,\n"
            + "    ep.name as performer_name,\n"
            + "    ep.category as performer_category,\n"
            + "    ep.long_bio as performer_bio,\n"
            + "    ep.url as performer_url"
            + " "
            + "    from eventful_event ee \n"
            + "	  left outer join eventful_event_has_performer ehp on ehp.event_id=ee.id\n"
            + "    left outer join eventful_performer ep on ehp.performer_id=ep.id\n"
            + "	 left outer join eventful_event_has_category ehc on ehc.event_id = ee.id\n"
            + "    left outer join eventful_event_category eevc on ehc.category_id = eevc.id\n"
            + "    left outer  join ee_event_category_has_eventful_category echec on eevc.id = echec.eventful_event_category_id\n"
            + "    left outer  join ee_event_category eec on eec.id = echec.ee_event_category_id"
            + "    "
            + "    where \n"
            + "	   eec.id = ? and\n"
            + "	   ee.city_name = ? and\n"
            + "    st_distance_sphere(Point(ee.latitude,ee.longitude),Point(?,?)) <= ? \n"
            + "	   "
            + "    union all \n"
            + "    select \n"
            + "	   fe.id, \n"
            + "    \"foursquare\" as source,\n"
            + "    fe.api_id, \n"
            + "    fe.name as title,\n"
            + "    fe.url, \n"
            + "    fe.tag,"
            + "    null as description,\n"
            + "    eec.name as category,\n"
            + "    fl.latitude as latitude,\n"
            + "    fl.longitude as longitude,\n"
            + "    fe.startAt as start_time, \n"
            + "    fe.endAt as stop_time, \n"
            + "    fe.venue_id,    \n"
            + "    fv.name as venue_name,\n"
            + "    fl.address as venue_address,\n"
            + "    fl.city as city_name,\n"
            + "    fl.state as region_name,\n"
            + "    fl.country as country_name,\n"
            + "    null as free,\n"
            + "    null as price,\n"
            + "    null as privacy,\n"
            + "    null as withdrawn,\n"
            + "    null as withdrawn_note,\n"
            + "    null as performer_api_id,\n"
            + "    null as performer_name,\n"
            + "    null as performer_category,\n"
            + "    null as performer_bio,\n"
            + "    null as performer_url    "
            + "    from foursquare_event fe\n"
            + "    inner join foursquare_venue fv on fe.venue_id=fv.id\n"
            + "    inner join foursquare_location fl on fl.venue_id = fv.id\n"
            + "    inner join foursquare_venue_has_category fvhs on fvhs.venue_id = fv.id\n"
            + "    inner join foursquare_category fc on fc.id = fvhs.category_id  \n"
            + "    inner join ee_event_category_has_foursquare_category echfc on fc.id = echfc.foursquare_category_id\n"
            + "    inner join ee_event_category eec on eec.id = echfc.ee_event_category_id"
            + "    where \n"
            + "	   eec.id = ?  and\n"
            + "	   fl.city = ? and\n"
            + "    st_distance_sphere(Point(fl.latitude,fl.longitude),Point(?,?)) <= ?     \n"
            + "	   "
            + "    order by title\n"
            + " limit 10";

    private final ConnectionFactory factory = ConnectionFactory.getInstance();

    private static EE_EventsResponseModel map(ResultSet resultSet) throws SQLException {
        EE_EventsResponseModel object = new EE_EventsResponseModel();

        object.setId(resultSet.getLong("id"));
        object.setSource(resultSet.getString("source"));
        object.setApi_id(resultSet.getString("api_id"));
        object.setTitle(resultSet.getString("title"));
        object.setUrl(resultSet.getString("url"));
        object.setTag(resultSet.getString("tag"));
        object.setDescription(resultSet.getString("description"));
        object.setCategory(resultSet.getString("category"));
        object.setLatitude(resultSet.getFloat("latitude"));
        object.setLongitude(resultSet.getFloat("longitude"));
        object.setStart_time(resultSet.getString("start_time"));
        object.setStop_time(resultSet.getString("stop_time"));
        object.setVenue_id(resultSet.getLong("venue_id"));
        object.setVenue_name(resultSet.getString("venue_name"));
        object.setVenue_address(resultSet.getString("venue_address"));
        object.setCity_name(resultSet.getString("city_name"));
        object.setRegion_name(resultSet.getString("region_name"));
        object.setCountry_name(resultSet.getString("country_name"));
        object.setFree(resultSet.getBoolean("free"));
        object.setPrice(resultSet.getString("price"));
        object.setPrivacy(resultSet.getInt("privacy"));
        object.setWithdrawn(resultSet.getBoolean("withdrawn"));
        object.setWithdrawn_note(resultSet.getString("withdrawn_note"));
        object.setPerformer_api_id(resultSet.getString("performer_api_id"));
        object.setPerformer_name(resultSet.getString("performer_name"));
        object.setPerformer_category(resultSet.getString("performer_category"));
        object.setPerformer_bio(resultSet.getString("performer_bio"));
        object.setPerformer_url(resultSet.getString("performer_url"));
        return object;
    }

    private static EE_EventsDetailsEventfulModel map_details(ResultSet resultSet) throws SQLException {
        EE_EventsDetailsEventfulModel object = new EE_EventsDetailsEventfulModel();

        object.setTitle(resultSet.getString("title"));
        object.setDescription(resultSet.getString("description"));
        object.setUrl(resultSet.getString("url"));
        object.setCategory(resultSet.getString("category"));
        object.setPrice(resultSet.getString("price"));
        object.setStart_time(resultSet.getString("start_time"));
        object.setVenue_name(resultSet.getString("venue_name"));
        object.setVenue_address(resultSet.getString("venue_address"));
        object.setCity_name(resultSet.getString("city_name"));
        object.setRegion_name(resultSet.getString("region_name"));
        object.setCountry_name(resultSet.getString("country_name"));
        object.setPerformer_name(resultSet.getString("performer_name"));
        object.setPerformer_url(resultSet.getString("performer_url"));

        return object;
    }

    @Override
    public List<EE_EventsResponseModel> list() {
        List<EE_EventsResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_BY_NAME);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_EventsDetailsEventfulModel> list_details() {
        List<EE_EventsDetailsEventfulModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_LIST_DETAILS);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                result.add(map_details(resultSet));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public EE_EventsResponseModel find_by_api_id(String api_id) {
        EE_EventsResponseModel event = null;

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_FIND_BY_API_ID, api_id);
//                statement.setString(1, getApi_id());
//            statement.setString(2, request.getApi_id());
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                event = map(resultSet);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return event;
    }

    @Override
    public List<EE_EventsResponseModel> search(EE_EventRequest request) {
        List<EE_EventsResponseModel> result = new ArrayList<>();

        String start_time_min = request.getStart_time_min();
        String start_time_max = request.getStart_time_max();

        if (start_time_min.length() == 10) {
            start_time_min = start_time_min + " 00:00:00";
        }

        if (start_time_max.length() == 10) {
            start_time_max = start_time_max + " 00:00:00";
        }

        Timestamp t1 = java.sql.Timestamp.valueOf(start_time_min);
        Timestamp t2 = java.sql.Timestamp.valueOf(start_time_max);

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_BY_NAME);) {

            statement.setString(1, request.getSelectedEventPlace());
            statement.setLong(2, request.getSelectedEventCategory());
            statement.setTimestamp(3, t1);
            statement.setTimestamp(4, t2);
            statement.setDouble(5, request.getLatitude());
            statement.setDouble(6, request.getLongitude());
            statement.setDouble(7, request.getDistance() * 1000);
            statement.setString(8, request.getSelectedEventPlace());
            statement.setLong(9, request.getSelectedEventCategory());
            statement.setTimestamp(10, t1);
            statement.setTimestamp(11, t2);
            statement.setDouble(12, request.getLatitude());
            statement.setDouble(13, request.getLongitude());
            statement.setDouble(14, request.getDistance() * 1000);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Override
    public List<EE_EventsResponseModel> search_events_close_to_venue(EE_FindEventsFromSelectedVenueRequest request) {
        List<EE_EventsResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_EVENTS_FROM_SELECTED_VENUE);) {

            statement.setLong(1, request.getVenue_id());
            statement.setLong(2, request.getSelectedEventCategory());
            statement.setDouble(3, request.getLatitude());
            statement.setDouble(4, request.getLongitude());
            statement.setDouble(5, request.getDistance() * 1000);
            statement.setLong(6, request.getVenue_id());
            statement.setLong(7, request.getSelectedEventCategory());
            statement.setDouble(8, request.getLatitude());
            statement.setDouble(9, request.getLongitude());
            statement.setDouble(10, request.getDistance() * 1000);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
      
        return result;
    }

    @Override
    public List<EE_EventsResponseModel> search_all(EE_Free_Search_EventsRequest request) {
        List<EE_EventsResponseModel> result = new ArrayList<>();

        try (Connection connection = factory.getConnection();
                PreparedStatement statement = DAOUtil.prepareStatement(connection, SQL_SEARCH_ALL);) {

            statement.setString(1, request.getTagword());
            statement.setString(2, request.getTagword());

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.add(map(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
        return result;
    }

  

}
