package com.eventsentertainment.training;

import com.evententertainment.database.dao.ee.EE_EventCategoryDAO;
import com.evententertainment.database.dao.ee.EE_EventCategoryDAOImpl;
import com.evententertainment.database.dao.ee.EE_Event_Category_Has_Eventful_CategoryDAO;
import com.evententertainment.database.dao.ee.EE_Event_Category_Has_Eventful_CategoryDAOImpl;
import com.evententertainment.database.dao.ee.EE_Event_Category_Has_Foursquare_CategoryDAO;
import com.evententertainment.database.dao.ee.EE_Event_Category_Has_Foursquare_CategoryDAOImpl;
import com.evententertainment.database.dao.ee.EE_RegionDAO;
import com.evententertainment.database.dao.ee.EE_RegionDAOImpl;
import com.evententertainment.database.dao.ee.EE_VenueCategoryDAO;
import com.evententertainment.database.dao.ee.EE_VenueCategoryDAOImpl;
import com.evententertainment.database.dao.ee.EE_Venue_Category_Has_Eventful_CategoryDAO;
import com.evententertainment.database.dao.ee.EE_Venue_Category_Has_Eventful_CategoryDAOImpl;
import com.evententertainment.database.dao.ee.EE_Venue_Category_Has_Foursquare_CategoryDAO;
import com.evententertainment.database.dao.ee.EE_Venue_Category_Has_Foursquare_CategoryDAOImpl;
import com.evententertainment.database.dao.ee.Eventful_Event_CategoryDAO;
import com.evententertainment.database.dao.ee.Eventful_Event_CategoryDAOImpl;
import com.evententertainment.database.dao.ee.Eventful_Venue_CategoryDAO;
import com.evententertainment.database.dao.ee.Eventful_Venue_CategoryDAOImpl;
import com.evententertainment.database.dao.ee.Foursquare_CategoryDAO;
import com.evententertainment.database.dao.ee.Foursquare_CategoryDAOImpl;

import com.evententertainment.database.model.ee.EE_Event_CategoryModel;
import com.evententertainment.database.model.ee.EE_Event_Category_Has_Eventful_CategoryModel;
import com.evententertainment.database.model.ee.EE_Event_Category_Has_Foursquare_CategoryModel;
import com.evententertainment.database.model.ee.EE_Venue_Category_Has_Foursquare_CategoryModel;
import com.evententertainment.database.model.ee.EE_RegionModel;
import com.evententertainment.database.model.ee.EE_Venue_CategoryModel;
import com.evententertainment.database.model.ee.EE_Venue_Category_Has_Eventful_CategoryModel;
import com.evententertainment.database.dao.ee.Eventful_Event_CategoryDAO;
import com.evententertainment.database.dao.ee.Eventful_Event_CategoryDAOImpl;
import java.util.Map;

public class Program {

    public static void main(String[] args) {
       // ta xw kanei import apo eventful_importer kai foursquare_importer
        Foursquare_CategoryDAO fdao = new Foursquare_CategoryDAOImpl();
        Eventful_Event_CategoryDAO eecdao = new Eventful_Event_CategoryDAOImpl();
       // vazw karfwta times alla programmatistika
        EE_RegionDAO rdao = new EE_RegionDAOImpl();
        Eventful_Venue_CategoryDAO evtdao = new Eventful_Venue_CategoryDAOImpl();
       // exoun diamorfwthei sumpsifizontas ta eventful_event_category kai foursquare_category
        EE_EventCategoryDAO cdao = new EE_EventCategoryDAOImpl();
        EE_VenueCategoryDAO vdao = new EE_VenueCategoryDAOImpl();
       // endiamesoi pinakes pou dimiourgountai karfwta alla programmatistika
        EE_Event_Category_Has_Eventful_CategoryDAO etcdao = new EE_Event_Category_Has_Eventful_CategoryDAOImpl();
        EE_Event_Category_Has_Foursquare_CategoryDAO efcdao = new EE_Event_Category_Has_Foursquare_CategoryDAOImpl();
        EE_Venue_Category_Has_Eventful_CategoryDAO vtcdao = new EE_Venue_Category_Has_Eventful_CategoryDAOImpl();
        EE_Venue_Category_Has_Foursquare_CategoryDAO cfcdao = new EE_Venue_Category_Has_Foursquare_CategoryDAOImpl();

       // insert regions       
        rdao.deleteAll();
        for (EE_RegionModel t : ImportConstants.r) {
            rdao.create(t);
        }

        cdao.deleteAll();
        for (EE_Event_CategoryModel t : ImportConstants.ec) {
            cdao.create(t);
        }

        //insert ee_venue_categories       
        vdao.deleteAll();
        for (EE_Venue_CategoryModel t : ImportConstants.vc) {
            vdao.create(t);
        }

        for (Map.Entry<Long, EE_Venue_CategoryModel[]> entry : ImportConstants.myMapVenues.entrySet()) {
            Long key = entry.getKey();
            EE_Venue_CategoryModel[] value = entry.getValue();
            
             for (EE_Venue_CategoryModel vcm : value) {
                 EE_Venue_Category_Has_Eventful_CategoryModel t = new EE_Venue_Category_Has_Eventful_CategoryModel(vcm.getId(), key);
                 vtcdao.create(t);
             }            
        }
        
        for (Map.Entry<Long, EE_Event_CategoryModel[]> entry: ImportConstants.myMapEvents.entrySet()){
        Long key=entry.getKey();
        EE_Event_CategoryModel[] value=entry.getValue();
        
             for (EE_Event_CategoryModel ecm : value){
             EE_Event_Category_Has_Eventful_CategoryModel t = new EE_Event_Category_Has_Eventful_CategoryModel(ecm.getId(),key);
             etcdao.create(t);
             }
        
        }
        for (Map.Entry<Long,EE_Event_CategoryModel[]> entry: ImportConstants.myMapFoursquareEvents.entrySet()){
        Long key=entry.getKey();
        EE_Event_CategoryModel[] value=entry.getValue();
        
               for (EE_Event_CategoryModel ec : value){
               EE_Event_Category_Has_Foursquare_CategoryModel t = new EE_Event_Category_Has_Foursquare_CategoryModel(ec.getId(), key);
               efcdao.create(t);
               
               }
        }
        for (Map.Entry<Long,EE_Venue_CategoryModel[]> entry: ImportConstants.myMapFoursquareVenues.entrySet()){
        Long key=entry.getKey();
        EE_Venue_CategoryModel[] value=entry.getValue();
        
               for (EE_Venue_CategoryModel vc : value){
               EE_Venue_Category_Has_Foursquare_CategoryModel t = new EE_Venue_Category_Has_Foursquare_CategoryModel(vc.getId(), key);
               cfcdao.create(t);
               
               }
        }
        

    }

}
