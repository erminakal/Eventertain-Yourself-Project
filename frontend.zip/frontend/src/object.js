var UserOne={
name:'ermina', email:'ermina@gmail.com'

};

print()
{
    console.log(UserOne.email);}