<template>
  <div class="faq">
    <div id="body">
      <h3>Frequently Asked Questions</h3>
    </div>
  </div>
</template>

<script>
export default {
  name: "faq"
};
</script>
<style>
</style>
