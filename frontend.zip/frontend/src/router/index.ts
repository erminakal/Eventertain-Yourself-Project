import Vue from "vue";
import VueRouter from "vue-router";
import Home from "C:/Users/user/Desktop/EFProject/frontend/efproject/src/views/Home.vue";
import About from "C:/Users/user/Desktop/EFProject/frontend/efproject/src/views/About.vue";
import Search_Events_Venues from "C:/Users/user/Desktop/EFProject/frontend/efproject/src/views/Search_Events_Venues.vue";
import Contact from "C:/Users/user/Desktop/EFProject/frontend/efproject/src/views/Contact.vue";
import NavBar from "C:/Users/user/Desktop/EFProject/frontend/efproject/src/components/NavBar.vue";
Vue.use(VueRouter);
import { FormDatepickerPlugin } from 'bootstrap-vue';
Vue.use(FormDatepickerPlugin);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home
  },
  {
    path: "/about",
    name: "about",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: About
  },
  {
    path: "/search_events_venues",
    name: "search_events_venues",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Search_Events_Venues
  },
  
  {
    path: "/contact",
    name: "Contact",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Contact
  }


];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
