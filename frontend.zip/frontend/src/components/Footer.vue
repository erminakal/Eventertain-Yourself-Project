<template>
  <div id="footer" class="fluid-container footer">
    <div class="col-md-7 mt-md-0 mt-2" id="footer-nav">
      <b-row>
        <b-col>
          <div id="eventful">
            <p>
              <a href="https://eventful.com/" target="_blank">
                <img
                  src="@/assets/eventful_logo.gif"
                  alt="Local Events, Concerts, Tickets"
                  id="eventful_logo"
                />
              </a>
            </p>
          </div>
        </b-col>
        <b-col>
          <div id="foursquare">
            <p>
              <a href="https://foursquare.com/city-guide" target="_blank">
                <img
                  src="@/assets/foursquare.gif"
                  alt="Foursquare_Venues"
                  id="foursquare_logo"
                />
              </a>
            </p>
          </div>
        </b-col>

        <b-col>
          <p id="copyright">© 2020 Copyright</p>
        </b-col>
      </b-row>
    </div>
  </div>
</template>

<script>
export default { name: "footer" };
</script>

<style>
.fluid-container.footer {
  background: blue;
}
.fluid-container.footer > *:last-child {
  margin-bottom: 0px;
  color: #fff;
}
</style>